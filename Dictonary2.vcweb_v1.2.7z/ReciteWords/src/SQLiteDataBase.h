﻿// SQLiteDataBase.h
#ifndef _SQLITEDATABASE_H_
#define _SQLITEDATABASE_H_

// tWord tSymbol tMeaning tSentences nLevel nFamiliar lLastDate
using namespace std;

struct sqlite3;
struct sqlite3_stmt;

class CWord{
public:
	CWord(){}
	//拷贝构造函数  
	CWord(const CWord& wd)
    {  
		m_tWord = wd.m_tWord.c_str();
		m_tSymbol = wd.m_tSymbol.c_str();
		m_tMeaning = wd.m_tMeaning.c_str();
		m_tSentences = wd.m_tSentences.c_str();
		//m_nLevel = wd.m_nLevel;
		//m_nFamiliar = wd.m_nFamiliar;
		//m_lLastDate = wd.m_lLastDate;

		m_tLevel = wd.m_tLevel.c_str();
		m_tFamiliar = wd.m_tFamiliar.c_str();
		m_tLastDate = wd.m_tLastDate.c_str();
    }
	~CWord(){}
	
private:
	tString m_tWord;
	tString m_tSymbol;
	tString m_tMeaning;
	tString m_tSentences;

	//int m_nLevel;
	tString m_tLevel;
	
	//int m_nFamiliar;
	tString m_tFamiliar;

	//long m_lLastDate;
	tString m_tLastDate;

public:
	// subscript operator for const objects returns value
	inline tString operator [] (int i) const
	{
		VERIFY(1 <= i <= 7);
		switch (i)
		{
		case 1:
			return m_tWord;
		case 2:
			return m_tSymbol;
		case 3:
			return m_tMeaning;
		case 4:
			return m_tSentences;
		case 5:
			return m_tLevel;
		case 6:
			return m_tFamiliar;
		case 7:
			return m_tLastDate;
		}
	}

	//subscript operator for non-const objects returns modifiable value
	inline tString& operator [] (int i)
	{
		VERIFY(1 <= i <= 7);
		switch (i)
		{
		case 1:
			return m_tWord;
		case 2:
			return m_tSymbol;
		case 3:
			return m_tMeaning;
		case 4:
			return m_tSentences;
		case 5:
			return m_tLevel;
		case 6:
			return m_tFamiliar;
		case 7:
			return m_tLastDate;
		}
	}
	
	void SetWord(const tString& wd) { m_tWord = wd.c_str(); }
	tString GetWord() const { return m_tWord; }

	void SetSymbol(const tString& sym) { m_tSymbol = sym.c_str(); }
	tString GetSymbol() const { return m_tSymbol; }

	tString SetMeaning(const tString& m) { m_tMeaning = m.c_str(); }
	tString GetMeaning() const { return m_tMeaning; }

	void SetSentences(const tString& sen) { m_tSentences = sen.c_str(); }
	tString GetSentences() const{ return m_tSentences; }

	void SetLevel(const int level) {
		Int2String(level, m_tLevel);
		//m_nLevel = level;
	}
	int GetLevel() const{ return _ttoi(m_tLevel.c_str()); }
	//int GetLevel() const{ return m_nLevel; }

	void IncreaseFamiliar(int n = 1){
		int familiar = _ttoi(m_tFamiliar.c_str());
		if(familiar >= 1) {
			familiar--;
			Int2String(familiar, m_tFamiliar);
		}
		//m_nFamiliar += n;
	}
	void DecreaseFamiliar(int n = 1){
		int familiar = _ttoi(m_tFamiliar.c_str());
		if(familiar <= 10) {
			familiar++;
			Int2String(familiar, m_tFamiliar);
		}
		//m_nFamiliar -= n;
	}
	int GetFamiliar() const {
		return _ttoi(m_tFamiliar.c_str());
		//return m_nFamiliar;
	}

	void SetLastDate(const long time) {
		//TCHAR tszTime[20];
		//_stprintf(tszTime, _T("%d"), time);
		//m_tLastDate = tszTime;
		Int2String(time, m_tLastDate);
		//m_lLastDate = time;
	}
	long GetLastDate() const {
		return _ttoi(m_tLastDate.c_str());
		//return m_lLastDate;
	}

private:
	void Int2String(const long l, tString& str){
		TCHAR tsz[20];
		_stprintf(tsz, _T("%d"), l);
		str = tsz;
	}
};

typedef vector<CWord> WordArray;

class CSQLiteDataBase {
public:
	CSQLiteDataBase();
	~CSQLiteDataBase();

private:
	const tString m_tTableName;
    sqlite3* m_pDataBase;
	bool m_bDebug;

	sqlite3_stmt *m_pStmt;

public:	
	bool LoadDict(const tString& filename);

	bool UnloadDict();

    bool GetContent(const tString& wd, CWord &word);
	
	bool GetSimilarWordList(const tString& wd, WordArray& findWords, int num = -1);
	bool GetWordListByDate(long afterDate, WordArray& findWords, int num = -1);
	bool GetWordListByFamiliar(int lessFamiliar, WordArray& findWords, int num = -1);
	bool GetStrangeWordList(long afterDate, int lessFamiliar, WordArray& findWords, int num = -1);
	bool GetWordList(WordArray& findWords, int start, int num = -1);
	
	bool UpdateWord(const CWord& word);
	bool UpdateLevel(const tString& wd, int level);
	bool UpdateFamiliar(const tString& wd, int familiar);
	bool UpdateLastDate(const tString& wd, int lastDate);
	
	bool InsertWord(const CWord* pWord);
	bool DeleteWord(const tString& wd);
	
private:
	bool CreateTabel(const TCHAR* table);
	bool GetWordList(const tString& tSql, WordArray& findWords, int num);
	bool UpdateData(const tString& wd, const tString& item, const tString& value);
	bool ExecSql(const tString& tSql);
	LPCTSTR GetLastErrorMsg();

	
	/*LPCTSTR GetStringValue(int nCol);	// 获取某列的值(字符串)	
	int GetIntValue(int nCol);				// 获取某列的值(整形)	
	long GetInt64Value(int nCol);		// 获取某列的值(长整形)*/
};

#endif //_SQLITEDATABASE_H_