//************************* begin of -- include ******************************
#include "stdafx.h"
//#include <stdlib.h>
//#include <iostream>
#include "IniFile.h"
//#include "LogFile.h"
//************************* **end of -- include ******************************

using namespace std;

CIniFile::CIniFile(const TCHAR* tszfile)
{
	m_bModified = false;
	//m_tszfile = const_cast<TCHAR*>(tszfile);
	_tcscpy(m_tszfile, tszfile);
	m_pFile = NULL;
	switch(OpenFile())
	{
		case 0:
			break;
		case 1:
			//LOGINFO(_T("fail to open %s file"), tszfile);
			break;
		case 2:
			//LOGINFO(_T("fail to read %s file to buffer"), tszfile);
			break;
	}
}

CIniFile::~CIniFile()
{
	CloseFile();
}

/*******************************************************************************
 *  desc: open ini file
 *------------------------------------------------------------------------------
 * param: char *tszfile  -- file to open
 *------------------------------------------------------------------------------
 * return: 0  -- file succefully opened
 *   -1  -- fail to open ini file
 *   -2  -- fail to read file to buffer
 *   -3  -- fail to close file
*******************************************************************************/
int CIniFile::OpenFile()
{
	//LOGINFO(_T("ready to Open ini File: %s\n"), tszfile);

	// open file
	m_pFile = NULL;
	m_pFile = _tfopen(m_tszfile, _T("r+"));
	//_tfopen_s(&m_pFile, tszfile, _T("a+"));
	assert(m_pFile);

	if (NULL == m_pFile) return -1;

	TCHAR tszLine[256];
	tString tszString;

	TCHAR *tszKey, *tszValue;
	
	tString tSection;

	bool bWrongFile = true;

	//while(!fin.eof())
	while(_fgetts(tszLine, 256, m_pFile))
	{
		//LOGINFO(_T("Line��%s"), tszLine);

		tszString = tszLine;

		StringTrim(tszString);

		if (0 == tszString.length()) continue;

		_tcscpy(tszLine, tszString.c_str());	//trim bank in head and tail
		//if(_tcscmp(tszLine[0], _T('[')) == 0)
		if(tszLine[0] == _T('['))
		{
			//tszLine = Mid(tszLine, 1, _tcslen(tszLine)-2);
			tSection = tszLine;
			int pos = tSection.find(_T(']'));
			if (pos != string::npos)
				tSection = tSection.substr(1, pos - 1);
			else continue;
			//tSection = tSection.substr(1, _tcslen(tszLine) - 3);
			//tSection = tSection.substr(1, _tcslen(tszLine) - 2);
			//map<tString, tString> mapSection;
			//m_mapData[tSection] = mapSection;
			//LOGINFO(_T("Section: %s"), tSection.c_str());

			bWrongFile = false;
		}
		//else if((_tcscmp(tszLine[0], _T('#')) != 0) || (_tcscmp(tszLine[0], _T(';')) != 0))
		else if (tszLine[0] != _T('#') && tszLine[0] != _T(';') && tszLine[0] != _T('\n') &&
			false == bWrongFile)
		{
			tszKey = _tcstok(tszLine, _T("="));
			tszValue = _tcstok(NULL, _T("="));

			tszString = tszKey;
			StringTrim(tszString);
			_tcscpy(tszKey, tszString.c_str());

			if (tszValue == NULL) tszValue = _T("");
			else {
				tszString = tszValue;
				StringTrim(tszString);
				_tcscpy(tszValue, tszString.c_str());
			}

			/*tString tValue = tszValue;
			tValue.resize(M_MAX_VALUE_BUFFER_SIZE);
			m_mapData[tSection][tszKey] = tValue;*/

			m_mapData[tSection][tszKey] = tszValue;
			
			//LOGINFO(_T("tszKey: %s,\t tszValue: %s"), tszKey, tszValue);
		}
	}

	// close file
	if (fclose(m_pFile) != -1)
	{
		m_pFile = NULL;
		if (true == bWrongFile) {
			assert(NULL);
		}
		return 0;
	}
	
	return -3;
}

/*******************************************************************************
 *  desc: close ini file
 *------------------------------------------------------------------------------
 * param: none
 *------------------------------------------------------------------------------
 * return: 0  -- file successfully closed
 *   -1  -- fail to close the opened file
*******************************************************************************/
int CIniFile::CloseFile(void)
{
	// file not opened
	// if(m_pFile == NULL) return true;

	//m_pChanged = false;
	// save file if buffer changed
	if (true == m_bModified)
	{
		//// close file
		//fclose(m_pFile);
		//m_pFile = NULL;
		m_pFile = _tfopen(m_tszfile, _T("w+"));

		//LOGINFO(_T("\nCloseFile -- wrtie file"));
		//_tfwrite(m_tszFilebuffer, m_lFilesize, 1, m_pFile);
		map<tString, map<tString, tString>>::reverse_iterator rit;
		map<tString, tString>::iterator intertr;
		for (rit = m_mapData.rbegin(); rit != m_mapData.rend(); rit++)
		{
			//std::wcout << _T("[") << multitr->first << _T("]") <<endl;
			_fputts(_T("["), m_pFile);
			_fputts(rit->first.c_str(), m_pFile);
			_fputts(_T("]\n"), m_pFile);
			for (intertr = rit->second.begin(); intertr != rit->second.end(); intertr++)
			{
				//std::wcout << intertr->first << " = " << intertr->second << endl;
				_fputts(intertr->first.c_str(), m_pFile);
				_fputts(_T(" = "), m_pFile);
				_fputts(intertr->second.c_str(), m_pFile);
				_fputts(_T("\n"), m_pFile);
			}
			_fputts(_T("\n"), m_pFile);
		}

		fflush(m_pFile);

		// close file
		if (fclose(m_pFile) != -1)
		{
			m_pFile = NULL;
			return 0;
		}
		else
		{
			return -1;
		}
	}
	return 0;
}

/*******************************************************************************
 *  desc: get a string value by key
 *------------------------------------------------------------------------------
 * param: const TCHAR* section -- section name
 *   const TCHAR* key   -- key name
 *   char *  value  -- key value
 *------------------------------------------------------------------------------
 * return: true  -- key value found
 *   false -- key value not found
*******************************************************************************/
bool CIniFile::GetString(const TCHAR* section, const TCHAR* key, TCHAR* value)
{
	//keymap map = m_mapData[section];
	//_tcscpy(value, map[key].c_str());
	//m_mapData[section].find(key)->second
	//_tcscpy(value, map->find(key)->second.c_str());
	//tString* v = &m_mapData[section][key];

	//tString v = static_cast<keymap>(m_mapData[section])[key];
	/*map<tString, tString> * keymap = &m_mapData[section];
	intertr = m_mapData[section].find(key);
	tString v;
	//v = m_mapData[section].at(key);
	v = keymap->at(key);
	//_tcscpy(value, m_mapData[section][key].c_str());*/
	//map<tString, map<tString, tString>>::iterator multitr;

	map<tString, tString>::iterator intertr;
	/*for (multitr = m_mapData.begin(); multitr != m_mapData.end(); multitr++)
	{
	std::wcout << "[" << multitr->first << "]" <<endl;
	for (intertr = multitr->second.begin(); intertr != multitr->second.end(); intertr++)
	std::wcout << intertr->first << " = " << intertr->second << endl;
	}*/
	intertr = m_mapData[section].find(key);
	//std::wcout << _T("start to Get section: ") << (*intertr).first << " = " << (*intertr).second << endl;
	if (intertr != m_mapData[section].end())
	{
		_tcscpy(value, (*intertr).second.c_str());
		//LOGINFO(_T("Get section: %s, key: %s, value: %s\n"), section, key, value);

		return true;
	}
	else
	{
		//LOGINFO(_T("Can't find: section: %s, key: %s"), section, key);
		return false;
	}
}

/*******************************************************************************
 *  desc: set a string value by key
 *------------------------------------------------------------------------------
 * param: const TCHAR* section -- section name
 *   const TCHAR* key   -- key name
 *   const TCHAR* value  -- key value
 *------------------------------------------------------------------------------
 * return: true  -- key value success to write in buffer
*******************************************************************************/
bool CIniFile::SetString(const TCHAR* section, const TCHAR* key, const TCHAR* value)
{
	//LOGINFO(_T("Set section: %s, key: %s, value: %s\n"), section, key, value);
	tString tszValue = value;
	m_mapData[section][key] = tszValue;

	/*try{
		map<tString, tString>::iterator intertr;

		intertr = m_mapData[section].find(key);
		//std::wcout << _T("start to Get section: ") << (*intertr).first << " = " << (*intertr).second << endl;
		if (intertr != m_mapData[section].end())
		{
			//_tcscpy(value, (*intertr).second.c_str());
			(*intertr).second.assign(value);
			m_bModified = true;
			return true;
		}
		else
		{
			m_bModified = false;
			return false;
		}
	}
	catch (CWinException &e)
	{
		e.what();
		// Display the exception and quit
		CString Error = CString(e.GetText()) + "\n" + CString(e.GetErrorString());
		MessageBox(NULL, Error, _T("CWinException thrown"), MB_ICONERROR);
	}*/

	m_bModified = true;
	return true;
}

/*******************************************************************************
 *  desc: get a interger value by key
 *------------------------------------------------------------------------------
 * param: const TCHAR* section -- section name
 *   const TCHAR* key   -- key name
 *   int default_value  -- default value
 *------------------------------------------------------------------------------
 * return: key value or default value
*******************************************************************************/
int CIniFile::GetInteger(const TCHAR* section, const TCHAR* key, int default_value)
{
	TCHAR tszBuffer[M_MAX_INTVAL_BUFFER_SIZE];

	if(GetString(section, key, tszBuffer))
	{
		return (int)(_ttoi(tszBuffer));
	}
	return default_value;
}

/*******************************************************************************
 *  desc: set a interger value
 *------------------------------------------------------------------------------
 * param: const TCHAR* section -- section name
 *   const TCHAR* key   -- key name
 *   const int  value   -- key value
 *------------------------------------------------------------------------------
 * return: true
*******************************************************************************/
bool CIniFile::SetInteger(const TCHAR* section, const TCHAR* key, const int value)
{
	TCHAR tszBuffer[M_MAX_VALUE_BUFFER_SIZE];

	memset(tszBuffer, 0, sizeof(tszBuffer));
	_stprintf(tszBuffer, _T("%d"), value);
	return SetString(section, key, tszBuffer);
}

/*******************************************************************************
 *  desc: get a long value by key
 *------------------------------------------------------------------------------
 * param: const TCHAR* section -- section name
 *   const TCHAR* key   -- key name
 *   long   default_value  -- default value
 *------------------------------------------------------------------------------
 * return: key value or default value
*******************************************************************************/
long CIniFile::GetLong(const TCHAR* section, const TCHAR* key, long default_value)
{
	TCHAR tszBuffer[M_MAX_INTVAL_BUFFER_SIZE];

	if(GetString(section, key, tszBuffer))
	{
		return (int)(_ttol(tszBuffer));
	}
	return default_value;
}

/*******************************************************************************
 *  desc: set a long value
 *------------------------------------------------------------------------------
 * param: const TCHAR* section -- section name
 *   const TCHAR* key   -- key name
 *   const long  value   -- key value
 *------------------------------------------------------------------------------
 * return: true
*******************************************************************************/
bool CIniFile::SetLong(const TCHAR* section, const TCHAR* key, const long value)
{
	TCHAR tszBuffer[M_MAX_INTVAL_BUFFER_SIZE];

	memset(tszBuffer, 0, sizeof(tszBuffer));
	_stprintf(tszBuffer, _T("%d"), value);
	return SetString(section, key, tszBuffer);
}

/*******************************************************************************
 *  desc: get a double value by key
 *------------------------------------------------------------------------------
 * param: const TCHAR* section -- section name
 *   const TCHAR* key   -- key name
 *   double  default_value  -- default value
 *------------------------------------------------------------------------------
 * return: key value or default value
*******************************************************************************/
double CIniFile::GetDouble(const TCHAR* section, const TCHAR* key, double default_value)
{
	TCHAR tszBuffer[M_MAX_INTVAL_BUFFER_SIZE];

	if(GetString(section, key, tszBuffer))
	{
		return (int)(_ttof(tszBuffer));
	}
	return default_value;
}

/*******************************************************************************
 *  desc: set a double value
 *------------------------------------------------------------------------------
 * param: const TCHAR* section -- section name
 *   const TCHAR* key   -- key name
 *   const double value   -- key value
 *------------------------------------------------------------------------------
 * return: true
*******************************************************************************/
bool CIniFile::SetDouble(const TCHAR* section, const TCHAR* key, const double value)
{
	TCHAR tszBuffer[M_MAX_INTVAL_BUFFER_SIZE];

	memset(tszBuffer, 0, sizeof(tszBuffer));
	_stprintf(tszBuffer, _T("%g"), value);
	return SetString(section, key, tszBuffer);
}

/*******************************************************************************
 *  desc: get a bool value by key
 *------------------------------------------------------------------------------
 * param: const TCHAR* section -- section name
 *   const TCHAR* key   -- key name
 *   bool   b_default  -- default value
 *------------------------------------------------------------------------------
 * return: key value or default value
*******************************************************************************/
bool CIniFile::GetBool(const TCHAR* section, const TCHAR* key, bool default_value)
{
	TCHAR tszBuffer[M_MAX_INTVAL_BUFFER_SIZE];

	if(GetString(section, key, tszBuffer))
	{
		if(_tcscmp(tszBuffer, _T("y")) == 0 ||		
			_tcscmp(tszBuffer, _T("yes")) == 0 ||
			_tcscmp(tszBuffer, _T("true")) == 0 )
			return true;
		if(_tcscmp(tszBuffer, _T("n")) == 0 ||
			_tcscmp(tszBuffer, _T("no")) == 0  ||
			_tcscmp(tszBuffer, _T("false")) == 0 )
			return false;
	}
	return default_value;
}

/*******************************************************************************
 *  desc: set a bool value
 *------------------------------------------------------------------------------
 * param: const TCHAR* section -- section name
 *   const TCHAR* key   -- key name
 *   const bool value   -- key value
 *------------------------------------------------------------------------------
 * return: true
*******************************************************************************/
bool CIniFile::SetBool(const TCHAR* section, const TCHAR* key, const bool value)
{
	TCHAR tszBuffer[M_MAX_INTVAL_BUFFER_SIZE];

	memset(tszBuffer, 0, sizeof(tszBuffer));
	if(value)
		_stprintf(tszBuffer, _T("%s"), _T("true"));
	else
		_stprintf(tszBuffer, _T("%s"), _T("false"));
	return SetString(section, key, tszBuffer);
}

/*******************************************************************************
 *  desc: get a time_t value by key
 *------------------------------------------------------------------------------
 * param: const TCHAR* section -- section name
 *   const TCHAR* key   -- key name
 *   time_t   default_value  -- default value
 *------------------------------------------------------------------------------
 * return: key value or default value
*******************************************************************************/
time_t CIniFile::GetTime(const TCHAR* section, const TCHAR* key, time_t default_value){
	TCHAR tszBuffer[M_MAX_INTVAL_BUFFER_SIZE];
	time_t tmpTime = 0;
	int lastI = 0;
	int tmpT = 0;
	int digit;
	TCHAR chr;
	if(GetString(section, key, tszBuffer))
	{
		for(int i=0; i<_tcslen(tszBuffer); i++){
			chr = tszBuffer[i];
			if (_T('d') == chr){
				tmpTime = tmpTime + tmpT * 86400;
			}
			else if (_T('h') == chr){
				tmpTime = tmpTime + tmpT * 3600;
			}
			else if (_T('m') == chr){
				tmpTime = tmpTime + tmpT * 60;
			}
			else if (_T('s') == chr){
				tmpTime = tmpTime + tmpT;
			}
			else {
				digit = chr - _T('0');
				if (tmpT != 0) tmpT = tmpT * 10 + digit;
				else tmpT = digit;
			}
		}
		return tmpTime;
	}
	return default_value;
}


/*******************************************************************************
 *  desc: set a time_t value
 *------------------------------------------------------------------------------
 * param: const TCHAR* section -- section name
 *   const TCHAR* key   -- key name
 *   const time_t value   -- key value
 *------------------------------------------------------------------------------
 * return: true
*******************************************************************************/
bool CIniFile::SetTime(const TCHAR* section, const TCHAR* key, const time_t value)
{
	return false;
}