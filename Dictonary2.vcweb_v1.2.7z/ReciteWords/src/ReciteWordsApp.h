//ReciteWordsApp.h
#ifndef _RECITEWORDSAPP_H_
#define _RECITEWORDSAPP_H_

#include "FullScreenDialog.h"
//#include "Mainfrm.h"

// Declaration of the CReaderApp class
class CReciteWordsApp : public CWinApp
{
public:
	CReciteWordsApp();
	virtual ~CReciteWordsApp();

public:	
	//void Initialize(HINSTANCE hInstance);
	//void Uninitialize();
	virtual BOOL InitInstance();
	CFullScreenDialog& GetDialog() { return m_MyDialog; }
	//CMainFrame& GetMainFrame() { return m_Frame; }

private:
	CFullScreenDialog m_MyDialog;
	//CMainFrame m_Frame;
};

// returns a pointer to the CReciteWordsApp object
inline CReciteWordsApp& GetReciteWordsApp() { return static_cast<CReciteWordsApp&>(GetApp()); }

#endif//_RECITEWORDSAPP_H_