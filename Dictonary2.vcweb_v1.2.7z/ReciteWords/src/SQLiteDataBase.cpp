﻿// SQLiteDataBase.cpp
#include "stdafx.h"
#include "..\..\sqlite3\sqlite3.h"
#pragma comment(lib,"..\\sqlite3\\sqlite3.lib")
#include "SQLiteDataBase.h"
#include "help.h"

//using namespace Win32xx;

CSQLiteDataBase::CSQLiteDataBase():m_tTableName(_T("Words")){
	m_pDataBase = NULL;
	m_bDebug = true;
}

CSQLiteDataBase::~CSQLiteDataBase(){
	m_pDataBase = NULL;
}

bool CSQLiteDataBase::LoadDict(const tString& filename){
	bool newdict = false;
	int ret;

	if(FALSE == ::PathFileExists(filename.c_str())){
		newdict = true;
	}

#ifdef  UNICODE
	ret = sqlite3_open16(filename.c_str(), &m_pDataBase);
#else 
	ret = sqlite3_open(filename.c_str(), &m_pDataBase);
#endif 
	
	//int ret = sqlite3_open16_v2(filename.c_str(),		// Database filename (UTF-8)
	//	&m_pDataBase,	// OUT: SQLite db handle
	//	SQLITE_OPEN_READWRITE | SQLITE_OPEN_CREATE,		// Flags
	//	NULL 	// Name of VFS module to use
	//	);
		
	if(ret != SQLITE_OK) {
		LOGERR(_T("Can't open %s, code: %d."), filename, ret);
		return false;
	}

	if(true == newdict){
		// for(int n = 97; n++ ; n<=122) {
			// CreateTabel(n);
		// }
		CreateTabel(m_tTableName.c_str());
	}

	return true;
}

bool CSQLiteDataBase::UnloadDict(){

	int ret = 0;
	if(m_pDataBase != NULL){
		
		ret = sqlite3_close(m_pDataBase);
		if (SQLITE_OK == ret){
			m_pDataBase = NULL;
			return true;
		}
	}

	return false;
}

bool CSQLiteDataBase::GetContent(const tString& wd, CWord &word){
	bool bRet = false;
	//string szSql = "select * from ";
	//szSql += T2A(m_tTableName.c_str());
	//szSql += " where Word = \"";
	//szSql += T2A(wd.c_str());
	//szSql += "\"";

	tString tSql = _T("select * from ");
	tSql += m_tTableName.c_str();
	tSql += _T(" where Word = \"");
	tSql += wd.c_str();
	tSql += _T("\"");
	
	sqlite3_stmt *pStmt;

	int ret;

#ifdef  UNICODE
	ret = sqlite3_prepare16_v2(m_pDataBase, tSql.c_str(), -1, &pStmt, NULL);
#else 
	ret = sqlite3_prepare_v2(m_pDataBase, tSql.c_str(), -1, &pStmt, NULL);
#endif 

	//int ret = sqlite3_prepare_v2(
	//	m_pDataBase,            /* Database handle */
	//	szSql.c_str(),       	/* SQL statement, UTF-8 encoded */
	//	-1,              /* Maximum length of zSql in bytes. */
	//	&pStmt,  /* OUT: Statement handle */
	//	NULL     /* OUT: Pointer to unused portion of zSql */
	//);

	if(SQLITE_OK == ret){
		ret = sqlite3_step(pStmt);
	
		if (SQLITE_ROW == ret){
			for (int iCol = 0; iCol < 7; iCol++){
#ifdef  UNICODE
				word[iCol + 1] = (LPCTSTR)sqlite3_column_text16(pStmt, iCol + 1);
#else 
				word[iCol + 1] = (LPCTSTR)sqlite3_column_text(pStmt, iCol);
#endif 
			}
			bRet = true;
		}
		else if (SQLITE_DONE == ret){
			LOGMSG(_T("Can't find %s."), wd.c_str());
			bRet = false;
		}
		else {
			LOGERR(_T("sqlite3_step, err: %s."), GetLastErrorMsg());
			bRet = false;
		}
	}
	else {
		LOGERR(_T("sqlite3_prepare_v2: %s, err: %s."), tSql.c_str(), GetLastErrorMsg());
		bRet = false;
	}
	
	//Destroy A Prepared Statement Object
	sqlite3_finalize(pStmt);

	return bRet;
}

bool CSQLiteDataBase::GetSimilarWordList(const tString& wd, WordArray& findWords, int num){

	tString tSql = _T("select * from ");
	tSql += m_tTableName;
	tSql += _T(" where Word like \"");
	tSql += wd;
	tSql += _T("\"");

	return GetWordList(tSql, findWords, num);
}

bool CSQLiteDataBase::GetWordListByDate(long afterDate, WordArray& findWords, int num){

	TCHAR tszDate[20];
	_stprintf(tszDate, _T("%d"), afterDate);

	tString tSql = _T("select * from ");
	tSql += m_tTableName;
	tSql += _T(" where LastDate > ");
	tSql += tszDate;

	return GetWordList(tSql, findWords, num);
}

bool CSQLiteDataBase::GetWordListByFamiliar(int lessFamiliar, WordArray& findWords, int num){

	TCHAR tszFamiliar[10];
	_stprintf(tszFamiliar, _T("%d"), lessFamiliar);

	tString tSql = _T("select * from ");
	tSql += m_tTableName;
	tSql += _T(" where Familiar < ");
	tSql += tszFamiliar;

	return GetWordList(tSql, findWords, num);	
}

bool CSQLiteDataBase::GetStrangeWordList(long afterDate, int lessFamiliar, WordArray& findWords, int num)
{
	TCHAR tszFamiliar[10];
	_stprintf(tszFamiliar, _T("%d"), lessFamiliar);

	TCHAR tszDate[10];
	_stprintf(tszDate, _T("%d"), afterDate);

	tString tSql = _T("select * from ");
	tSql += m_tTableName;
	tSql += _T(" where Familiar < ");
	tSql += tszFamiliar;
	tSql += _T(" And LastDate > ");
	tSql += tszDate;

	return GetWordList(tSql, findWords, num);		
}

bool CSQLiteDataBase::GetWordList(WordArray& findWords, int start, int num){

	TCHAR tszStart[10];
	_stprintf(tszStart, _T("%d"), start);

	tString tSql = _T("select * from ");
	tSql += m_tTableName;
	tSql += _T(" where ID >= ");
	tSql += tszStart;

	return GetWordList(tSql, findWords, num);		
}

bool CSQLiteDataBase::UpdateWord(const CWord& word)
{
	tString tSql = _T("UPDATE ");
	tSql += m_tTableName.c_str();
	tSql += _T(" SET Symbol = '");
	tSql += word.GetSymbol().c_str();
	tSql += _T("' Meaning = '");
	tSql += word.GetMeaning().c_str();
	tSql += _T("' Sentences = '");
	tSql += word.GetSentences().c_str();
	tSql += _T("' Level = '");
	tSql += word[5];
	tSql += _T("' Familiar = '");
	tSql += word[6];
	tSql += _T("' LastDate = '");
	tSql += word[7];	
	tSql += _T("' where Word = '");
	tSql += word.GetWord();
	tSql += _T("' ");
	
	return ExecSql(tSql);	
}

bool CSQLiteDataBase::UpdateLevel(const tString& wd, int level){
	TCHAR tszValue[10];
	_stprintf(tszValue, _T("%d"), level);
	return UpdateData(wd, _T("Level"), tszValue);
}

bool CSQLiteDataBase::UpdateFamiliar(const tString& wd, int familiar){
	TCHAR tszValue[10];
	_stprintf(tszValue, _T("%d"), familiar);
	return UpdateData(wd, _T("Familiar"), tszValue);
}

bool CSQLiteDataBase::UpdateLastDate(const tString& wd, int lastDate){
	TCHAR tszValue[10];
	_stprintf(tszValue, _T("%d"), lastDate);
	return UpdateData(wd, _T("LastDate"), tszValue);
}

bool CSQLiteDataBase::InsertWord(const CWord* pWord){

	CWord word = *pWord;
	tString table = m_tTableName;

	tString wd = word[0];
	tString symbol = word[1];
	tString meaning = word[2];
	tString sentences = word[3];
	tString level = word[4];
	tString familiar = word[5];
	tString lastDate = word[6];

	tString tSql = _T("INSERT INTO ") + table;
	tSql += _T(" VALUES (") + symbol;
	tSql += _T(", ") + meaning;
	tSql += _T(", ") + sentences;
	tSql += _T(", ") + level;
	tSql += _T(", ") + familiar;
	tSql += _T(", ") + lastDate;
	tSql += _T(")");

	return ExecSql(tSql);
}

bool CSQLiteDataBase::DeleteWord(const tString& wd){

	tString tSql = _T("delete from ");
	tSql += m_tTableName;
	tSql += _T(" where Word = \"");
	tSql += wd;
	tSql += _T("\" ");

	return ExecSql(tSql);
}

bool CSQLiteDataBase::CreateTabel(const TCHAR* table){

	tString tSql = _T("CREATE TABLE ");
	tSql += table;
	tSql += _T("(Word TEXT NOT NULL COLLATE PRIMARY KEY, Symbol TEXT, Meaning TEXT NOT NULL , Sentences TEXT, Level INTEGER, Familiar INTEGER, LastDate INTEGER)");

	return ExecSql(tSql);
}

bool CSQLiteDataBase::GetWordList(const tString& tSql, WordArray& findWords, int num)
{
	bool bRet = false;

	//string szSql = T2A(sql.c_str());

	//sqlite3_stmt *pStmt;

	int ret;

#ifdef  UNICODE
	ret = sqlite3_prepare16_v2(m_pDataBase, tSql.c_str(), -1, &m_pStmt, NULL);
#else 
	ret = sqlite3_prepare_v2(m_pDataBase, tSql.c_str(), -1, &pStmt, NULL);
#endif 

	//int ret = sqlite3_prepare_v2(
	//	m_pDataBase,            /* Database handle */
	//	szSql.c_str(),       	/* SQL statement, UTF-8 encoded */
	//	-1,              /* Maximum length of zSql in bytes. */
	//	&pStmt,  /* OUT: Statement handle */
	//	NULL     /* OUT: Pointer to unused portion of zSql */
	//);

	const void* value;

	if(SQLITE_OK == ret){
		ret = sqlite3_step(m_pStmt);
	
		if (SQLITE_ROW == ret) {
			do{
				CWord word;
				for(int iCol=1; iCol<7; iCol++){
					//word[iCol + 1] = (LPCTSTR)sqlite3_column_text(pStmt, iCol));
#ifdef  UNICODE
					//word[iCol + 1] = (LPCTSTR)sqlite3_column_text16(pStmt, iCol + 1);
					value = sqlite3_column_text16(m_pStmt, iCol);
#else 
					//word[iCol + 1] = (LPCTSTR)sqlite3_column_text(pStmt, iCol);
					value = sqlite3_column_text(pStmt, iCol);					
#endif 
					if (NULL != value) word[iCol] = (LPCTSTR)value;
					else word[iCol] = _T("");
				}

				//if (NULL != value) word.SetWord((LPCTSTR)value);

				tString sen = word.GetSentences();
				if (sen.length() >= 1){
					StringReplaceAll(sen, _T("/r/n"), _T("\n"));
					word.SetSentences(sen);
				}
				
				num--;
				findWords.push_back(word);
				ret = sqlite3_step(m_pStmt);
			} while (SQLITE_ROW == ret && num > 0);
			bRet = true;
		}
		else if (SQLITE_ERROR == ret){
			LOGERR(_T("sqlite3_step, err: %s."), GetLastErrorMsg());
			bRet = false;
		}
	}
	else {
		LOGERR(_T("sqlite3_prepare_v2: %s, err: %s."), tSql.c_str(), GetLastErrorMsg());
		bRet = false;
	}
	
	//Destroy A Prepared Statement Object
	sqlite3_finalize(m_pStmt);

	return bRet;
}

bool CSQLiteDataBase::UpdateData(const tString& word, const tString& item, const tString& value){

	tString tSql = _T("UPDATE ");
	tSql += m_tTableName;
	tSql += _T(" SET ");
	tSql += item;
	tSql += _T(" = '");
	tSql += value;
	tSql += _T("' where Word = \"");
	tSql += word;
	tSql += _T("\" ");
	
	return ExecSql(tSql);
}

bool CSQLiteDataBase::ExecSql(const tString& tSql)
{
	int ret = sqlite3_exec(m_pDataBase, T2A(tSql.c_str()), 0, 0, 0);

	if(SQLITE_OK == ret){
		return true;
	}
	else {
		LOGERR(_T("ExecSql: %s, err: %s."), tSql.c_str(), GetLastErrorMsg());
		return false;
	}
}

// 获取上一条错误信息 
LPCTSTR CSQLiteDataBase::GetLastErrorMsg()
{
#ifdef UNICODE
	return (LPCTSTR)sqlite3_errmsg16(m_pDataBase);
#else 
	return sqlite3_errmsg(m_db);
#endif 
}

/*// 获取某列的值(字符串)
LPCTSTR CSQLiteDataBase::GetStringValue(int nCol)
{
#ifdef  UNICODE
	return (LPCTSTR)sqlite3_column_text16(m_pStmt, nCol);
#else 
	return (LPCTSTR)sqlite3_column_text(m_pStmt, nCol);
#endif 
}

// 获取某列的值(整形)
int CSQLiteDataBase::GetIntValue(int nCol)
{
	return sqlite3_column_int(m_pStmt, nCol);
}

// 获取某列的值(长整形) 
long CSQLiteDataBase::GetInt64Value(int nCol)
{
	return (long)sqlite3_column_int64(m_pStmt, nCol);
}*/