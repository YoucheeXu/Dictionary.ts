/*******************************************************************************
class for log File on Unix/Linux/Window

Version :  v1.0.0.0
Description :
change Log

************************************************************************/

#ifndef __LOGFILE__H__
#define __LOGFILE__H__

#ifdef _WIN32
#pragma once
#endif

//#ifndef _CRT_SECURE_NO_WARNINGS
//#define _CRT_SECURE_NO_WARNINGS
//#endif
//
//#ifndef _CRT_SECURE_NO_DEPRECATE
//#define _CRT_SECURE_NO_DEPRECATE
//#endif
//
//#define _CRT_NON_CONFORMING_SWPRINTFS
#pragma warning (disable: 4996)
#include <stdio.h>
#include <stdarg.h>
#include <time.h>
#include <assert.h>
#ifdef _WIN32
//#include <tchar.h>
#include <windows.h>
//#else
//	#ifdef _UNICODE
//		typedef wchar_t	TCHAR
//	#else
//		typedef char	TCHAR
//	#endif
#endif

using namespace std;

class CLogFile
{
public:
	CLogFile(TCHAR* file)
	{
		m_pLog = NULL;
		StartLog(file);
		_tcscpy(m_tszFileName, file);
	}
	CLogFile()
	{
		m_pLog = NULL;
		StartLog(_T("D:\\Log_ReadMdict.txt"));
		_tcscpy(m_tszFileName, _T("D:\\Log.txt"));
	}

	virtual ~CLogFile(void)
	{
		fclose(m_pLog);
	};

private:
	FILE* m_pLog;
	TCHAR m_tszFileName[260];

private:
	//DISALLOW_COPY_AND_ASSIGN(CLogFile);

	void StartLog(TCHAR* pFilePath)
	{
		m_pLog = _tfopen(pFilePath, _T("w"));
		//_tfopen_s(&m_pLog, pFilePath, _T("w+"));
		assert(m_pLog);
		LogTime();
	}

public:

	void GetName(TCHAR* name)
	{
		_tcscpy(name, m_tszFileName);
	}

	TCHAR* GetName()
	{
		return m_tszFileName;
	}

    //Display operating system-style date and time
	void LogTime()
	{
		wchar_t datebuf[128];
		wchar_t timebuf[128];

		_wstrdate(datebuf);
		_wstrtime(timebuf);
		LogOut(_T("OS time:\t%s\t%s\n\n"), datebuf, timebuf);
	}

	void LogOut(const wchar_t* wString, ...)
	{
		assert(m_pLog);

		wchar_t wBuffer[4096];
		va_list pArgList;

		// The va_start macro (defined in STDARG.H) is usually equivalent to:
		// pArgList = (char *) &szFormat + sizeof (szFormat) ;

		va_start(pArgList, wString);

		// The last argument to wvsprintf points to the arguments

		int n = sizeof(wBuffer) / sizeof(wchar_t);

		_vsnwprintf(wBuffer, sizeof(wBuffer) / sizeof(wchar_t),
			wString, pArgList);

		// The va_end macro just zeros out pArgList for no good reason

		va_end(pArgList);

#ifdef _WIN32
		OutputDebugStringW(wBuffer);
		//OutputDebugStringW(_T("\n"));
#else

#endif

#ifdef UNICODE
		_wsetlocale(0, _T("chs")); //������ϣ�����fwprintf�����Ĳ�֧��
#endif
		fwprintf(m_pLog, wBuffer);
		//fwprintf(m_pLog, _T("\n"));

		fflush(m_pLog);
	}

	void LogOut(const char* szString, ...)
	{
		assert(m_pLog);

		char szBuffer[1024];
		va_list pArgList;

		// The va_start macro (defined in STDARG.H) is usually equivalent to:
		// pArgList = (char *) &szFormat + sizeof (szFormat) ;

		va_start(pArgList, szString);

		// The last argument to wvsprintf points to the arguments
	
		_vsnprintf(szBuffer, sizeof(szBuffer) / sizeof(char),
			szString, pArgList);

		// The va_end macro just zeroes out pArgList for no good reason

		va_end(pArgList);

#ifdef _WIN32
		OutputDebugStringA(szBuffer);
		//OutputDebugStringA("\n");
#else

#endif
		//_twsetlocale(0,T"chs"); //������ϣ�����fwprintf�����Ĳ�֧��

		fprintf(m_pLog, szBuffer);
		//fprintf(m_pLog, "\n");

		fflush(m_pLog);
	}
};

//extern CLogFile theLogFile;
extern bool g_bDebug;
extern CLogFile* g_pLogFile; //= &theLogFile;

//for debuging
#define LOGORNOT	\ g_bDebug && m_bDebug
#define LOGORNOT2	\ g_bDebug && bDebug

#define BGNLOG		\
	bool m_bDebug = true;

#define ENDLOG		\
	bool m_bDebug = false;

//#define LOGMSG		\
//	if(g_bDebug && m_bDebug) theLogFile.LogOut
#define LOGMSG		\
	if(g_bDebug && m_bDebug) g_pLogFile->LogOut
	
//#define LOGOUT theLogFile.LogOut
#define LOGOUT g_pLogFile->LogOut

#define LOGFUNBGN		\
	m_bDebug = true;		\
	if(g_bDebug && m_bDebug) {	\
		LOGOUT(__FUNCTION__);		\
		LOGOUT("\nLine: %d", __LINE__);		\
		LOGOUT(_T(" is to start.\n"));	\
	}

#define LOGFUNEND		\
	if(g_bDebug && m_bDebug) {	\
		LOGOUT(__FUNCTION__);	\
		LOGOUT(_T(" is finished.\n"));		\
	}

#define LOGFUNMSG		\
	if(g_bDebug) {		\
		LOGOUT(__FUNCTION__);	\
		LOGOUT("\nLine: %d", __LINE__);		\
		LOGOUT("\n");		\
	}
	
#define LOGINFO(tInfo, ...)	\
	if(g_bDebug && m_bDebug) {	\
		LOGOUT("INFO:\t");	\
		LOGOUT(tInfo, ## __VA_ARGS__);		\
		LOGOUT("\n");		\
	}

#define LOGERR(tErr, ...)\
	if(g_bDebug && m_bDebug) {	\
		LOGOUT("ERROR:\t");	\
		LOGOUT(tErr, ## __VA_ARGS__);	\
		LOGOUT("\n");	\
	}

#define LOGOK(tOK, ...)	\
	if(g_bDebug && m_bDebug) {	\
		LOGOUT("OK:\t");		\
		LOGOUT(tOK, ## __VA_ARGS__);		\
		LOGOUT("\n\n");		\
	}

#endif//!__LOGFILE__H__