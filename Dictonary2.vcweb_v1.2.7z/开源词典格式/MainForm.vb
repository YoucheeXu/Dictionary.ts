﻿Imports System
Imports System.Windows.Forms
Imports System.Security.Permissions
Imports System.Speech
Imports System.IO.File
Imports System.Runtime.InteropServices
Imports System.Xml
Imports System.Text.RegularExpressions
'<PermissionSet(SecurityAction.Demand, Name:="FullTrust")> _
'<PermissionSet(SecurityAction.LinkDemand, Name:="FullTrust")> _
'<System.Runtime.InteropServices.ComVisibleAttribute(True)> _
<ComVisibleAttribute(True)> _
<ClassInterfaceAttribute(ClassInterfaceType.AutoDispatch)> _
<DockingAttribute(DockingBehavior.AutoDock)> _
<PermissionSetAttribute(SecurityAction.InheritanceDemand, Name:="FullTrust")> _
<PermissionSetAttribute(SecurityAction.LinkDemand, Name:="FullTrust")> _
Public Class MainForm

    Property mSkinPath() As String = Application.StartupPath + "\Skin\"
    Property mDictPath() As String = Application.StartupPath + "\Dict\"
    Property mXMLPath() As String = Application.StartupPath + "\XML\"
    Property mDataPath() As String = Application.StartupPath + "\Data\"
    Property mAudioPath() As String = Application.StartupPath + "\Audio\"
    Property mAudioPath_EN() As String = mAudioPath + "EN\"
    Property mAudioPath_US() As String = mAudioPath + "US\"

    Property mNumNewwords() As Integer
    Property mResult() As Boolean = False
    Property mWdVoice() As New Speech.Synthesis.SpeechSynthesizer

    Property mVOADict() As CDataBase1
    Property mBasicDict3() As CDataBase3

    Property mFocus As Boolean
    Property mMore As Boolean
    Property mWord As String = ""
    Property mUrl As String = ""
    Private Property mVoice As Boolean

    Private Const HTCAPTION As Integer = &H2&
    Private Const WM_NCLBUTTONDOWN As Integer = &HA1&
    <DllImport("user32")> _
    Private Shared Function SendMessageA(ByVal hWnd As Integer, ByVal wMsg As Integer, ByVal wParam As Integer, ByVal lParam As Integer) As Integer
    End Function
    <DllImport("user32")> _
    Private Shared Function ReleaseCapture() As Integer
    End Function
    ''' <summary>
    ''' 移动窗口
    ''' </summary>
    ''' <param name="handle">移动窗口的句柄</param>
    ''' <remarks></remarks>
    Public Shared Sub WindowMove(ByVal handle As Integer)
        ReleaseCapture()
        SendMessageA(handle, WM_NCLBUTTONDOWN, HTCAPTION, &H0&)
    End Sub
    Private Sub MainForm_MouseDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles MyBase.MouseDown
        WindowMove(Me.Handle)
    End Sub
    Private Sub MainForm_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Me.Height = 551
        Me.Width = 701
        Me.BackColor = Color.FromArgb(67, 160, 255)

        'Panel_Input.BackColor = Color.FromArgb(9934743)
        'Panel_Input.BackColor = Color.FromArgb(240, 240, 240)
        Panel_Input.BackgroundImage = System.Drawing.Bitmap.FromFile(mSkinPath + "combox_bk.bmp")
        Panel_Input.BackgroundImageLayout = ImageLayout.Center

        Panel_Bottom.BackColor = Color.FromArgb(64, 132, 238)
        'Panel_Bottom.BackgroundImage = System.Drawing.Bitmap.FromFile(mSkinPath + "top_middle.bmp")

        txtCaption.BackColor = Color.Transparent
        BtnMenu.LoadImage(mSkinPath + "menu_btn.bmp", 31, 21)
        BtnMin.LoadImage(mSkinPath + "minimize_btn.bmp", 33, 21)
        BtnClose.LoadImage(mSkinPath + "close_btn.bmp", 43, 21)
        BtnLookup.LoadImage(mSkinPath + "lookup_btn.bmp", 110, 37)

        BtnPrev.LoadImage(mSkinPath + "prev_btn.bmp", 45, 37)
        BtnNxt.LoadImage(mSkinPath + "next_btn.bmp", 40, 37)
        BtnDrop.LoadImage(mSkinPath + "combobox_drop_btn.bmp", 20, 34)
        BtnDel.LoadImage(mSkinPath + "delete_item.bmp", 30, 34)
        BtnDel.Visible = False

        BtnNewword.LoadImage(mSkinPath + "newword_btn.bmp", 75, 22)

        Panel_Edit.BackColor = Color.FromArgb(255, 255, 255)
        Panel_Edit.BackgroundImage = System.Drawing.Bitmap.FromFile(mSkinPath + "combox_bk.bmp")

        '禁止用户用鼠标改变窗体大小
        Me.FormBorderStyle = Windows.Forms.FormBorderStyle.None

        With WordListBox
            .Width = 135
            .Height = 421
            .Hide()
        End With

        With DataWebBrowser
            .Left = 1
            .Width = 699
            .Height = 421
            .Navigate(mDataPath + "FrontPage\index.html")
            .AllowWebBrowserDrop = False
            .IsWebBrowserContextMenuEnabled = False
            .WebBrowserShortcutsEnabled = True
            .ObjectForScripting = Me
        End With

        DataWebBrowser.Update()
        Me.Update()

        mVOADict = New CDataBase1
        mVOADict.LoadDict(mDictPath + "VOA.dict")

        mBasicDict3 = New CDataBase3
        mBasicDict3.LoadDict(mDictPath + "basic2.dict")

        mFocus = True
    End Sub
    Private Sub MainForm_Shown(sender As Object, e As EventArgs) Handles MyBase.Shown
        WordTxtBox.Select()
        WordTxtBox.Focus()
    End Sub
    Private Sub MainForm_FormClosing(ByVal sender As System.Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        mVOADict.UnloadDict()
        mBasicDict3.UnloadDict()
    End Sub
    Private Sub WordTxtBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles WordTxtBox.TextChanged
        Dim url_path As String = mDataPath
        Dim word As String = WordTxtBox.Text.Trim.ToLower
        Dim l = word.Length
        If l > 0 Then
            If Asc(word.Substring(l - 1)) < Asc("a") Or Asc(word.Substring(l - 1)) > Asc("z") Then
                word = word.Substring(0, l - 1)
                WordTxtBox.Text = word
                WordTxtBox.SelectionStart = word.Length
            End If
        End If
        mWord = word
        l = word.Length
        If l > 0 Then
            BtnDel.Visible = True
            WordListBox.Show()
            url_path = url_path + "ResultPage\index.html"
            With DataWebBrowser
                .Width = 699 - 135
                .Left = 136
            End With
            mResult = True
            Dim wordlist As String = ""
            If mBasicDict3.GetWordList(word, wordlist) Then
                WordListBox.Items.Clear()
                Dim wdlst() As String = wordlist.Split("@")
                For Each wd In wdlst
                    If wd IsNot Nothing Then
                        WordListBox.Items.Add(wd)
                    End If
                Next
                WordListBox.SetSelected(0, True)
                mWord = WordListBox.Items(0)
            End If
        Else
            BtnDel.Visible = False
            WordListBox.Hide()
            With DataWebBrowser
                .Left = 1
                .Width = 699
            End With
            url_path = url_path + "FrontPage\index.html"
            mResult = False
        End If

        mUrl = url_path
        DataWebBrowser.Navigate(url_path)

        DataWebBrowser.Update()
        Me.Update()
    End Sub
    Private Sub WordListBox_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles WordListBox.Click
        Dim url_result As String = mSkinPath + "ResultHtml\result.html"
        WordTxtBox.Text = WordListBox.SelectedItem().ToString()
        mWord = WordTxtBox.Text
        DataWebBrowser.Navigate(url_result)
    End Sub
    Private Sub WordListBox_DoubleClick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles WordListBox.DoubleClick
        WordTxtBox.Text = WordListBox.SelectedItem().ToString()
        ListMore()
    End Sub
    Private Sub DataWebBrowser_DocumentCompleted(ByVal sender As System.Object, ByVal e As System.Windows.Forms.WebBrowserDocumentCompletedEventArgs) Handles DataWebBrowser.DocumentCompleted
        If mResult = False Then Return
        Dim symbol As String = ""
        Dim def As String = ""
        Dim sent As String = ""
        Dim more As String = ""
        Dim bSucess As Boolean = False

        If mMore Then
            Dim ret As Integer = QueryDict3(mWord, symbol, def, sent)
            Select Case ret
                Case -1
                Case -2
                    QueryDict3(mWord, symbol, def, sent)
            End Select
            Dim bNew As Boolean = (mBasicDict3.GetNew(mWord) = -1)
            more = GetMore(mWord, symbol, def, sent, bNew)
        Else
            more = "<DIV class=lcDownDetail>" + _
                            "<SPAN><IMG src='images/downdetail.png'></SPAN>" + _
                            "<SPAN><A class=asTextColor href='app:detail:" + WordTxtBox.Text + "' target=_self>点击查看更多解释</A></SPAN>" + _
                        "</DIV "
        End If

        symbol = ""
        def = ""
        sent = ""

        Dim main_Item As HtmlElement = DataWebBrowser.Document.GetElementById("main")
        If main_Item = Nothing Then Return
        If mMore = False Then
            Dim ct As String = ""
            QueryDict1(mWord, symbol, ct)
            main_Item.InnerHtml = "<div class=main>" + _
                                    "<div class = 'dict_title'>" + _
                                        "<div class='title' id='current_word'><h1>" + mWord + "</h1></div>" + _
                                    "</div>" + _
                                    "<div class = 'dict_content'>" + _
                                        "<DIV class = 'explain'>" + _
                                            ct + _
                                        "</DIV>" + _
                                    "</div>" + _
                                    more + _
                                "</div>"
        Else
            main_Item.InnerHtml = "<div class=main>" + _
                                more + _
                                "</div>"
            mMore = False
        End If
        If DataWebBrowser.ReadyState = WebBrowserReadyState.Complete Then
            DataWebBrowser.Document.Body.AttachEventHandler("ondblclick", AddressOf DataWebBrowser_OnDoubleClick)
        End If
        If mFocus Then
            WordTxtBox.Focus()
            mFocus = False
        End If
    End Sub
    Public Sub OnAddDelWord(ByVal bNew As Integer)
        Dim word As String = WordListBox.Items(0)
        If bNew = 1 Then
            mNumNewwords += 1
        Else
            mNumNewwords -= 1
        End If
        mBasicDict3.UpdateNew(word, bNew)
        WordTxtBox.Select()
    End Sub
    Private Sub DataWebBrowser_OnDoubleClick()
        Dim oDOM As mshtml.IHTMLDocument2 = DataWebBrowser.Document.DomDocument
        'WordTxtBox.Text = oDOM.selection.createRange.htmlText.ToString.ToLower.Trim
        WordTxtBox.Text = oDOM.selection.createRange.Text.ToString.ToLower.Trim
        Me.WordTxtBox_TextChanged(Me, New System.EventArgs)
    End Sub
    Public Sub OnHoverSpeech(ByVal wd As String, ByVal us As Boolean)
        If wd IsNot Nothing Then
            Dim voice As String = ""

            If us = False Then
                voice = mAudioPath_EN + wd.Trim + ".mp3"
            Else
                voice = mAudioPath_US + wd.Trim + ".mp3"
            End If

            If System.IO.File.Exists(voice) = False Then
                If DownloadAudio(wd) = False Then
                    mWdVoice.Speak(wd)
                    Return
                End If
            End If
            AxWindowsMediaPlayer1.URL = voice
            AxWindowsMediaPlayer1.Ctlcontrols.play()
        End If
    End Sub
    Private Function QueryDict1(ByVal wd As String, ByRef smb As String, ByRef ct As String) As Boolean
        Dim n As Integer = 0
        Dim def As String = ""
        Dim sent As String = ""
        smb = ""
        If mVOADict.ExistWord(wd) Then
            def = mVOADict.GetDefinition()
            sent = mVOADict.GetSentence()
            Dim deflst() As String = def.Split("@")
            Dim sentlst() As String = sent.Split("@")
            For i = 1 To deflst.Length - 1
                ct = ct + "<DIV class=pos>" + i.ToString + "." + deflst(i - 1) + "</DIV> " + "<DIV class=pos>&nbsp;&nbsp;" + sentlst(i - 1) + "</DIV> "
            Next
        End If
        Return True
    End Function
    Private Function QueryDict3(ByVal wd As String, ByRef smb As String, ByRef def As String, ByRef sent As String) As Integer
        Dim mp3path_EN As String = ""
        Dim mp3path_US As String = ""
        Dim xmlPath As String = "http://dict-co.iciba.com/api/dictionary.php?w=" & wd.Trim
        Dim xmlFile As String = mXMLPath + wd.Trim + ".xml"
        Dim bFound As Boolean = False
        Dim S_XmlReader As XmlReader
        Dim i As Integer = 0
        smb = ""
        def = ""
        sent = ""
        wd = wd.Trim
        Try
            If mBasicDict3.ExistWord(wd) Then
                smb = mBasicDict3.GetSymbol()
                def = mBasicDict3.GetDefinition()
                sent = mBasicDict3.GetSentence()

            ElseIf SystemInformation.Network And mMore Then
                Dim pos As String = ""
                Dim myWebClient = New System.Net.WebClient

                If System.IO.File.Exists(xmlFile) = False Then
                    myWebClient.DownloadFile(New Uri(xmlPath), xmlFile)
                End If
                If System.IO.File.Exists(xmlFile) = True Then
                    Dim S_XmlReader2 As XmlReader
                    Dim settings As New XmlReaderSettings()
                    settings.ConformanceLevel = ConformanceLevel.Fragment
                    settings.IgnoreWhitespace = True
                    settings.IgnoreComments = True
                    S_XmlReader = XmlReader.Create(xmlFile, settings)
                    While S_XmlReader.Read()
                        If S_XmlReader.NodeType = XmlNodeType.Element Then
                            Select Case S_XmlReader.Name
                                Case "ps"
                                    smb = smb + S_XmlReader.ReadString() + "&"
                                    bFound = True
                                Case "pron"
                                    i = i + 1
                                    If i = 1 Then
                                        mp3path_EN = S_XmlReader.ReadString()
                                        bFound = True
                                    Else
                                        mp3path_US = S_XmlReader.ReadString()
                                    End If

                                Case "pos"
                                    pos = S_XmlReader.ReadString()
                                Case "acceptation"
                                    def = def + pos + S_XmlReader.ReadString()
                                Case "sent"
                                    S_XmlReader2 = S_XmlReader
                                    S_XmlReader2.ReadSubtree()
                                    While S_XmlReader2.Read()
                                        If S_XmlReader.NodeType = XmlNodeType.Element Then
                                            Select Case S_XmlReader2.Name
                                                Case "orig"
                                                    sent = sent + S_XmlReader2.ReadString()
                                                Case "trans"
                                                    sent = sent + S_XmlReader2.ReadString()
                                            End Select
                                        End If
                                    End While
                                    S_XmlReader2.Close()
                            End Select
                        End If
                    End While
                End If

                If bFound Then
                    If smb.Length > 1 Then
                        smb = smb.Remove(Len(smb) - 1)
                    End If
                    sent = sent.Trim
                    sent = sent.Replace(vbLf + vbLf, vbLf)
                    mBasicDict3.InsertContent(wd, smb, def, sent, True)
                    Dim voiceFile_EN As String = mAudioPath_EN + wd.Trim + ".mp3"
                    Dim voiceFile_US As String = mAudioPath_US + wd.Trim + ".mp3"
                    If System.IO.File.Exists(voiceFile_EN) = False And mp3path_EN.Length > 4 Then
                        If mp3path_EN.Substring(mp3path_EN.Length - 4, 4) = ".mp3" Then
                            myWebClient.DownloadFile(New Uri(mp3path_EN), voiceFile_EN)
                        End If
                    End If
                    If System.IO.File.Exists(voiceFile_US) = False And mp3path_US.Length > 4 Then
                        If mp3path_US.Substring(mp3path_US.Length - 4, 4) = ".mp3" Then
                            myWebClient.DownloadFile(New Uri(mp3path_US), voiceFile_US)
                        End If
                    End If
                Else
                    def = "Not Found!"
                    sent = ""
                    S_XmlReader.Close()
                    System.IO.File.Delete(xmlFile)
                    Return -1
                End If
            End If

            def = def.Replace(vbLf, "<BR>")
            sent = sent.Replace(vbLf, "<BR>")

            Call OnHoverSpeech(wd, True)
        Catch ex As Exception
            If S_XmlReader IsNot Nothing Then
                S_XmlReader.Close()
            End If
            If System.IO.File.Exists(xmlFile) = True Then
                Dim xml As String = System.IO.File.ReadAllText(xmlFile, System.Text.Encoding.UTF8)
                xml = Regex.Replace(xml, "<([^a-z>]+)>", "&lt;$1&gt;")
                xml = xml.Replace("&", "&amp;")
                System.IO.File.WriteAllText(xmlFile, xml)
            End If
            def = "Try Again!"
            Return -2
        End Try

        Return 1
    End Function
    Private Function GetMore2(ByVal wd As String, ByVal symbol As String, ByVal def As String, ByVal sent As String, ByVal bnew As Boolean) As String
        If symbol <> Nothing Then
            Dim symbols() As String = symbol.Split("&")
            Dim sound_EN As String =
                "<SPAN class='symbol' id=voice0 style='MARGIN-LEFT: 5px; VERTICAL-ALIGN: middle' qvalue='" + wd + "' onclick=onVoice(this,0); >" + _
                "<IMG style='CURSOR:hand' src='images/Voice_1.png'" + _
                "onmouseup=""this.src='images/Voice_1.png'"" onmousedown=""this.src='images/Voice_2.png'""/>" + _
                "</SPAN>"
            Dim sound_US As String =
                "<SPAN class='symbol' id=voice0 style='MARGIN-LEFT: 5px; VERTICAL-ALIGN: middle' qvalue='" + wd + "' onclick=onVoice(this,1); >" + _
                "<IMG style='CURSOR:hand' src='images/Voice_1.png'" + _
                "onmouseup=""this.src='images/Voice_1.png'"" onmousedown=""this.src='images/Voice_2.png'""/>" + _
                "</SPAN>"
            If symbols.Length > 1 Then
                symbol = "[英][" + symbols(0) + "]" + sound_EN + "  [美][" + symbols(1) + "]" + sound_US
            Else
                symbol = "[" + symbols(0) + "]" + sound_US
            End If
        End If

        Dim strAddDelWord As String = "<IMG id=delWord src='images/delete_word.png' alt ='mark as old'>"

        If bnew = False Then
            strAddDelWord = "<IMG id=addWord src='images/add_word.png' alt ='mark as new'>"
        End If
        Return "<div class='title' id='current_word'><h1>" + wd + "</h1></div>" + _
                "<div class='prons'>" + symbol + _
                     "<SPAN style='MARGIN-LEFT: 5px; VERTICAL-ALIGN: middle;CURSOR:hand' onclick=addDelWord(this);>" + _
                    strAddDelWord + _
                "</div>" + _
                "<DIV class='dict_content'>" + _
                    "<DIV class='explain'>" + def + "</DIV>" + _
                    "<DIV class='sample'>" + sent + "</DIV>" + _
                "</DIV>"
    End Function
    Private Function GetMore(ByVal wd As String, ByVal symbol As String, ByVal def As String, ByVal sent As String, ByVal bnew As Boolean) As String
        If symbol <> Nothing Then
            Dim symbols() As String = symbol.Split("&")
            Dim sound_EN As String =
                "<SPAN class='symbol' id=voice0 style='MARGIN-LEFT: 5px; VERTICAL-ALIGN: middle' qvalue='" + wd + "' onclick=onVoice(this,0); >" + _
                "<IMG style='CURSOR:hand' src='images/Voice_1.png'" + _
                "onmouseup=""this.src='images/Voice_1.png'"" onmousedown=""this.src='images/Voice_2.png'""/>" + _
                "</SPAN>"
            Dim sound_US As String =
                "<SPAN class='symbol' id=voice0 style='MARGIN-LEFT: 5px; VERTICAL-ALIGN: middle' qvalue='" + wd + "' onclick=onVoice(this,1); >" + _
                "<IMG style='CURSOR:hand' src='images/Voice_1.png'" + _
                "onmouseup=""this.src='images/Voice_1.png'"" onmousedown=""this.src='images/Voice_2.png'""/>" + _
                "</SPAN>"
            If symbols.Length > 1 Then
                symbol = "[英][" + symbols(0) + "]" + sound_EN + "  [美][" + symbols(1) + "]" + sound_US
            Else
                symbol = "[" + symbols(0) + "]" + sound_US
            End If
        End If

        Dim strAddDelWord As String = "<IMG id='delWord' src='images/delete_word.png' alt ='mark as old'>"

        If bnew = False Then
            strAddDelWord = "<IMG id = 'addWord' src='images/add_word.png' alt ='mark as new'>"
        End If
        Return "<div class = 'dict_title'>" + _
                    "<div class='title' id='current_word'><h1>" + wd + "</h1></div>" + _
                    "<div class='prons'>" + symbol + _
                      "<SPAN style='MARGIN-LEFT: 5px; VERTICAL-ALIGN: middle;CURSOR:hand' onclick=addDelWord(this);>" + _
                        strAddDelWord + "</SPAN>" + _
                    "</div>" + _
                "</div>" + _
                "<div class = 'dict_content'>" + _
                    "<div class = 'explain'>" + _
                        def + _
                    "</div>" + _
                    "<div class = 'sample'>" + _
                        sent + _
                    "</div>" + _
                "</div>"
    End Function
    Private Sub ListMore()
        WordTxtBox.Text = WordTxtBox.Text.Trim.ToLower
        If WordTxtBox.Text.Length <= 1 Then Return
        mMore = True
        mFocus = True
        mResult = True
        mWord = WordTxtBox.Text
        WordListBox.Hide()
        With DataWebBrowser
            .Left = 1
            .Width = 699
            .Update()
        End With
        WordTxtBox.SelectAll()
        DataWebBrowser.Navigate(mDataPath + "ResultPage\index.html")
    End Sub
    Private Function DownloadAudio(wd As String) As Boolean
        Dim mp3path_EN As String = ""
        Dim mp3path_US As String = ""
        Dim xmlPath As String = "http://dict-co.iciba.com/api/dictionary.php?w=" & wd.Trim
        Dim xmlFile As String = mXMLPath + wd.Trim + ".xml"
        Dim S_XmlReader As XmlReader
        Dim i As Integer = 0

        wd = wd.Trim
        Try
            If System.IO.File.Exists(xmlFile) = False Then
                If SystemInformation.Network And mMore Then
                    Dim pos As String = ""
                    Dim myWebClient = New System.Net.WebClient

                    myWebClient.DownloadFile(New Uri(xmlPath), xmlFile)
                Else
                    Return False
                End If
            End If

            If System.IO.File.Exists(xmlFile) = True Then
                Dim settings As New XmlReaderSettings()
                settings.ConformanceLevel = ConformanceLevel.Fragment
                settings.IgnoreWhitespace = True
                settings.IgnoreComments = True
                S_XmlReader = XmlReader.Create(xmlFile, settings)
                While S_XmlReader.Read()
                    If S_XmlReader.NodeType = XmlNodeType.Element Then
                        Select Case S_XmlReader.Name
                            Case "pron"
                                i = i + 1
                                If i = 1 Then
                                    mp3path_EN = S_XmlReader.ReadString()
                                Else
                                    mp3path_US = S_XmlReader.ReadString()
                                End If
                        End Select
                    End If
                End While
            End If

            If SystemInformation.Network Then
                Dim myWebClient = New System.Net.WebClient
                Dim voiceFile_EN As String = mAudioPath_EN + wd.Trim + ".mp3"
                Dim voiceFile_US As String = mAudioPath_US + wd.Trim + ".mp3"
                Dim voiceFile As String = mAudioPath + wd.Trim + ".mp3"

                If i = 1 Then

                    If System.IO.File.Exists(voiceFile) = False And mp3path_EN.Length > 4 Then
                        If mp3path_EN.Substring(mp3path_EN.Length - 4, 4) = ".mp3" Then
                            myWebClient.DownloadFile(New Uri(mp3path_EN), voiceFile)
                        End If
                    End If

                Else
                    If System.IO.File.Exists(voiceFile_EN) = False And mp3path_EN.Length > 4 Then
                        If mp3path_EN.Substring(mp3path_EN.Length - 4, 4) = ".mp3" Then
                            myWebClient.DownloadFile(New Uri(mp3path_EN), voiceFile_EN)
                        End If
                    End If
                    If System.IO.File.Exists(voiceFile_US) = False And mp3path_US.Length > 4 Then
                        If mp3path_US.Substring(mp3path_US.Length - 4, 4) = ".mp3" Then
                            myWebClient.DownloadFile(New Uri(mp3path_US), voiceFile_US)
                        End If
                    End If
                End If

                If System.IO.File.Exists(voiceFile_US) = False Then
                    Return False
                End If

            Else
                Return False
            End If

        Catch ex As Exception
            S_XmlReader.Close()
            'MessageBox.Show(ex.ToString)
            If System.IO.File.Exists(xmlFile) = True Then
                Dim xml As String = System.IO.File.ReadAllText(xmlFile, System.Text.Encoding.UTF8)
                'Dim expression As New Regex("<[^a-z]+>")
                xml = Regex.Replace(xml, "<([^a-z>]+)>", "&lt;$1&gt;")
                xml = xml.Replace("&", "&amp;")
                System.IO.File.WriteAllText(xmlFile, xml)
            End If
            Return False
        End Try

        Return True
    End Function
    Private Sub WordTxtBox_KeyDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles WordTxtBox.KeyDown
        If e.KeyCode = Keys.Enter Then
            ListMore()
        End If
        If e.Shift = True Then
            If e.KeyCode = Keys.Delete Then
                Call DelCurrentWord()
                e.Handled = True
            End If
        End If
    End Sub
    Private Sub ToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolStripItemClickedEventArgs) Handles MenuStrip.ItemClicked
        Select Case e.ClickedItem().ToString()
            Case "Always Top"
           
            Case "&Edit Word"

            Case "&Delete Word"
                DelCurrentWord()
            Case Else
        End Select
        WordTxtBox.Select()
    End Sub
    Private Sub ToolStrip2MenuItem_Click(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolStripItemClickedEventArgs) Handles NewToolStripMenuItem.DropDownItemClicked
        Select Case e.ClickedItem().ToString()
            Case "New &Word"
                NewWordForm.ShowDialog(Me)
            Case "New E&xplain"
                NewContentForm.ShowDialog(Me)
        End Select
    End Sub
    Private Sub BtnMenu_Click(sender As Object, e As EventArgs) Handles BtnMenu.Click
        Me.MenuStrip.Show(Me.Location.X + BtnMenu.Location.X, Me.Location.Y + BtnMenu.Location.Y + 30)
    End Sub
    Private Sub BtnMin_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnMin.Click
        Me.WindowState = FormWindowState.Minimized
    End Sub
    Private Sub BtnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnClose.Click
        Me.Close()
    End Sub
    Private Sub BtnDel_Click(sender As System.Object, e As System.EventArgs) Handles BtnDel.Click
        WordTxtBox.Text = ""
    End Sub
    Private Sub BtnNewword_Click(sender As Object, e As EventArgs) Handles BtnNewword.Click
        frmNewWords.ShowDialog()
    End Sub
    Private Sub BtnLookup_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnLookup.Click
        ListMore()
    End Sub
    Private Sub DelCurrentWord()
        mBasicDict3.DelWord(mWord)  'delete word from dictory database
        System.IO.File.Delete(mXMLPath + mWord + ".xml") 'delete xml file
        System.IO.File.Delete(mAudioPath_EN + mWord + ".mp3") 'delete audio file
        System.IO.File.Delete(mAudioPath_US + mWord + ".mp3") 'delete audio file
        System.IO.File.Delete(mAudioPath + mWord + ".mp3") 'delete audio file
        MsgBox(mWord + " was deleted!")
        WordTxtBox.Text = ""
    End Sub
End Class
