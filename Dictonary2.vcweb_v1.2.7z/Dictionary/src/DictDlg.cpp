//DictDlg.cpp
#include "stdafx.h"
#include "DictApp.h"

#include "resource.h"
#include "IniFile.h"
//#include "BmpButton.h"
//#include "EventSink.h"
//#include "DictWebBrowser.h"
//#include "Mp3.h"
#include "GDictBase.h"
#include "Mp3Player.h"
#include <wininet.h>
#define ERR_MSG_LEN 512
#define BUFFER_LEN  256
#pragma comment( lib, "wininet.lib" )
//#include "InternetSever.h"
#include "DictDlg.h"

#pragma warning(disable:4127) // Conditional expression is constant

CLogFile theLogFile;

CDictDlg::CDictDlg(UINT nResID) : CDialog(nResID)
{
	m_bDebug = true;
	TCHAR tszIniPath[MAX_PATH], tszLogPath[MAX_PATH], tszTmpPath[MAX_PATH];
	//_tcscpy(m_tszCfgPath, thePlugin.GetPluginsConfigDir());

	GetModuleFileName(NULL, m_tszAppPath, MAX_PATH); //�õ���ǰģ��·��
	(_tcsrchr(m_tszAppPath, _T('\\')))[0] = 0;

	_stprintf(tszIniPath, _T("%s%s"), m_tszAppPath, _T("\\Data\\Dictionary.ini"));
	
	m_pIniFile = new CIniFile(tszIniPath);

	g_bDebug = m_pIniFile->GetBool(_T("Debug"), _T("Enable"));
	if (g_bDebug)
	{
		m_pIniFile->GetString(_T("Debug"), _T("file"), tszLogPath);
		//g_pLogFile->StartLog(tszAppPath);
		//theLogFile.StartLog(tszAppPath);
		LOGINFO(_T("LogDir: %s"), tszLogPath);
	}
	LOGFUNBGN;
	
	_stprintf(m_tszDataPath, _T("%s%s"), m_tszAppPath, _T("\\Data\\"));
	_stprintf(m_tszDictPage, _T("%s%s"), m_tszDataPath, _T("Query\\dict.html"));

	m_pIniFile->GetString(_T("GUI"), _T("Skin"), tszTmpPath);

	_stprintf(m_tszSkinPath, _T("%s%s"), m_tszAppPath, tszTmpPath);

	_stprintf(m_tszDictPath, _T("%s%s"), m_tszAppPath, _T("\\Dict"));
	
	_stprintf(m_tszAudioPath, _T("%s%s"), m_tszAppPath, _T("\\Audio"));

	//if m_pIniFile->GetInteger("Agent"), "Agent") = 1
	//{
	//	mIsAgent = true
	//	mProxyProgram = m_pIniFile->GetString("Agent"), "program")
	//	mProxyName = m_pIniFile->GetString("Agent"), "Name")
	//else
	//	mIsAgent = false
	//}

	m_bAgent = m_pIniFile->GetBool(_T("Agent"), _T("Agent"));

	if (true == m_bAgent)
	{
		m_pIniFile->GetString(_T("Agent"), _T("ip"), tszTmpPath);
		_stprintf(m_tszProxyAddress, _T("%s%s"), _T("HTTP=http://"), tszTmpPath);
		//TCHAR tszProxyAddress[] = _T("HTTP=HTTP://127.0.0.1:8087");
	}

	m_bMore = false;
	m_nDictTimer = 100;

	//m_pBmpCombox_bk = NULL;
	m_pDCCombox_bk = NULL;
	
	m_pMp3Player = new CMp3Player();
}

CDictDlg::~CDictDlg()
{
	m_pGDict->Unload();
	delete m_pIniFile;
	delete m_pGDict;
	//delete m_pInternetSever;
	delete m_pMp3Player;

	//if (m_hBmpCombox_bk != NULL) ::DeleteObject(m_hBmpCombox_bk);
	//if (m_pBmpCombox_bk != NULL) delete m_pBmpCombox_bk;
	//m_pDCCombox_bk->Destroy();
	if (m_pDCCombox_bk != NULL) delete m_pDCCombox_bk;

	Destroy(); // to be sure GetHwnd() returns NULL
	//delete m_pWebBrowser;
}

BOOL CDictDlg::OnInitDialog()
{
	// Set the Icon
	SetIconLarge(IDI_MAIN);
	SetIconSmall(IDI_MAIN);
	
	//InitOptions();

	BuildFromFile(_T("haha"));

	//m_webBrowser.Update();
	//Me.Update();

	//'m_tszWordDict = new CDataBase;
	//'m_tszWordDict.LoadDict(mDictPath + _T("word.dict"));

	//'mVOADict = new CDataBase1;
	//'mVOADict.LoadDict(mDictPath + _T("VOA.dict"));

	//'mPWDict = new CDataBase3;
	//'mPWDict.LoadDict(mDictPath + _T("pw.dict"));

	m_pGDict = new CGDictBase(this);
	m_pGDict->Load(m_tszDictPath, m_tszAudioPath);

	//m_pInternetSever = new CInternetSever();

	//mFocus = true;

	//MainTimer.Interval = 2000;
	
	//ConnectEvents();

	m_hMainMenu = LoadMenu(GetDialogApp().GetInstanceHandle(), MAKEINTRESOURCE(IDM_MAINMENU));
	m_hMainMenu = GetSubMenu(m_hMainMenu, 0);

	OnSize(true);

	SetWindowText(_T("Dictionary2"));

	//m_edtWord.SetFocus();
	FocusEditWord();

	return TRUE;
}

//TODO:
//void CDictDlg::OnEidtWord_KeyDown
BOOL CDictDlg::PreTranslateMessage(MSG* pMsg)
{
	if (WM_KEYDOWN == pMsg->message)
	{
		switch (pMsg->wParam)
		{
		case VK_RETURN:
			KillTimer(m_nDictTimer);
			//ListMore();
			QueryMore(m_edtWord.GetWindowText().c_str());
			//return TRUE;
			break;
		case VK_DELETE:
			tString word = m_edtWord.GetWindowText().c_str();
			BOOL ret = FALSE;
			if (::GetKeyState(VK_SHIFT) < 0)
			{
				//'Call OnDelJSON(m_edtWord.Text, false);
				ret = m_pGDict->DelWord(word.c_str());
				m_edtWord.SetWindowText(_T(""));
				tString retJ = TRUE == ret ? _T("Dict was deleted!") : _T("Dict was not deleted!");
				MessageBox(retJ.c_str(), word.c_str(), MB_OK);
			}
			else if (::GetKeyState(VK_CONTROL) < 0)
			{
				m_edtWord.SetWindowText(_T(""));
				ret = m_pGDict->DelAudio(word.c_str());
				tString retA = TRUE == ret ? _T("Audio was deleted!\n") : _T("Audio not deleted!\n");
				ret = m_pGDict->DelWord(word.c_str());
				tString retJ = TRUE == ret ? _T("Dict was deleted!") : _T("Dict was not deleted!");
				MessageBox((retA + retJ).c_str(), word.c_str(), MB_OK);
			}
			break;
		}
	}
	//else if (WM_LBUTTONDOWN == pMsg->message)
	//{
	//	::ReleaseCapture();

	//}
	return CDialog::PreTranslateMessage(pMsg);
}

INT_PTR CDictDlg::DialogProc(UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	//LOGMSG(_T("DialogProc: %d."), uMsg);
	switch (uMsg)
	{
		case WM_INITDIALOG:
			return OnInitDialog();

		case WM_SIZE:
			OnSize();
			break;

		//case WM_NOTIFY:
		//	NMHDR* pnmh = (NMHDR*) lParam;
		//	if (pnmh->hwndFrom == )
		//	{
		//		if (LOWORD(pnmh->code) == DMN_CLOSE)
		//		{
		//			::SendMessage(, NPPM_SETMENUITEMCHECK, 
		//				funcItem[0]._cmdID, FALSE);
		//			return 0;
		//		}
		//	}
		//	break;
		case WM_LBUTTONDOWN:
			::ReleaseCapture();
			SendMessage(WM_NCLBUTTONDOWN, HTCAPTION, 0);
			break;

		case WM_MOUSEMOVE:
			//m_btnLookup.OnMouseMove(wParam, lParam);
			break;
		
		case WM_TIMER:
			OnTimer((UINT_PTR)lParam);
			break;

		//case WM_CTLCOLORDLG:
		case WM_CTLCOLORSTATIC:
			/*CDC* pDC = CDC::FromHandle((HDC)wParam);
			CWnd* pWnd = CWnd::FromHandle((HWND)lParam);*/
			UINT nCtlColor = uMsg - 0x0132;
			//return (INT_PTR)OnCtlColor(pDC, pWnd, nCtlColor);
			HWND hWnd = (HWND)lParam;
			return (INT_PTR)OnCtlColor((HDC)wParam, hWnd, nCtlColor);
	}

	return DialogProcDefault(uMsg, wParam, lParam);
}

void CDictDlg::OnSize(bool bInitial)
{
	if (bInitial)
	{
		CRect r = GetWindowRect();
		//::MoveWindow(GetHwnd(), 0, 0, m_opt.getInt(OPT_VIEW_WIDTH), r.Height(), TRUE);
		return;
	}

	CRect r = GetClientRect();
	const int width = r.Width();
	const int height = r.Height();
	const int left = 2;
	int top = 1;

	//// toolbar
	//r = mToolBar.GetWindowRect();
	//::MoveWindow(mToolBar, left, top, width - 2*left, r.Height(), TRUE);
	//top += (r.Height() + 1);
}

//
BOOL CDictDlg::OnCommand(WPARAM wParam, LPARAM lParam)
{
	switch (LOWORD(wParam))
	{
		case IDB_MENU:
			OnMenuClicked();
			break;
		case IDB_MIN:
			ShowWindow(SW_MINIMIZE);
			break;
		case IDB_CLOSE:
			PostQuitMessage(0);
			break;

		case IDB_DEL:
			m_edtWord.SetWindowText(_T(""));
			FocusEditWord();
			break;

		case IDB_LOOKUP:
			QueryMore(m_edtWord.GetWindowText().c_str());
			break;
			
		case IDC_EDIT_WORD:
			if(EN_CHANGE == HIWORD(wParam))
				OnEidtWord_TextChanged();
			break;
	};
	
	// Handle notification WM_COMMAND from CEdit
	if((HWND)lParam == m_lstWords.GetHwnd())
	{
		switch(HIWORD(wParam))
		{
		case CBN_SELCHANGE:
			// User made selection from list
			{
				// Get text from edit box
				//tString str = m_edtWord.GetWindowText();

				// Navigate to web page
				//m_View.Navigate(str);
				//QueryWord(str.c_str());
				OnWordsLstBoxItemClicked();
			}
			return TRUE;
		};
	};
	return FALSE;
}

LRESULT CDictDlg::OnNotify(WPARAM wParam, LPARAM lParam)
{
	//LOGMSG(_T("Notify: %d."), ((LPNMHDR)lParam)->code);
	switch (((LPNMHDR)lParam)->code)
	{
	case LVN_COLUMNCLICK:
		//SetSortMode((eTagsSortMode) (TSM_NAME + ((LPNMLISTVIEW) lParam)->iSubItem));
		break;

	case LVN_ITEMACTIVATE:
		break;

	case TVN_SELCHANGED:
		break;

	case NM_DBLCLK:
		if (IDC_LSTB_WORDS == LOWORD(wParam))
			OnWordsLstBoxItemDBClicked();
		break;

	case NM_CLICK:
		if (IDC_LSTB_WORDS == LOWORD(wParam))
			OnWordsLstBoxItemClicked();
		break;
	}
	return 0;
}

//HBRUSH CDictDlg::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor)
HBRUSH CDictDlg::OnCtlColor(HDC hDC, HWND hWnd, UINT nCtlColor)
{
	//LOGMSG(_T("CDictDlg::OnMessageReflect: %d."), nCtlColor);
	//HDC hdcStatic = (HDC)wParam;
	CDC* pDC = new CDC(hDC);
	//CDC* pDC = GetApp().GetCDCFromMap(hDC);

	//CWnd* pWnd = new CWnd();
	bool tmpWnd = false;

	CWnd* pWnd = GetCWndPtr(hWnd);
	if (NULL != hWnd && 0 == pWnd)
	{
		pWnd = new CWnd();
		pWnd->Attach(hWnd);
		tmpWnd = true;
		//return 0L;
	}

	switch (nCtlColor)
	{
	case CTLCOLOR_STATIC:
		//pWnd->Attach(hWnd);
		switch (pWnd->GetDlgCtrlID())
		{
		case IDT_CAPTION:
			//SetTextColor(hdcStatic, RGB(255, 0, 0));
			pDC->SetTextColor(RGB(0, 0, 0));
			//SetBkMode(hdcStatic, TRANSPARENT); //�������屳��Ϊ͸��
			pDC->SetBkMode(TRANSPARENT); //�������屳��Ϊ͸��
			// TODO: Return a different brush if the default is not desired
			return (HBRUSH)::GetStockObject(HOLLOW_BRUSH);  // ���ñ���ɫ
			//if (hbrBkgnd == NULL)
			//{
			//	hbrBkgnd = CreateSolidBrush(RGB(0, 0, 0));
			//}
			//return (INT_PTR)hbrBkgnd;
			//case IDC_PANEL_INPUT:
			//	pDC->SetBkColor(RGB(255, 255, 255));   //���屳��ɫ 
			//	return (HBRUSH)::GetStockObject(WHITE_BRUSH);
		}
	case CTLCOLOR_DLG:
		//pDC->SetTextColor(RGB(0, 0, 0));
		//pDC->SetBkColor(RGB(166, 254, 1));
		RECT rect;
		rect.left = 1;
		rect.top = 22;
		rect.right = 1 + 499;
		rect.bottom = 22 + 38;
		pDC->SolidFill(RGB(255, 255, 255), rect);
		//return CreateSolidBrush(RGB(67, 160, 255));
		return (HBRUSH)::GetStockObject(NULL_BRUSH);
	}

	pDC->Detach();
	delete pDC;

	if (true == tmpWnd) {
		pWnd->Detach();
		delete pWnd;
	}

	return 0L;
}

void CDictDlg::OnMenuClicked()
{
	DWORD dwPos = GetMessagePos();
	CPoint point(LOWORD(dwPos), HIWORD(dwPos));

	TrackPopupMenu(m_hMainMenu, TPM_LEFTBUTTON, point.x, point.y, 0, this->GetHwnd(), NULL);
}

//?
void CDictDlg::OnWordsLstBoxItemClicked()
{
	KillTimer(m_nDictTimer);
	int iItem = m_lstWords.GetCurSel();
	TCHAR tszWord[20];
	m_lstWords.GetText(iItem, tszWord);

	//tString tUrl = m_tszDataPath;
	//tUrl = tUrl + _T("Query\\dict.html");
	////m_webBrowser.Navigate(tUrl.c_str());
	//m_webBrowser.QueryWord(tszWord, tUrl.c_str());
	QueryMore(tszWord);
}

//?
void CDictDlg::OnWordsLstBoxItemDBClicked()
{
	KillTimer(m_nDictTimer);
	int iItem = m_lstWords.GetCurSel();
	TCHAR tszWord[20];
	m_lstWords.GetText(iItem, tszWord);
	//ListMore();
	QueryMore(tszWord);
}

void CDictDlg::OnDestroy()
{
	// End the application
	::PostQuitMessage(0);
}

void CDictDlg::BuildFromFile(const TCHAR* file)
{
	tString tmpPath;
	m_nHeight = m_pIniFile->GetInteger(_T("GUI"), _T("Height"));
	m_nWidth = m_pIniFile->GetInteger(_T("GUI"), _T("Width"));
	//Me.BackColor = Color.FromArgb(67, 160, 255);

	////��ֹ�û������ı䴰���С
	//Me.FormBorderStyle = Windows.Forms.FormBorderStyle.None;

	//AttachItem(IDB_MENU, m_txtCaption);
	//txtCaption.BackColor = Color.Transparent;

	AttachItem(IDB_MENU, m_btnMenu);
	tmpPath = m_tszSkinPath;
	tmpPath = tmpPath + _T("menu_btn.bmp");
	m_btnMenu.Init(tmpPath, 560, 1, 31, 21, true);

	//mHFunMenu = LoadMenu(thePlugin.GetInstanceHandle(), MAKEINTRESOURCE(IDM_FUNCTION_CONTENTITEM));
	//mHFunMenu = GetSubMenu(mHFunMenu, 0);

	AttachItem(IDB_MIN, m_btnMin);
	tmpPath = m_tszSkinPath;
	tmpPath = tmpPath + _T("minimize_btn.bmp");
	m_btnMin.Init(tmpPath, 591, 1, 33, 21, true);

	AttachItem(IDB_MAX, m_btnMax);
	tmpPath = m_tszSkinPath;
	tmpPath = tmpPath + _T("maxmize_btn.bmp");
	m_btnMax.Init(tmpPath, 624, 1, 33, 21, true);

	// AttachItem(IDB_RESTORE, m_btnRestore);
	// tmpPath = tmpPath + _T("restore_btn.bmp");
	// m_btnRestore.Init(tmpPath, 624, 1, 33, 21, true);

	AttachItem(IDB_CLOSE, m_btnClose);
	tmpPath = m_tszSkinPath;
	tmpPath = tmpPath + _T("close_btn.bmp");
	m_btnClose.Init(tmpPath, 657, 1, 43, 21, true);
	//m_btnClose.MoveWindow(103, 63, 428, 26);

	AttachItem(IDB_PREV, m_btnPrev);
	tmpPath = m_tszSkinPath;
	tmpPath = tmpPath + _T("prev_btn.bmp");
	m_btnPrev.Init(tmpPath, 11, 49, 45, 37, false);
	m_btnPrev.EnableWindow(FALSE);

	AttachItem(IDB_NEXT, m_btnNext);
	tmpPath = m_tszSkinPath;
	tmpPath = tmpPath + _T("next_btn.bmp");
	m_btnNext.Init(tmpPath, 56, 49, 40, 37, false);
	m_btnNext.EnableWindow(FALSE);

	//CFont font;
	//font.CreatePointFont(200, _T("������κ"), NULL);
	//m_fontEdit.CreateFont(30, 0, 0, 0, FW_NORMAL, FALSE, FALSE, 0,
	//	ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, 
	//	DEFAULT_QUALITY, DEFAULT_PITCH | FF_SWISS, _T("Arial"));

	LOGFONT _logfont;
	memset(&_logfont, 0, sizeof(_logfont));
	_logfont.lfHeight = 30;
	_logfont.lfWeight = 0;
	_logfont.lfQuality = CLEARTYPE_QUALITY;
	_logfont.lfPitchAndFamily = FF_DONTCARE;
	_tcscpy(_logfont.lfFaceName, _T("Arial"));

	m_fontEdit.CreateFontIndirect(&_logfont);

	AttachItem(IDC_EDIT_WORD, m_edtWord);
	m_edtWord.MoveWindow(99, 52, 400, 30);
	m_edtWord.SetFocus();
	m_edtWord.SetForegroundWindow();
	m_edtWord.SetFont(m_fontEdit);

	AttachItem(IDB_DEL, m_btnDel);
	tmpPath = m_tszSkinPath;
	tmpPath = tmpPath + _T("delete_item.bmp");
	m_btnDel.Init(tmpPath, 527, 50, 30, 34, true);
	m_btnDel.ShowWindow(SW_HIDE);

	AttachItem(IDB_DROP, m_btnDrop);
	tmpPath = m_tszSkinPath;
	tmpPath = tmpPath + _T("combobox_drop_btn.bmp");
	m_btnDrop.Init(tmpPath, 557, 50, 20, 34, true);
	m_btnDrop.ShowWindow(SW_SHOWNORMAL);
	//m_btnDrop.EnableWindow(FALSE);

	//AttachItem(IDC_PANEL_INPUT, m_panelInput);
	//'m_panelInput.BackColor = Color.FromArgb(9934743)
	//'m_panelInput.BackColor = Color.FromArgb(240, 240, 240)
	tmpPath = m_tszSkinPath;
	tmpPath = tmpPath + _T("combox_bk.bmp");
	HBITMAP hBmpCombox_bk = (HBITMAP)LoadImage(NULL,  //Ӧ�ó���ʵ��
	tmpPath.c_str(),     //·��
	IMAGE_BITMAP,
	0,        //�������0,��˲���ָ��bitmap�Ŀ�(λͼ������)
	0,        //�������0,��˲���ָ��bitmap�ĸ�(λͼ������)
	LR_LOADFROMFILE | LR_CREATEDIBSECTION | LR_DEFAULTSIZE);
	//m_panelInput.SetBitmap(m_hBmpCombox_bk);
	// m_panelInput.MoveWindow(96, 49, 481, 37);
	//m_panelInput.SetWindowPos((CWnd*)&m_btnDrop, 96, 49, 481, 37, SWP_NOACTIVATE);
	//m_panelInput.SetWindowPos((CWnd*)&m_btnDel, 96, 49, 481, 37, SWP_NOACTIVATE);
	//m_panelInput.SetWindowPos((CWnd*)&m_edtWord, 96, 49, 481, 37, SWP_NOACTIVATE);
	//m_panelInput.BackgroundImageLayout = ImageLayout.Center

	if (hBmpCombox_bk != NULL)
	{
		//m_pBmpCombox_bk = new CBitmap(hBmpCombox_bk);
		m_pDCCombox_bk = new CDC();
		//HDC hScrDC = CreateCompatibleDC(NULL);  //�����ڴ��豸������
		//SelectObject(hScrDC, m_hBmpCombox_bk);
		//m_pDCCombox_bk = CDC::FromHandle(hScrDC);
		BOOL bRet = m_pDCCombox_bk->CreateCompatibleDC(NULL);
		//m_pDCCombox_bk->SelectObject(m_pBmpCombox_bk);
		m_pDCCombox_bk->SelectObject(hBmpCombox_bk);
	}

	AttachItem(IDB_LOOKUP, m_btnLookup);
	tmpPath = m_tszSkinPath;
	tmpPath = tmpPath + _T("lookup_btn.bmp");
	m_btnLookup.Init(tmpPath, 577, 49, 110, 37, true);

	AttachItem(IDC_LSTB_WORDS, m_lstWords);
	m_lstWords.MoveWindow(1, 92, 135, 416);
	m_lstWords.ShowWindow(SW_HIDE);
	m_lstWords.SetFont(m_fontEdit);

	//m_pWebBrowser =  new CDictWebBrowser(this);	
	//AttachItem(IDC_WB_DATA, *m_pWebBrowser);
	m_webBrowser.AttachDlgItem(IDC_WB_DATA, this->GetHwnd());

	m_webBrowser.SetLeft(1);
	m_webBrowser.SetWidth(m_nWidth - 2);
	m_webBrowser.SetHeight(421);
	m_webBrowser.MoveWindow(1, 92, m_nWidth - 2, 416);

	//m_webBrowser.GetIWebBrowser2()->put_Silent(VARIANT_TRUE);

	// Navigate to the home page
	tmpPath = m_tszDataPath;
	tmpPath = tmpPath + _T("FrontPage\\index.html");
	m_webBrowser.Navigate(tmpPath.c_str());
	m_webBrowser.ConnectEvents();
	
	//Panel_Bottom.BackColor = Color.FromArgb(64, 132, 238);
	//'Panel_Bottom.BackgroundImage = System.Drawing.Bitmap.FromFile(tmpPath + _T("top_middle.bmp");

	//tmpPath = m_tszSkinPath;
	//tmpPath = tmpPath + _T("beidanci.bmp");
	//m_btnBeidanci.Init(tmpPath, 540, y, 75, 25);	
	
	//tmpPath = m_tszSkinPath;
	//tmpPath = tmpPath + _T("newword_btn.bmp");
	//m_btnNewword.Init(tmpPath, 619, y, 75, 25);
	int w = GetSystemMetrics(SM_CXSCREEN);
	int h = GetSystemMetrics(SM_CYSCREEN);
	MoveWindow(w / 2 - m_nWidth / 2, h / 2 - m_nHeight/2, m_nWidth, m_nHeight);
}

//TODO:
void CDictDlg::OnEidtWord_TextChanged()
{
	tString tUrl = m_tszDataPath;
	tUrl = tUrl + _T("FrontPage\\index.html");
	tString tWord = m_edtWord.GetWindowText();
	StringTrim(tWord);

	int l = tWord.length();
	if (l > 0)
	{
		//int asccode = toascii(tWord.substr(l - 1, 1));
		int asccode = toascii(tWord[l-1]);
		if (!((asccode >= toascii('a') && asccode <= toascii('z')) || (asccode <= toascii('Z') && asccode >= toascii('A'))))
		{
			tWord = tWord.substr(0, l - 1);
			m_edtWord.SetWindowText(tWord.c_str());
			//m_edtWord.SelectionStart = tWord.Length();
		}
	}
	//_tcscpy(m_tszWord, tWord.c_str());
	//Trace("TextChanged: " + m_tszWord);
	l = tWord.length();
	if (l > 0)
	{
		m_btnDel.ShowWindow(SW_SHOW);
		m_lstWords.ShowWindow(SW_SHOW);
		m_lstWords.ResetContent();

		// MainTimer.Stop();
		// MainTimer.Enabled = false;
		// MainTimer.Enabled = true;
		// MainTimer.Start();
		KillTimer(m_nDictTimer);
		SetTimer(m_nDictTimer, 5000, NULL);
		
		// 'tUrl = tUrl + "ResultPage\index.html"\
		// 'tUrl = m_tszDataPath + "FrontPage\index.html"
		// 'tUrl = "http://dict.cn/mini.php?q=" & m_tszWord.Trim

		/*m_webBrowser.SetLeft(136);
		m_webBrowser.SetWidth(460 - 135);*/
		//m_webBrowser.MoveWindow(1, 87, m_nWidth - 2, 421);
		m_webBrowser.MoveWindow(136, 87, m_nWidth - 2 - 136, 421);

		//mResult = true;
		tString tFindWord;
		bool bFind = m_pGDict->GetWordList(tWord.c_str(), tFindWord);

		while (true == bFind)
		{
			SendDlgItemMessage(IDC_LSTB_WORDS, LB_ADDSTRING, 0, (LPARAM)tFindWord.c_str());
			bFind = m_pGDict->GetWordList(tWord.c_str(), tFindWord);
		}
		m_lstWords.SetSel(0, true);
	}
	else
	{
		m_btnDel.ShowWindow(SW_HIDE);
		m_lstWords.ShowWindow(SW_HIDE);

		//m_webBrowser.SetLeft(1);
		//m_webBrowser.SetWidth(460);
		//m_webBrowser.MoveWindow(1, 95, m_nWidth - 2, 420);
		m_webBrowser.MoveWindow(1, 87, m_nWidth - 2, 421);
		//'tUrl = m_tszDataPath + "FrontPage\index.html";
		//mResult = false;
		//m_webBrowser.QueryWord(_T(""), tUrl.c_str());
		m_webBrowser.Navigate(tUrl.c_str());
	}

	//mUrl = tUrl;
	//'m_webBrowser.Navigate(tUrl)

	//m_webBrowser.Update();
}

//TODO: wait to test
bool CDictDlg::OnSaveHtml(tString html)
{
	tString htmlfile = m_tszDataPath;
	htmlfile = htmlfile + _T("query\\");
	//htmlfile = htmlfile + m_tszWord;
	htmlfile = htmlfile + _T("newhtml");
	htmlfile = htmlfile + _T(".html");
	FILE* pFile = _tfopen(htmlfile.c_str(), _T("w+"));
	
	_fputts(html.c_str(), pFile);
	
	// close file
	if(fclose(pFile) != -1)
	{
		pFile = NULL;
		return true;
	}
	else
	{
		return false;
	}
}
	
void CDictDlg::OnHoverSpeech(tString wd, bool isUs)
{
	if(false == wd.empty())
	{
		tString voicefile;

		if (false == m_pGDict->GetAudioPath(wd.c_str(), isUs, voicefile)) return;
		
		m_pMp3Player->Load(voicefile.c_str());
		m_pMp3Player->Play();
		// AxWindowsMediaPlayer1.URL = voicefile;
		// AxWindowsMediaPlayer1.Ctlcontrols.play();
	}
}

/* void CDictDlg::DataWebBrowser_OnDoubleClick()
// {
	// mshtml.IHTMLDocument2 oDOM= m_webBrowser.Document.DomDocument;
	// //'m_edtWord.Text = oDOM.selection.createRange.htmlText.ToString.ToLower.Trim
	// m_edtWord.SetWindowText(oDOM.selection.createRange.Text.ToString.ToLower.Trim);
	// this->EditWord_TextChanged();
}*/

void CDictDlg::QueryMore(tString tWord)
{
	// if (!PrevInstance(mProxyName, false) && m_bAgent)
		//{
		// System.Diagnostics.Process.Start(mProxyProgram)
			//if( (int)(LRESULT)::ShellExecute(NULL, _T("open"), szUrl, NULL, NULL, SW_SHOWNORMAL ) > 32)
	// }
	// m_pGDict->QueryWrod(m_tszWord, mIsAgent)
	//_tcslen(m_edtWord.GetWindowText())
	//m_edtWord.Text = m_edtWord.Text.Trim
	//if (m_edtWord.Text.Length) <= 1 return

	//if (true == bDefault) tWord = m_edtWord.GetWindowText();

	StringTrim(tWord);
	if(tWord.size() <= 1) return;
	m_bMore = true;
	KillTimer(m_nDictTimer);
	//mFocus = true;
	//mResult = true;
	//m_tszWord = m_edtWord.GetWindowText();
	m_edtWord.SetWindowText(tWord.c_str());
	m_lstWords.ShowWindow(SW_HIDE);
	// m_lstWords.EnableWindow(FALSE);
	/*m_webBrowser.SetLeft(1);
	m_webBrowser.SetWidth(699);*/
	m_webBrowser.MoveWindow(1, 87, m_nWidth - 2, 421);
	//m_webBrowser.MoveWindow(1, 95, m_nWidth - 2, 420);

	m_edtWord.SetSel(0, -1, TRUE);	//select all
	FocusEditWord();
	//m_webBrowser.Navigate(m_tszDataPath + _T("Query\\dict.html"));

	if (false == m_pGDict->QueryWrod(tWord.c_str())) return;

	m_webBrowser.QueryWord(tWord.c_str(), m_tszDictPage);
}

void CDictDlg::FocusEditWord()
{
	//m_edtWord.SetSel(0, -1, TRUE);	//select all
	m_edtWord.SetFocus();
}

void CDictDlg::OnTimer(UINT_PTR nIDEvent)
{
	// MainTimer.Stop();
	// MainTimer.Enabled = false;
	if (nIDEvent != m_nDictTimer) return;
	KillTimer(nIDEvent);
	//Trace("TimerTick: " + m_tszWord);
	tString tWord = m_edtWord.GetWindowText();
	tString tUrl = _T("http://dict.cn/mini.php?q=");
	tUrl = tUrl + tWord;
	//m_webBrowser.Navigate(tUrl.c_str());
	m_webBrowser.QueryWord(tWord.c_str(), tUrl.c_str());
}

//work in synchronous mode
bool CDictDlg::DownloadFile(tString url, tString file)
{
	/*// bool isAgent = m_pIniFile->GetBool(_T("Agent"), _T("Agent"));
	// if(true == isAgent)
	// {
		// TCHAR tszProxyAddress[MAX_PATH];
		// m_pIniFile->GetString(_T("Agent"), _T("ip"), tszProxyAddress);
		// _stprintf(tszProxyAddress, _T("%s%s"), _T("http:\\"), tszProxyAddress);
	
		// httpURL = new System.Uri(url);
		// WebRequest myWebRequest = WebRequest.Create(httpURL);

		// //' Create a new Uri object.

		// myProxy = new WebProxy();
		// newUri = new Uri(m_tProxyAddress);
		// //' Associate the new Uri object to the myProxy object.
		// myProxy.Address = newUri;

		// //' Create a NetworkCredential object and is assign to the Credentials property of the Proxy object.
		// myProxy.Credentials = new NetworkCredential("", "");
		// myWebRequest.Proxy = myProxy;
	// }

	// try
	// {
		// WebResponse myWebResponse = myWebRequest.GetResponse();
		// Stream streamResponse = myWebResponse.GetResponseStream();

		// //'streamRead new StreamReader(streamResponse)
		// //'html = streamRead.ReadToEnd()
		// //'readBuff(256) [Char]
		// readBuff(2048)[Byte];
		// int count = streamResponse.Read(readBuff, 0, 256);
		// fs FileStream = new FileStream(file, FileMode.Create);

		// While count > 0
			// fs.Write(readBuff, 0, count);
			// count = streamResponse.Read(readBuff, 0, 256);
		// End While

		// //' Close the Stream object.
		// streamResponse.Close();
		// fs.Close();
		// //'streamRead.Close()
		// //' Release the HttpWebResponse Resource.
		// myWebResponse.Close();
	// }
	// catch (std::exception &e)
	// {
		// // Process the exception and quit 
		// e.what();
		// return false;
	// }
	 return true;*/

	BGNLOG;

	BYTE szOutputBuffer[BUFFER_LEN];
	DWORD dwDownloadedBytes = 0;
	FILE *pFile = NULL;
	HINTERNET hSession = NULL;
	HINTERNET handle2 = NULL;
	//TCHAR* tszText = GetWindowText();
	
	//bool isAgent = m_pIniFile->GetBool(_T("Agent"), _T("Agent"));
	bool bRet = false;
	try
	{
		if(true == m_bAgent)
		{
			//TCHAR tszProxyAddress[MAX_PATH];
			//m_pIniFile->GetString(_T("Agent"), _T("ip"), tszProxyAddress);
			//_stprintf(tszProxyAddress, _T("%s%s"), _T("HTTP\=http\:\/\/"), tszProxyAddress);
			//TCHAR tszProxyAddress[] = _T("HTTP=HTTP://127.0.0.1:8087");
			//_stprintf(tszIniPath, _T("%s%s"), m_tszAppPath, _T("\\Data\\Dictionary.ini"));

			hSession = InternetOpen(GetWindowText().c_str(), //User Agent
						INTERNET_OPEN_TYPE_PROXY,	// Preconfig or Proxy
						m_tszProxyAddress,	// Proxy name
						NULL,		// Proxy bypass, do not bypass any address
						0);		// 0 for Synchronous
		}
		else
		{
			hSession = InternetOpen(GetWindowText().c_str(), //application name
						INTERNET_OPEN_TYPE_PRECONFIG,	// Use configuration as IE
						NULL, NULL, 0);
		}

		if (hSession != NULL)
		{
			handle2 = InternetOpenUrl(hSession, (LPCWSTR)url.c_str(), NULL, 0,
				INTERNET_FLAG_NO_CACHE_WRITE | 	// Does not add the returned entity to the cache.
				INTERNET_FLAG_TRANSFER_BINARY | // 
				INTERNET_FLAG_RELOAD,	// Forces a download of the requested file, object, or directory listing from the origin server, not from the cache.
				0);
			if (handle2 != NULL)
			{
				if((pFile = _tfopen(file.c_str(), _T("wb+"))) != NULL)
				{
					do
					{
						BOOL bSuccess = InternetReadFile(handle2, szOutputBuffer, sizeof(szOutputBuffer), &dwDownloadedBytes);
						if(false == bSuccess)
						{
							DWORD dwError = GetLastError();
							if(ERROR_IO_PENDING == dwError)
							{
								LOGINFO(_T("Waiting for InternetReadFile to complete."));
							}
							else
							{
								LogInetError(dwError, _T("InternetReadFile"));
							}
						}
						else
						{
							if (0 == dwDownloadedBytes) break;  // no data was received.
							fwrite(szOutputBuffer, sizeof(BYTE), dwDownloadedBytes, pFile);
						}
					} while (true);

					//fflush(pFile);
					fclose(pFile);
				}
				InternetCloseHandle(handle2);
				handle2 = NULL;
			}
			else
			{
				LogInetError(GetLastError(), _T("InternetOpenUrl"));
			}
			InternetCloseHandle(hSession);
			hSession = NULL;
		}
		else
		{
			LogInetError(GetLastError(), _T("InternetOpen"));
		}
	}
	catch (std::exception &e)
	{
		// Process the exception and quit 
		e.what();
		return false;
	}
	return true;
}

//void CDictDlg::OnDraw(CDC* pDC)
void CDictDlg::OnDraw(CDC& dc)
{
	CDC* pDC = &dc;
	//CPaintDC dc(this);
	CRect rect = GetClientRect();
	pDC->SolidFill(RGB(67, 160, 255), rect);   //���ñ���

	rect.left = rect.left + 1;
	rect.top = rect.top + 37;
	rect.right = rect.right - 1;
	rect.bottom = rect.top + 62;
	pDC->SolidFill(RGB(240, 240, 240), rect);
	
	if (m_pDCCombox_bk != NULL){
		//pDC->SetStretchBltMode(STRETCH_HALFTONE);
		BOOL bRet = pDC->StretchBlt(96, 49, 481, 37, m_pDCCombox_bk->GetHDC(), 0, 0, 1, 37, SRCCOPY);
		//BOOL bRet = pDC->BitBlt(96, 49, 481, 37, m_pDCCombox_bk->GetHDC(), 0, 0, SRCCOPY);
		if (FALSE == bRet) LOGERR("m_pDCCombox_bk failed!");
	}
}

// This routine is used to log WinInet dwErrors in human readable form.
// Arguments:
// dwErr - dwError number obtained from GetLastdwError()
// tszMsgEx - tszMsgExing pointer holding caller-context information
// Return Value: None.
VOID LogInetError(
	__in DWORD dwErr,
	__in LPCTSTR tszMsgEx)
{
	DWORD dwResult;
	PWSTR tszMsgBuffer = NULL;
	bool m_bDebug = true;

	//dwResult = FormatMessage(FORMAT_MESSAGE_ALLOCATE_BUFFER |
	//                       FORMAT_MESSAGE_FROM_HMODULE,
	//                       GetModuleHandle(_T("wininet.dll")),
	//                       dwErr,
	//                       MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
	//                       (LPWSTR)&tszMsgBuffer,
	//		   ERR_MSG_LEN,
	//                       NULL);

	dwResult = FormatMessage(
		FORMAT_MESSAGE_ALLOCATE_BUFFER |
		FORMAT_MESSAGE_FROM_SYSTEM |
		FORMAT_MESSAGE_IGNORE_INSERTS,
		NULL,
		dwErr,
		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
		(LPTSTR)&tszMsgBuffer,
		0, NULL);

	if (dwResult)
	{
		//fprintf(stderr, "%ws: %ws\n", tszMsgEx, tszMsgBuffer);
		LOGMSG(_T("%ws: %ws."), tszMsgEx, tszMsgBuffer);
		LocalFree(tszMsgBuffer);
	}
	else
	{
		LOGMSG(_T("Error %d while formatting message for %d in %ws."), GetLastError(), dwErr, tszMsgBuffer);
	}
	return;
}