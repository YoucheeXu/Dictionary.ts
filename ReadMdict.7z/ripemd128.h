//ripemd128.h
/*
// follows this description: http://homes.esat.kuleuven.be/~bosselae/ripemd/rmd128.txt
reference of https://github.com/zhansliu/writemdict

bug to fix:
while origlen> 56 or origlen < -64, Pad_Split(...) will do wrong
*/


#ifndef _RIPEMD128_H_
#define _RIPEMD128_H_

#pragma warning (disable: 4996)
#include"stdafx.h"
#include <stdio.h>
#include <stdarg.h>
#include <cassert>
#ifdef _WIN32
//#include <tchar.h>
#include <windows.h>
#include "LogFile.h"
typedef unsigned long  uLong; /* 32 bits or more */
#endif

class CRipemd128 {
public:
	CRipemd128(){}
	~CRipemd128(){}

private:	
	uLong f(int j, uLong x, uLong y, uLong z) {
		assert(0 <= j && j < 64);
		if (j < 16) return x ^ y ^ z;
		else if (j < 32) return (x & y) | (z & ~x);
		else if (j < 48) return (x | (0xffffffff & ~y)) ^ z;
		else return (x & z) | (y & ~z);
	}

	uLong K(int j) {
		assert(0 <= j && j < 64);
		if (j < 16) return 0x00000000;
		else if (j < 32) return 0x5a827999;
		else if (j < 48) return 0x6ed9eba1;
		else return 0x8f1bbcdc;
	}

	uLong Kp(int j) {
		assert(0 <= j && j < 64);
		if (j < 16) return 0x50a28be6;
		else if (j < 32) return 0x5c4dd124;
		else if (j < 48) return 0x6d703ef3;
		else return 0x00000000;
	}

	void Pad_Split(BYTE* message, int origlen) {
		/*
		returns a two-dimensional array X[i][j] of 32-bit integers, where j ranges
		from 0 to 16.
		First pads the message to length in bytes is congruent to 56 (mod 64), 
		by first adding a byte 0x80, and then padding with 0x00 bytes until the
		message length is congruent to 56 (mod 64). Then adds the little-endian
		64-bit representation of the original length. Finally, splits the result
		up into 64-byte blocks, which are further parsed as 32-bit integers.
		*/

		//int rem = ((origlen - 56) % 64);
		int rem = 0;

		if (-64 < origlen < 56) rem = 64 + (origlen - 56);
		else {
			LOGERR("can't calculate ((%d - 56) % 64)", origlen);
			assert(0);
		}

		int padlength = 64 - rem; // #minimum padding is 1!
		
		uLong newmsg_len = origlen + padlength + 8;
		BYTE* newmsg = new BYTE[newmsg_len];
		
		memcpy(newmsg, message, origlen);

		newmsg[origlen] = 0x80;

		for(int i = 0; i < padlength; i++){
			newmsg[origlen + 1 + i] = 0x00;
		}
		
		//Q: unsigned long long, <: little-endian
		//message += struct.pack("<Q", origlen*8);
		unsigned long long len = origlen * 8;
		BYTE* value = (BYTE*)&len;
		for(int i = 0; i < 8; i++){
			newmsg[origlen + padlength + i] = value[i];
		}

		_msg_arr_Col = newmsg_len/64;
		_msg_arr = new uLong[newmsg_len/4];
		for (int i = 0; i < newmsg_len/4; i++) {
			_msg_arr[i] = 0;
			for (int j = 0; j < 4; j++){

				_msg_arr[i] += newmsg[i*4+j]<<(8*j);
			}
		}
		
		delete [] newmsg;
	}

	uLong add(const int num, ...) {

		uLong result = 0;

		va_list pArgList;

		// The va_start macro (defined in STDARG.H) is usually equivalent to:
		// pArgList = (char *) &szFormat + sizeof (szFormat) ;
		
		va_start(pArgList, num);

		for (int i = 0; i < num; i++)  {

			result += va_arg(pArgList, uLong);
		}

		// The va_end macro just zeroes out pArgList for no good reason

		va_end(pArgList);
		
		return result;
	}

	uLong rol(int s, uLong x) {
		assert(s < 32);
		return (x << s | x >> (32-s)) & 0xffffffff;
	}

	int32_t swapInt32(int32_t value)
	{
		return ((value & 0x000000FF) << 24) |
			((value & 0x0000FF00) << 8) |
			((value & 0x00FF0000) >> 8) |
			((value & 0xFF000000) >> 24);
	}

	static const int r[64];
	static const int rp[64];
	static const int s[64];
	static const int sp[64];

public:
	void Checksum(BYTE* message, int len, uLong* key) {
		uLong h0 = 0x67452301;
		uLong h1 = 0xefcdab89;
		uLong h2 = 0x98badcfe;
		uLong h3 = 0x10325476;
		Pad_Split(message, len);

		for(int i = 0; i < _msg_arr_Col; i++)	{

			uLong A = h0;
			uLong B = h1;
			uLong C = h2;
			uLong D = h3;
			uLong Ap = h0;
			uLong Bp = h1;
			uLong Cp = h2;
			uLong Dp = h3;
			uLong T = 0;
			//for j in range(64){
			for(int j = 0; j < 64; j++)	{
				T = rol(s[j], add(4, A, f(j, B, C, D), _msg_arr[i + r[j]], K(j)));
				//LOGINFO("T1 = %X", T);
				A = D; D = C; C = B; B = T;
				T = rol(sp[j], add(4, Ap, f(63-j, Bp, Cp, Dp), _msg_arr[i + rp[j]], Kp(j)));
				//LOGINFO("T2 = %X", T);
				Ap = Dp; Dp = Cp; Cp = Bp; Bp = T;
			}
			T = add(3, h1, C, Dp);
			h1 = add(3, h2, D, Ap);
			h2 = add(3, h3, A, Bp);
			h3 = add(3, h0, B, Cp);
			h0 = T;
		}
		
		delete [] _msg_arr;
		
		//return struct.pack("<LLLL", h0, h1, h2, h3);
		//BYTE result[16];

		//key[3] = swapInt32(h3);
		//key[2] = swapInt32(h2);
		//key[1] = swapInt32(h1);
		//key[0] = swapInt32(h0);

		key[3] = h3;
		key[2] = h2;
		key[1] = h1;
		key[0] = h0;
	}
	
private:
	uLong* _msg_arr;
	UINT _msg_arr_Col; 
	bool m_bDebug = true;
	// def hexstr(bstr){
		// return "".join("{0:02x}".format(b) for b in bstr);
	// }
};

const int CRipemd128::r[64] = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15,
7, 4, 13, 1, 10, 6, 15, 3, 12, 0, 9, 5, 2, 14, 11, 8,
3, 10, 14, 4, 9, 15, 8, 1, 2, 7, 0, 6, 13, 11, 5, 12,
1, 9, 11, 10, 0, 8, 12, 4, 13, 3, 7, 15, 14, 5, 6, 2 };

const int CRipemd128::rp[64] = { 5, 14, 7, 0, 9, 2, 11, 4, 13, 6, 15, 8, 1, 10, 3, 12,
6, 11, 3, 7, 0, 13, 5, 10, 14, 15, 8, 12, 4, 9, 1, 2,
15, 5, 1, 3, 7, 14, 6, 9, 11, 8, 12, 2, 10, 0, 4, 13,
8, 6, 4, 1, 3, 11, 15, 0, 5, 12, 2, 13, 9, 7, 10, 14 };

const int CRipemd128::s[64] = { 11, 14, 15, 12, 5, 8, 7, 9, 11, 13, 14, 15, 6, 7, 9, 8,
7, 6, 8, 13, 11, 9, 7, 15, 7, 12, 15, 9, 11, 7, 13, 12,
11, 13, 6, 7, 14, 9, 13, 15, 14, 8, 13, 6, 5, 12, 7, 5,
11, 12, 14, 15, 14, 15, 9, 8, 9, 14, 5, 6, 8, 6, 5, 12 };

const int CRipemd128::sp[64] = { 8, 9, 9, 11, 13, 15, 15, 5, 7, 7, 8, 11, 14, 14, 12, 6,
9, 13, 15, 7, 12, 8, 9, 11, 7, 7, 12, 7, 6, 15, 13, 11,
9, 7, 15, 11, 8, 6, 6, 14, 12, 13, 5, 14, 13, 13, 7, 5,
15, 5, 8, 11, 14, 14, 6, 14, 6, 9, 12, 9, 12, 5, 15, 8 };

#endif //_RIPEMD128_H_