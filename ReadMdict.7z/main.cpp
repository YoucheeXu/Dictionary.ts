///////////////////////////////////////
// main.cpp

#include "stdafx.h"
#include "MDictBase.h"

bool g_bDebug = true;
CLogFile theLogFile;

int main ()
{
	CMDictBase myDict;
	myDict.Load(_T("src\\dicts\\WordNet 3.0.mdx"));
	myDict.Unload();

	return 0;
}