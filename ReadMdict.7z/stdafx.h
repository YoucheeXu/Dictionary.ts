//////////////////////////////////////////////
// StdAfx.h

// This file is used for precompiled headers
// Rarely modified header files should be included.

// Based on code provided by Lynn Allan


#ifndef STDAFX_H
#define STDAFX_H

// Rarely modified header files should be included here
#include <vector>
#include <map>
#include <string>
#include <sstream>		// Add support for string stream
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <tchar.h>

#include <iostream> 

#define tString wstring

typedef unsigned char BYTE;

#endif
