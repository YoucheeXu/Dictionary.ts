///////////////////////////////////////
// main.cpp

#include "stdafx.h"
#include "MDictBase.h"

bool g_bDebug = true;
CLogFile* g_pLogFile;

int main ()
{
	CMDictBase myDict;
	g_pLogFile = new CLogFile(_T("D:\\MDict.log"));
	myDict.Load(_T("Bin\\dicts\\WordNet3.0.mdx"));
	myDict.QueryWord(_T("right"));
	myDict.Unload();
	delete g_pLogFile;
	return 0;
}