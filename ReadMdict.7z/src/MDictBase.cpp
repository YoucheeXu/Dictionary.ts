//MDictBase.cpp
#include "stdafx.h"
#include "MDictBase.h"
#include "3rd\tinyxml2.h"
#include "3rd\zlib.h"
#include "3rd\minilzo-2.09\minilzo.h"
#include "ripemd128.h"

#pragma comment(lib, "src\\3rd\\zdll.lib")

using namespace tinyxml2;

CMDictBase::CMDictBase() {
	m_pDict = NULL;
	//m_pWord_Info = NULL;
	m_Ripemd128 = new CRipemd128();
	m_bDebug = true;

	// m_pKeyword_blocks_Info = NULL;
	// m_pRecord_Info = NULL;
}

CMDictBase::~CMDictBase() {

}

bool CMDictBase::Load(const TCHAR* dictPath) {

	if (lzo_init() != LZO_E_OK)
	{
		LOGERR("internal error - lzo_init() failed !!!");
		LOGERR("this usually indicates a compiler bug - try recompiling\nwithout optimizations, and enable '-DLZO_DEBUG' for diagnostics");
		return false;
	}
	
	bool ret = false;
	
	//ret = ReadDict(dictPath, true);
	ret = ReadDict(dictPath);
	if(false == ret) {
		LOGERR(_T("failed to read: %s"), dictPath);
		return false;
	}

	return true;
}

void CMDictBase::Unload() {
	delete m_Ripemd128;
	
	if(m_pDict != NULL) fclose(m_pDict);

	/*if (m_pWord_Info != NULL) {
		delete[] m_pWord_Info;
	}*/

	/*if (m_pKeyword_blocks_Info != NULL) {
		delete[] m_pKeyword_blocks_Info;
		m_pKeyword_blocks_Info = NULL;
	}*/

	/*if(m_pRecord_Info != NULL)
	{
		// for(UINT64 i = 0; i< m_lMDD_Num_blocks; i++){
			// auto it;
			// for(it = m_pMDD_Word_Info[i]->record_pair.begin();
					// it != m_pMDD_Word_Info[i]->record_pair.end(); ++it) {
				// BYTE* data = static_cast <BYTE*> (it->second);
				// delete [] data;
			// }
		// }
		delete[] m_pRecord_Info;
		m_pRecord_Info = NULL;
	}*/

    m_mapWords_info.clear();
}

bool CMDictBase::QueryWord(const TCHAR* wd) {

	UINT64 num_entries = 0;
	UINT64 record_start = 0;
	UINT64 record_end = 0;

	bool bFind = false;
	/*map<wstring, UINT64>::iterator it;
	int i = 0;
	for(; i < m_lNum_keywords_entries; i++) {
		if(_tcscmp(wd, m_pKeyword_blocks_Info[i].last_word.c_str())<=0) {
			if(_tcscmp(wd, m_pKeyword_blocks_Info[i].first_word.c_str())>0) {
				num_entries = m_pKeyword_blocks_Info[i].num_entries;
				it = m_pKeyword_blocks_Info[i].keyword_pair.find(wd);
				if(it != m_pKeyword_blocks_Info[i].keyword_pair.end()) {
					assert(0);
				}

				record_end = it->second;
				it--;
				record_start = it->second;
				
				bFind = true;
			}
			else if(_tcscmp(wd, m_pKeyword_blocks_Info[i].first_word.c_str()) == 0){
				it = m_pKeyword_blocks_Info[i].keyword_pair.begin();
				
				record_end = it->second;
				
				//? it  = m_pKeyword_blocks_Info[i - 1].keyword_pair.end() - 1;
				record_start = it->second;
				
				bFind = true;
			}
		}
	}*/
	
	if(false == bFind) {
		LOGINFO(_T("There is no %s in this dict."), wd);
		return false;
	}
	
	//if(0 == num_entries) return false;
	
	// UINT64 comp_size;
	// UINT64 decomp_size;
	// UINT32 file_offset;

	/*for(int i = 0; i < m_lTotal_num_keywords; i++) {
		if(num_entries < m_pRecord_Info[i]) {
			comp_size = m_pRecord_Info[i].comp_size;
			decomp_size = m_pRecord_Info[i].decomp_size;
			file_offset = m_pRecord_Info[i].file_offset;
		} else {
			num_entries = num_entries - m_pWord_blocks_Info[i].num_entries;
		}
	}*/
	
	/*UINT64 comp_size = m_pRecord_Info[i].comp_size;
	UINT64 decomp_size = m_pRecord_Info[i].decomp_size;
	UINT64 file_offset = m_pRecord_Info[i].file_offset;
	
	//
	fseek(m_pDict, file_offset, SEEK_SET);
	
	BYTE* rec_block_comp = new BYTE[comp_size];
	BYTE* rec_block_decomp = new BYTE[decomp_size];
	
	int num = fread(rec_block_comp, sizeof(BYTE), comp_size, m_pDict);
	if (num != comp_size) {
		LOGERR("Fail to read `rec_block`!");
		return false;
	}
	
	BYTE data_4Bytes[4];
	
	memcpy(data_4Bytes, &rec_block_comp[0], 4);	
	UINT32 comp_type = Decode_BytesNum(data_4Bytes, 4);
	
	memcpy(data_4Bytes, &rec_block_comp[4], 4);
	UINT32 rec_block_checksum = Decode_BytesNum(data_4Bytes, 4);
	
	bool ret = DecompData(&rec_block_comp[8], comp_size,
		rec_block_decomp, decomp_size, comp_type);
	
	if (false == ret ) {
		LOGERR("Fail to decomp rec_block.");
		delete [] rec_block_comp;	
		delete[] rec_block_decomp;
		return false;
	}
	
	delete [] rec_block_comp;
	
	//checksum keyword_block_decomp
	uLong rec_block_adler = adler32(0L, Z_NULL, 0);
	rec_block_adler = adler32(rec_block_adler, (BYTE*)rec_block_decomp, decomp_size);
	if (rec_block_adler != rec_block_checksum) {
		LOGERR("Fail to checksum `rec_block_decomp`!");
		delete[] rec_block_decomp;
		return false;
	}
	
	UINT rec_len = record_end - record_start;
	
	BYTE* record = new BYTE[rec_len];
	
	memcpy(record, &rec_block_comp[record_start], rec_len);
	
	delete[] rec_block_decomp;

	FILE* fp = _tfopen(wd, _T("w"));
	
	num = fwrite(record, sizeof(BYTE), rec_len, fp);
	
	fclose(fp);

	delete [] record;*/
	
	return true;
}

//To-Do: 
bool CMDictBase::GetWordList(const tString word, tString& tFindWord) {
	return false;
}

//To-Do: 
bool CMDictBase::DelWord(const TCHAR* wd) {
	return false;
}

//
bool CMDictBase::ReadDict(const TCHAR* dictPath) {
	bool ret = false;

	m_pDict = _tfopen(dictPath, _T("rb"));
	assert(m_pDict);
	//read Length of `header_str`, 4 bytes. Big-endian.
	BYTE len_header_str[4];
	size_t num = fread(len_header_str, sizeof(BYTE), 4, m_pDict);
	if (num != 4) {
		LOGERR("Fail to read len_header_str!");
		return false;
	}

	UINT32 length_header_str = Decode_BytesNum(len_header_str, 4);

	//read header_str, An XML string, encoded in UTF-16LE.

	wchar_t * header_wstr = new wchar_t[length_header_str / 2];

	num = fread(header_wstr, sizeof(BYTE), length_header_str, m_pDict);
	if (num != length_header_str) {
		LOGERR("Fail to read length_header_str!");
		return false;
	}

	LOGOUT("head of dict2:\r\n");
	LOGOUT(header_wstr);
	LOGOUT("\r\n");

	//read ADLER32 checksum of `header_str`, 4 bytes, stored little-endian.  
	BYTE checksum_header_str[4];
	num = fread(checksum_header_str, sizeof(BYTE), 4, m_pDict);
	if (num != 4) {
		LOGERR("Fail to read checksum of `header_str`!");
		return false;
	}

	//little-endian
	UINT32 header_checksum = Decode_BytesNum(checksum_header_str, 4, false);

	//checksum head_str
	UINT32 header_adler = adler32(0L, Z_NULL, 0);
	header_adler = adler32(header_adler, (BYTE*)header_wstr, length_header_str);

	if (header_adler != header_checksum) {
		LOGERR("Fail to checksum `header_str`!");
		return false;
	}

	//parse head_str
	ret = ParseHead(header_wstr);
	delete[] header_wstr;

	if (false == ret) {
		LOGERR("Fail to ParseHead!")
		return false;
	}
	
	ret = Read_keyword_sect();
	if (false == ret) {
		LOGERR("Fail to read keyword sect!")
		return false;
	}

	ret = Read_record_sect();
	if (false == ret) {
		LOGERR("Fail to Read_record_sect!")
		return false;
	}
	
	return ret;
}

//bool CMDictBase::ParseHead(wchar_t* header_wstr, dict_info& dictInfo) {
bool CMDictBase::ParseHead(wchar_t* header_wstr) {

	//convert to ANSI code;
	size_t len = wcslen(header_wstr) + 1;
	size_t converted = 0;
	char * header_str = (char*)malloc(len*sizeof(char));
	wcstombs_s(&converted, header_str, len, header_wstr, _TRUNCATE);

	tinyxml2::XMLDocument doc;
	doc.Parse(header_str);

	free(header_str);

	XMLElement *root = doc.RootElement();

	const XMLAttribute *attributeOfSurface = root->FirstAttribute();
	while (attributeOfSurface) {
		cout << attributeOfSurface->Name() << ":" << attributeOfSurface->Value() << endl;
		attributeOfSurface = attributeOfSurface->Next();
	}

	m_dict_info.fGeneratedByEngineVersion = root->FloatAttribute("GeneratedByEngineVersion");
	m_dict_info.fRequiredEngineVersion = root->FloatAttribute("RequiredEngineVersion");
	if (m_dict_info.fRequiredEngineVersion != 2.0) {
		LOGERR("Can't support version of %f!", m_dict_info.fRequiredEngineVersion);
		return false;
	}

	m_dict_info.szDescription = root->Attribute("Description");
	m_dict_info.szTitle = root->Attribute("Title");

	m_dict_info.szEncoding = root->Attribute("Encoding");
	m_dict_info.szFormat = root->Attribute("Format");
	m_dict_info.szCreationDate = root->Attribute("CreationDate");

	string szCompacted = root->Attribute("Compact");
	m_dict_info.bCompacted = strncmp(szCompacted.c_str(), "Yes", 12) == 0;
	if (true == m_dict_info.bCompacted) {
		m_dict_info.szStyleSheet = root->Attribute("StyleSheet");
		if (m_dict_info.szStyleSheet.length() >= 2) {
			LOGERR("Can't support compact attribute!");
			return false;
		}
	}

	m_dict_info.nDataSourceFormat = root->IntAttribute("DataSourceFormat");

	string szKeyCaseSensitive = root->Attribute("KeyCaseSensitive");
	m_dict_info.bKeyCaseSensitive = strncmp(szKeyCaseSensitive.c_str(), "Yes", 12) == 0;

	int nEncrypted = root->IntAttribute("Encrypted");
	if (nEncrypted != 0) {
		m_dict_info.bKeyword_header_encrypted = false;
		m_dict_info.bKeyword_index_encrypted = false;
		if ((nEncrypted & 0x1) !=0 ) {
			m_dict_info.bKeyword_header_encrypted = true;
			m_dict_info.szRegisterBy = root->Attribute("RegisterBy");
			if (root->Attribute("RegCode") != NULL) {
				m_dict_info.szRegCode = root->Attribute("RegCode");
			} else {
				//read samename.key
			}

			LOGERR("Can't support Keyword_header_encrypted!");
			return false;
		}
		if ((nEncrypted & 0x2) != 0) m_dict_info.bKeyword_index_encrypted = true;
	}

	return true;
}

//parse keyword_sect	
bool CMDictBase::Read_keyword_sect() {
	bool ret = false;
	size_t num = 0;
	BYTE data_8Bytes[8];
	int num_header = 8 * 5;
	/*if (m_fRequiredEngineVersion >= 2.0) {
		num_keyword_header = 8 * 5;
	}*/

	BYTE* header_data = new BYTE[num_header];

	num = fread(header_data, sizeof(BYTE), num_header, m_pDict);
	if (num != num_header) {
		LOGERR("Fail to read `keyword_header_str`!");
		delete[] header_data;
		return false;
	}
	
	//decrypt Keyword_header_encrypted if needed
	if (true == m_dict_info.bKeyword_header_encrypted) {
		//memcpy(keyword_header_str, Decrypt_string(keyword_header_str), num_keyword_header);
		LOGERR("it doesn't support Keyword_header_encrypted");
		delete[] header_data;
		return false;
	}

	BYTE header_checksum_data[4];
	num = fread(header_checksum_data, sizeof(BYTE), 4, m_pDict);
	if (num != 4) {
		LOGERR("Fail to read checksum of `keyword_header_checksum_data`!");
		delete[] header_data;
		return false;
	}

	//Big-endian
	UINT32 header_checksum = Decode_BytesNum(keyword_header_checksum_data, 4);

	//checksum keyword_header_data
	UINT32 header_adler = adler32(0L, Z_NULL, 0);
	header_adler = adler32(header_adler, (BYTE*)header_data, num_header);
	if (header_adler != header_checksum) {
		LOGERR("Fail to checksum `keyword_header_data`!");
		delete[] header_data;
		return false;
	}

	memcpy(data_8Bytes, &header_data[0], 8);	
	UINT num_blocks = Decode_BytesNum(data_8Bytes, 8);

    //Total number of keywords. 8Bytes Big-endian.
	memcpy(data_8Bytes, &header_data[8], 8);
	dict_info.num_entries = Decode_BytesNum(data_8Bytes, 8);

	memcpy(data_8Bytes, &header_data[16], 8);
	UINT64 index_decomp_size = Decode_BytesNum(data_8Bytes, 8);

	memcpy(data_8Bytes, &header_data[24], 8);
	UINT64 index_comp_size = Decode_BytesNum(data_8Bytes, 8);

    //Total number of bytes taken up by key_blocks. 8Bytes, Big-endian.
	memcpy(data_8Bytes, &header_data[32], 8);
	UINT64 blocks_size = Decode_BytesNum(data_8Bytes, 8);

	delete[] header_data;

	//read keyword_index
 	BYTE * index_comp = new BYTE[index_comp_size];
	num = fread(index_comp, sizeof(BYTE), index_comp_size, m_pDict);
	if (num != index_comp_size) {
		LOGERR("Fail to read checksum of `keyword_index_comp`!");
        delete [] index_comp;
		return false;
	}

	BYTE index_head_data[4];
	memcpy(index_head_data, index_comp, 4);
	UINT32 index_head = Decode_BytesNum(index_head_data, 4, false);

	if (index_head != 2) {
		LOGERR("`keyword_index_comp_head` is wrong!");
		delete[] index_comp;
		return false;
	}

	BYTE index_deComp_checksum[4];
	memcpy(index_deComp_checksum, &index_comp[4], 4);

	BYTE index_encryption_keyword_data[8];
	memcpy(index_encryption_keyword_data, &index_deComp_checksum, 4);

	index_encryption_keyword_data[4] = 0x95;
	index_encryption_keyword_data[5] = 0x36;
	index_encryption_keyword_data[6] = 0x00;
	index_encryption_keyword_data[7] = 0x00;

	//decrypt if needed
	if (true == m_dict_info.bKeyword_index_encrypted) {
		uLong index_encryption_key[4];
		m_Ripemd128->Checksum(index_encryption_keyword_data, 8, index_encryption_key);

		BYTE previous = 0x36;
		BYTE* index_keyword_byte = (BYTE*)index_encryption_key;
		for (int i = 0; i < index_comp_size - 8; i++) {
			BYTE t = (index_comp[8 + i] >> 4 | index_comp[8 + i] << 4) & 0xff;
			int keybyte_index = i % (4 * 4);
			BYTE keybyte = index_keyword_byte[keybyte_index];
			t = t ^ previous ^ (i & 0xff) ^ keybyte;
			previous = index_comp[8 + i];
			index_comp[8 + i] = t;
		}
	}

	//decompress keyword_index_decomp //???
	BYTE* index_deComp = new BYTE[index_decomp_size];
	uLong out_len = index_decomp_size;
	int index_uncompress_ret = uncompress(index_deComp, &out_len, &index_comp[8], index_comp_size - 8);
	if (index_uncompress_ret != Z_OK) {
		LOGERR("Fail to uncompress `keyword_index`, err-code: %d", index_uncompress_ret);
        delete [] index_comp;
        delete [] index_deComp;
		return false;
	}

	//checksum of keyword_index_info
	UINT32 index_checksum = Decode_BytesNum(index_deComp_checksum, 4);

	//checksum keyword_index
	uLong index_adler = adler32(0L, Z_NULL, 0);
	index_adler = adler32(index_adler, (BYTE*)index_deComp, index_decomp_size);

	if (index_adler != index_checksum) {
		LOGERR("Fail to checksum `keyword_index`!");
        delete[] index_comp;
		delete[] index_deComp;
		return false;
	}

	delete[] index_comp;

	BYTE index_first_size[2];		//Length of `first_word`, not including trailing null character.
	UINT16 first_keyword_size;
	//BYTE* keyword_index_first_word;
	BYTE index_last_size[2];		//Length of `last_word`, not including trailing null character.
	UINT16 last_keyword_size;
	//BYTE* keyword_index_last_word;

	/*typedef struct _index_t {
		UINT64 comp_size;			//Compressed size of `keyword_blocks`
		UINT64 decomp_size;		//Decompressed size of `keyword_blocks`
	}index_t;
	index_t* index = new index_t[num_blocks];*/

	//m_pKeyword_blocks_Info = new keyword_bolck_t[m_lNum_Keyword_blocks];
    //UINT64 comp_size;
	UINT index_deComp_index = 0;
    UINT64 num_entries = 0;

	BYTE block_comp_type_data[4];
	UINT32 block_comp_type;
	BYTE block_checksum_data[4];
	UINT32 block_checksum;
	BYTE* block_comp;
    UINT64 block_comp_size;	    //Compressed size of `keyword_blocks`
	BYTE* block_decomp;
	UINT64 block_decomp_size;   //Decompressed size of `keyword_blocks`
        
	for (UINT64 i = 0; i < num_blocks; i++)
	{
        //read keyword index
  
		LOGINFO("Info of keyword block: %d", i);
		memcpy(data_8Bytes, &index_deComp[index_deComp_index], 8);
		num_entries = Decode_BytesNum(data_8Bytes, 8);
		LOGINFO("Nume_entries: %d", num_entries);
        
        index_deComp_index += 8;

		//read first_word_size
		memcpy(index_first_size, &index_deComp[index_deComp_index], 2);
		first_keyword_size = Decode_BytesNum(index_first_size, 2);
		if (strcmp(m_dict_info.szEncoding.c_str(), "UTF-16") == 0) first_keyword_size = (first_keyword_size + 1) * 2;
		else first_keyword_size = first_keyword_size + 1;

        index_deComp_index += 2;

		// keyword_index_first_word = new BYTE[first_keyword_size];
		// memcpy(keyword_index_first_word, &keyword_index_deComp[keyword_index_deComp_index], first_keyword_size);
        // m_pKeyword_blocks_Info[i].first_word = (wchar_t*)keyword_index_first_word;
        // LOGINFO(_T("first_word: %s"), m_pKeyword_blocks_Info[i].first_word.c_str());
        // delete[] keyword_index_first_word;
        
		index_deComp_index += first_keyword_size;

		//read last_word_size
		memcpy(index_last_size, &index_deComp[index_deComp_index], 2);
		last_keyword_size = Decode_BytesNum(index_last_size, 2);
		if (strcmp(m_dict_info.szEncoding.c_str(), "UTF-16") == 0) last_keyword_size = (last_keyword_size + 1) * 2;
		else last_keyword_size = last_keyword_size + 1;
        
        index_deComp_index += 2;

		/* //read last_word
        keyword_index_last_word = new BYTE[last_keyword_size];
		memcpy(keyword_index_last_word, &keyword_index_deComp[keyword_index_deComp_index], last_keyword_size);
		m_pKeyword_blocks_Info[i].last_word = (wchar_t*)keyword_index_last_word;
		LOGINFO(_T("last_word: %s"), m_pKeyword_blocks_Info[i].last_word.c_str());
		delete[] keyword_index_last_word;*/
        
        index_deComp_index += last_keyword_size;

		//read comp_size
		memcpy(data_8Bytes, &index_deComp[index_deComp_index], 8);
		block_comp_size = Decode_BytesNum(data_8Bytes, 8);
		LOGINFO("comp size: %d.", block_comp_size);
        
        index_deComp_index += 8;

		//read decomp_size
		memcpy(data_8Bytes, &keyword_index_deComp[keyword_index_deComp_index], 8);
		block_decomp_size = Decode_BytesNum(data_8Bytes, 8);
		LOGINFO("deComp size: %d.", block_decomp_size);
        
        index_deComp_index += 8;

		LOGOUT("\r\n");

        //read keyword_block

		num = fread(block_comp_type_data, sizeof(BYTE), 4, m_pDict);
		if (num != 4) {
			LOGERR("Fail to read keyword_block_comp_type_data[%d]!", i);
            delete [] index_deComp;
			return false;
		}
		block_comp_type = Decode_BytesNum(comp_type_data, 4);

		num = fread(checksum_data, sizeof(BYTE), 4, m_pDict);
		if (num != 4) {
			LOGERR("Fail to read keyword_block_checksum_data[%d]!", i);
			delete[] keyword_index;
			return false;
		}
		checksum = Decode_BytesNum(checksum_data, 4);

		UINT64 block_text_size = block_comp_size - 8;
		block_comp = new BYTE[block_text_size];
		num = fread(block_comp, sizeof(BYTE), block_text_size, m_pDict);
		if (num != block_text_size) {
			LOGERR("Fail to read keyword_block_comp[%d]!", i);
            delete[] block_comp;
			return false;
		}

		//deCompress keyword_block
		block_decomp = new BYTE[keyword_index[i].decomp_size];
		ret = DecompData(block_comp, block_text_size, 
            block_decomp, block_decomp_size, block_comp_type);
		if(false == ret){
			LOGERR("Fail to deComp keyword block: %d.", i);
            delete[] block_decomp;
			delete[] block_comp;
			return false;
		}
        
        delete[] block_comp;

		//checksum keyword_block_decomp
		uLong block_adler = adler32(0L, Z_NULL, 0);
		block_adler = block_adler32(adler, (BYTE*)block_decomp, block_decomp_size);
		if (adler != block_checksum) {
			LOGERR("Fail to checksum `keyword_block_decomp`!");
			delete[] block_decomp;
			return false;
		}

		UINT64 num_keyword = Split_keyword_block(i, block_decomp, block_decomp_size);

		if (num_keyword != num_entries) {
			LOGERR("Fail to split `keyword_block_decomp`!");
            delete[] index_deComp;
			delete[] block_decomp;
			return false;
		}

		delete[] block_decomp;
	}
    
    delete[] index_deComp;

	return true;
}

bool CMDictBase::Read_record_sect(){
	size_t num = 0;
	bool ret = false;
	BYTE data_8bytes[8];

	BYTE head_data[32]; 

	//Number items in `record_blocks`. Does not need to equal the number of keyword blocks. Big-endian.
	num = fread(head_data, sizeof(BYTE), 32, m_pDict);
	if (num != 32) {
		LOGERR("Fail to read record_head_data!");
		return false;
	}
	
	//Number items in `record_blocks`. Does not need to equal the number of keyword blocks. Big-endian.
	memcpy(data_8bytes, &head_data[0], 8);
	num_blocks = Decode_BytesNum(data_8bytes, 8);

	//Total number of records in dictionary. Should be equal to `keyword_sect.num_entries`. Big-endian. 
	memcpy(data_8bytes, &head_data[8], 8);
	UINT64 num_entries = Decode_BytesNum(data_8bytes, 8);
    
    if(num_entries != m_dict_info.num_entries){
        LOGERR("num_entries in record_sect don't equal to in keyword_sect");
        return false;
    }

	//Total size of the `comp_size[i]` and `decomp_size[i]` variables, in bytes. In other words, should equal 16 times `num_blocks`. Big-endian.
	memcpy(data_8bytes, &head_data[16], 8);
	UINT64 index_size = Decode_BytesNum(data_8bytes, 8);

	//Total size of the `rec_block[i]` sections, in bytes. Big-endian. |
	memcpy(data_8bytes, &head_data[24], 8);
	UINT64 blocks_size = Decode_BytesNum(data_8bytes, 8);

	BYTE* index_data = new BYTE[index_size];
	num = fread(index_data, sizeof(BYTE), index_size, m_pDict);
	if (num != index_size) {
		LOGERR("Fail to read index_data!");
		delete [] index_data;
		return false;
	}

    auto it = m_mapWords_info.begin();
    UINT32 file_offset = ftell(m_pDict);
    UINT64 j = 0;
    UINT64 offset = 0;
 
    /*BYTE block_comp_type_data[4];     
	UINT32 block_comp_type;
	BYTE block_checksum_data[4];
	UINT32 block_checksum;*/
    UINT64 block_comp_size = 0;
    //BYTE* block_comp;
    UINT64 block_decomp_size = 0;
    //BYTE* block_decomp;
    //BYTE* record_data;
    //UINT64 record_size = 0;
    //wstring record_text;
	for(UINT64 i = 0; i < num_blocks; i++) {

		memcpy(data_8bytes, &index_data[i * 16], 8);
		//m_pRecord_Info[i].comp_size = Decode_BytesNum(data_8bytes, 8);
        //index[i].comp_size = Decode_BytesNum(data_8bytes, 8);
        block_comp_size = Decode_BytesNum(data_8bytes, 8);

		memcpy(data_8bytes, &index_data[i * 16 + 8], 8);
		//m_pRecord_Info[i].decomp_size = Decode_BytesNum(data_8bytes, 8);
        //index[i].decomp_size = Decode_BytesNum(data_8bytes, 8);
        block_decomp_size = Decode_BytesNum(data_8bytes, 8);

        for(; it != m_mapWords_info.end(); it++){
            // reach the end of current record block
            if (it->second.offset - offset >= block_decomp_size){
                it--;
                break;
            }
            
            // record end index
            if (j < m_mapWords_info.size() - 1) {
                //record_end = self._key_list[i+1][0]
                it->second.end_offset = (it+1)->second.offset - offset;
            }
            else {
                it->second.end_offset = block_decomp_size;
            }
            j++;
            
            it->second.comp_size = block_comp_size;
            it->second.decomp_size = block_decomp_size;
            
            it->second.file_offset = file_offset;
            it->second.start_offset = it->second.offset - offset;

            /*// read record_blocks
            // split record block according to the offset info from key block
            
            // 4 bytes indicates block compression type
            num = fread(block_comp_type_data, sizeof(BYTE), 4, m_pDict);
            if (num != 4) {
                LOGERR("Fail to read record_block_comp_type_data[%d]!", i);
                delete [] index;
                return false;
            }
            block_comp_type = Decode_BytesNum(comp_type_data, 4);

            // 4 bytes adler checksum of uncompressed content
            num = fread(block_checksum_data, sizeof(BYTE), 4, m_pDict);
            if (num != 4) {
                LOGERR("Fail to read record_block_checksum_data[%d]!", i);
                delete [] index;
                return false;
            }
            checksum = Decode_BytesNum(checksum_data, 4);
            
            //comp_size = m_pRecord_Info[i].comp_size - 8;
            block_comp_size = index[i].comp_size - 8;
            block_comp = new BYTE[comp_size];
            num = fread(block_comp, sizeof(BYTE), comp_size, m_pDict);
            if (num != comp_size) {
                LOGERR("Fail to read record block: %d!", i);
                delete [] block_comp;
                delete [] index;
                return false;
            }

            //deCompress keyword_block
            block_decomp_size = index[i].decomp_size - 8;
            block_decomp = new BYTE[block_decomp_size];

            ret = DecompData(block_comp, block_decomp_size,
                block_decomp, block_comp_size, block_comp_type);
            
            delete[] block_comp;
            
            if(false == ret){
                LOGERR("Fail to deComp record_block[%d]!", i);
                delete[] block_decomp;
                delete[] index;
                return false;
            }

            //checksum block_decomp
            uLong block_adler = adler32(0L, Z_NULL, 0);
            block_adler = adler32(adler, (BYTE*)block_decomp, index[i].decomp_size);
            if (block_adler != block_checksum) {
                LOGERR("Fail to checksum `record_block_decomp[%d]`!", i);
                delete[] block_decomp;
                delete[] index;
                return false;
            }
            
            record_size = (record_end - offset) - (record_start - offset);
            record_data = new BYTE[record_size]
            memcpy(record_data, &block_decomp[record_end - offset], record_size);
            # convert to utf-8
            record_text = (wchar_t*)record_data;
            delete [] record_data;
            // substitute styles
            if (m_dict_info.bSubstyle && m_dict_info.stylesheet){
                record_text = Substitute_stylesheet(record_text)
            }
            UINT32 text_checksum = 
            uLong text_adler = adler32(0L, Z_NULL, 0);
            text_adler = adler32(adler, (BYTE*)record_text.c_str(), record_text.size());
            UINT32 text_comp_type = ;
            UINT64 text_comp_size = CompData(record_text, text_comp_type, text_comp);
            InsertWord(it->first, text_comp_type, text_checksum, text_comp);
            */            
        }
        // delete [] block_decomp;
        file_offset = file_offset + block_comp_size;
        offset += block_decomp_size;           
	}
	//size_counter += compressed_size;
	delete [] index_data;

    //return false;
}

UINT64 CMDictBase::Split_keyword_block(UINT64 num_block, const BYTE* block,
		UINT64 block_size) {
	BYTE offset_data[8];
	UINT64 offset = 0;
	BYTE* key;
	UINT16 keyword_size = 0;
	bool found = false;
	UINT end = 0;
	bool isUTF16 = false;

	UINT64 num_key = 0;
	UINT64 block_index = 0;

	//memcpy(offset_data, &keyword_block[0], 8);
	//offset = Decode_BytesNum(offset_data, 8);

	LOGINFO("Start to Split keyword block: %d.", num_keyword_block);

	if (strcmp(m_dict_info.szEncoding.c_str(), "UTF-16") == 0) {
		isUTF16 = true;
		end = 2;
		keyword_size = end;
	}
	else {
		isUTF16 = false;
		end = 1;
		keyword_size = end;
	}

	memcpy(offset_data, &block[0], 8);
	offset = Decode_BytesNum(offset_data, 8);
	block_index = 8;

	for (;;) {
		if (true == isUTF16) {
			if((block[block_index + keyword_size] == '\0') && (block[block_index + keyword_size + 1] == '\0')){
				found = true;
			}
			else keyword_size += end;
		}
		else {
			if (block[block_index + keyword_size] == '\0') {
				found = true;
			}
			else keyword_size ++;
		}

		if (true == found) {
			key = new BYTE[keyword_size + end];
			memcpy(key, &block[block_index], keyword_size + end);
			
			wstring wkey = (wchar_t*)key;
			
			//m_pKeyword_blocks_Info[num_keyword_block].keyword_pair.insert(std::pair<wstring, UINT64>((wchar_t*)key, offset));
            
            m_mapWords_info[wkey].offset = offset;

			num_key++;

			//LOGINFO("Number: %d", num_key);
			//LOGINFO("Index: %d", block_index);
			//LOGINFO("keyword_size: %ld, keyword_offset: %ld.", keyword_size, offset);
			//LOGINFO(_T("keyword_text: %s"), wkey.c_str());

			block_index = block_index + keyword_size + end;
			keyword_size = end;
			found = false;
			delete[] key;

			if (block_index >= block_size) {
				LOGOUT("\r\n");
				return num_key;
			}

			memcpy(offset_data, &block[block_index], 8);
			offset = Decode_BytesNum(offset_data, 8);
			block_index += 8;
		}
	}

	return 0;
}

//To-Do: modify comp_type to raw data
bool CMDictBase::DecompData(const BYTE* comp_data, UINT64 comp_size,
		BYTE* decomp_data, UINT64 decomp_size, UINT32 comp_type) {
	int ret = 0;
	uLong out_len = decomp_size;
	switch (comp_type) {
		case 0x0:
			memcpy(decomp_data, comp_data, decomp_size);
			break;
		case 0x01000000:		//LZO
			lzo_uint new_len;;
			ret = lzo1x_decompress(comp_data, comp_size, decomp_data, &new_len, NULL);
			if (ret != LZO_E_OK || new_len != decomp_size) {
				LOGERR("Fail to unLZO `keyword_block`, err-code: %d", ret);
				return false;
			}
			break;
		case  0x02000000:		//zlib
			ret = uncompress(decomp_data, &out_len, comp_data, comp_size);
			if (ret != Z_OK) {
				LOGERR("Fail to unZLib `keyword_block`, err-code: %d", ret);
				return false;
			}
			break;
		default:
			LOGERR("Unknown comp type: %d", comp_type);
			return false;
		}
	return true;
}

UINT64 CMDictBase::Decode_BytesNum(const BYTE* num, int len, bool isBigEndian) {
	assert(2 <= len <= 8);

	int times = 0;
	
	UINT result = 0;
	for (int i = 0; i < len; i++) {
		if (true == isBigEndian) times = len - i - 1;
		else times = i;
		result += num[i] << 8 * times;
	}

	return result;
}

bool CMDictBase::Decrypt_string(BYTE* str) {

	//if (strcpy("EMail", m_szRegisterBy.c_str()) == 0) {
	//	email_digest = ripemd128(email.decode().encode('utf-16-le'))
	//		s20 = Salsa20(key = email_digest, IV = b"\x00" * 8, rounds = 8)
	//		encrypt_key = s20.encryptBytes(reg_code)
	//}
	//else if (strcpy("DeviceID", m_szRegisterBy.c_str()) == 0) {
	//	deviceid_digest = ripemd128(deviceid)
	//		s20 = Salsa20(key = deviceid_digest, IV = b"\x00" * 8, rounds = 8)
	//		encrypt_key = s20.encryptBytes(reg_code)
	//}

	////return _salsa_decrypt(str, encrypted_key);

	//s20 = Salsa20(key = encrypt_key, IV = b"\x00" * 8, rounds = 8)
	//return s20.encryptBytes(ciphertext)

	return false;
}