//MDictBase.h
/*
Can't support Keyword_header_encrypted!
only support version of 2.0
Can't support compact attribute!

*/

#ifndef __MDICTBASE__H__
#define __MDICTBASE__H__

#include <string>
#include <tchar.h>
#include <stdio.h>
#include <assert.h>
#include "LogFile.h"

using namespace std;

class CRipemd128;

class CMDictBase
{
public:

	CMDictBase();
	~CMDictBase();

public:

	bool Load(const TCHAR* dictPath);
	void Unload();

	bool QueryWord(const TCHAR* wd);

	bool GetWordList(const tString word, tString& tFindWord);

	bool DelWord(const TCHAR* wd);

private:
	bool ReadDict(const TCHAR* dictPath);
	bool ParseHead(wchar_t* header_wstr);
	
	bool Read_keyword_sect();
	UINT64 Split_keyword_block(UINT64 num_block, const BYTE* block, UINT64 block_size);
	
	bool Read_record_sect();
	
	bool DecompData(const BYTE* comp_data, UINT64 comp_size,
		BYTE* decomp_data, UINT64 decomp_size, UINT32 comp_type);
	
	UINT64 Decode_BytesNum(const BYTE* num, int len, bool isBigEndian = true);
	bool Decrypt_string(BYTE* str);

private:
	bool m_bDebug;

	CRipemd128* m_Ripemd128;

	FILE* m_pDict;
	
	typedef struct _dict_info {
		float fGeneratedByEngineVersion;
		float fRequiredEngineVersion;

		string szDescription;
		string szTitle;

		string szEncoding;
		string szFormat;
		string szCreationDate;
		
		bool bCompacted;
		bool bCompated;	//may be typo of m_bCompacted;
		string szStyleSheet;	//Used in conjunction with the `Compact` option. See the documentation for the official MdxBuilder client for details.
		
		int nDataSourceFormat;      //unknown
		
		bool bKeyCaseSensitive;

		//int nEncrypted;
		bool bKeyword_header_encrypted;
		bool bKeyword_index_encrypted;
		string szRegisterBy;
		string szRegCode;
        UINT64 num_entries;     //the whole number of words
	} dict_info;

	//StripKey = "Yes";
	//Left2Right = "Yes";
	
	dict_info m_dict_info;

	/*UINT64 m_lNum_Keyword_blocks;		//Number of items in key_blocks. 
	UINT64 m_lNum_keywords_entries;		//Total number of keywords.

	typedef struct _keyword_bolck_t {
		wstring first_word;		//The first keyword (alphabetically) in the keyword block.
		wstring last_word;		//The last keyword (alphabetically) in the keyword block.
		UINT64 num_entries;				//Number of keywords in the keyword block
		map<wstring, UINT64> key_pair;
	}keyword_bolck_t;

	keyword_bolck_t* m_pKeyword_blocks_Info;
	
	typedef struct _record_block_t {
		UINT32 file_offset;
		UINT32 rec_offset;
		UINT64 comp_size;
		UINT64 decomp_size;
		//BYTE* record;
	}record_bolck_t;
	
	record_bolck_t* m_pRecord_Info;
	UINT64 m_lNum_Record_blocks;*/
    
    typedef struct _word_info_t {
        UINT32 file_offset;
        UINT64 comp_size;           //record block comp_size
        UINT64 decomp_size;         //record block comp_size
        UINT64 start_offset;        //word data start offset in record_block_decomp
        UINT64 end_offset;
        UINT64 offset;              //tmp data from keyword_block
    }word_info_t
    
    map<wstring, word_info_t> m_mapWords_info;
};

#endif //__MDICTBASE__H__