#include "stdafx.h"
#include "DictApp.h"
#include "resource.h"

// global vars
//CLogFile theLogFile;
//CDictApp theApp;
//bool g_bDebug;
//CLogFile* g_pLogFile;

CDictApp::CDictApp() : m_MyDialog(IDD_DICT)
{
	//g_pLogFile = new CLogFile();
	g_bDebug = true;
}

CDictApp::~CDictApp()
{
	//Uninitialize();
	//delete g_pLogFile;
}

BOOL CDictApp::InitInstance()
{
	//m_MyDialog.SetDialogBkColor(RGB(0, 0, 255), RGB(255, 0, 0));
	//Display the Modal Dialog
	m_MyDialog.DoModal();

	return TRUE;
}

//void CDictApp::Initialize(HINSTANCE hInstance)
//{    
//	SetResourceHandle(hInstance);
//	mHTabIcon = (HICON) ::LoadImage( hInstance, 
//		MAKEINTRESOURCE(IDC_LV_CV), IMAGE_ICON, 0, 0, 
//		LR_LOADMAP3DCOLORS | LR_LOADTRANSPARENT );
//	//m_TB_Icon.hToolbarBmp = (HBITMAP) ::LoadImage( hInstance,
//	// MAKEINTRESOURCE(IDB_TAGSVIEW), IMAGE_BITMAP, 0, 0, 
//	// LR_DEFAULTSIZE | LR_LOADMAP3DCOLORS );
//}

//void CDictApp::Uninitialize()
//{
//	if (mHTabIcon)
//	{
//		::DestroyIcon(mHTabIcon);
//		mHTabIcon = NULL;
//	}
//	//if ( m_TB_Icon.hToolbarBmp )
//	//{
//	//    ::DeleteObject(m_TB_Icon.hToolbarBmp);
//	//    m_TB_Icon.hToolbarBmp = NULL;
//	//}
//}

//{
//	If PrevInstance(IO.Path.GetFileNameWithoutExtension(Application.ExecutablePath), True) Then
//		Me.Close()
//		Return
//	End If
//}

//bool CDictApp::PrevInstance(ByVal sProName As String, Optional ByVal start As Boolean = False)
//{
//	Dim i As Integer
//	Try
//		i = Diagnostics.Process.GetProcessesByName(sProName).Length
//	Catch ex As Exception
//		i = 0
//	End Try
//
//	If start Then
//		Return i > 1
//	Else
//		Return i > 0
//	End If
//}