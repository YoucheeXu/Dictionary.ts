#include <string>
#include <tchar.h>

using namespace std;


class CDictDlg;

class CGDictBase
{
public:

	CGDictBase(CDictDlg* pDlg);
	~CGDictBase();

public:

	bool Load(const TCHAR* dictPath, const TCHAR* audioPath);
	void Unload();

	bool QueryWrod(const TCHAR* wd);

	//TCHAR* GetWordList(const TCHAR* wd);
	//TCHAR* GetWordList(const tString word);
	bool GetWordList(const tString word, tString& tFindWord);

	BOOL DelWord(const TCHAR* wd);
	BOOL DelAudio(const TCHAR* wd);
	
	bool GetAudioPath(const TCHAR* wd, bool isUs, tString& path);

private:
	bool QueryJson(TCHAR* dictPath, const TCHAR* wd, TCHAR* jsonURL);

private:
	TCHAR m_tszGDictPath1[MAX_PATH], m_tszGDictPath2[MAX_PATH];
	TCHAR m_tszAudioPath[MAX_PATH];
	CDictDlg* m_pDlg;
	intptr_t m_hFile;
};