//#include "win32++\include\stdcontrols.h"
//#include "win32++\include\gdi.h"
#include <tchar.h>

using namespace Win32xx;

class CBmpButton :public CButton
{
public:
	CBmpButton();
	virtual ~CBmpButton();

private:
	//CBitmap m_bmpAll;
	// BYTE* m_pBmpAllBits;
    // CBitmap m_bmpNormal;
    // CBitmap m_bmpFocused; 
    // CBitmap m_bmpClicked;
	// CBitmap m_bmpDisable;
	HDC m_hScrDC;
	HBITMAP m_hScrBmp;

    /*HBITMAP m_hNormalBmp;
    HBITMAP m_hFocusedBmp; 
    HBITMAP m_hClickedBmp;
	HBITMAP m_hDisableBmp;*/
	
	int m_nWidth;
	int m_nHeight;
	
	bool m_bInRect;
	//CRect m_rectButton;
	bool m_b3States;
	//bool m_bInited;
	int m_nState;

public:
	void Init(tString imgfile, int x, int y, int w, int h, bool is3states);
	//void NotifyFocused(bool bFocused);
	//virtual void OnMouseMove(WPARAM wParam, LPARAM lParam);
	//void EnableWindow2(BOOL bEnable);
	
private:
	bool LoadFromFile(const TCHAR* bmpfile);
	// bool CutBmp(CPoint start, CPoint ends, CBitmap &newbmp);
	//bool CutBmp(int x, int y, HBITMAP& hBmp);
	//HBITMAP CutBmp(int x, int y);

protected:
	virtual void OnMouseMove(WPARAM wParam, LPARAM lParam);
	//virtual void	OnNCHitTest(WPARAM wParam, LPARAM lParam);
	//virtual void	OnSetCursor(WPARAM wParam, LPARAM lParam);
	virtual LRESULT WndProc(UINT uMsg, WPARAM wParam, LPARAM lParam);
	virtual void OnLButtonDown(WPARAM wParam, LPARAM lParam);
	virtual void OnLButtonUp(WPARAM wParam, LPARAM lParam);
	//virtual void OnMouseEnter();
	//virtual void OnMouseLeave();
	virtual LRESULT OnMessageReflect(UINT uMsg, WPARAM wParam, LPARAM lParam);
	virtual void OnDrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct);
};