//MainDialog.cpp
#include "stdafx.h"
//#include "ReciteWordsApp.h"

#include "resource.h"
#include "IniFile.h"
#include "SQLiteDataBase.h"
#include "StudyMode.h"
#include "TestMode.h"
#include "Mp3Player.h"
#include "MainDialog.h"
#include "ReciteWordsApp.h"

#pragma warning(disable:4127) // Conditional expression is constant

CLogFile* g_pLogFile;

CMainDialog::CMainDialog(UINT nResID) : CDialog(nResID)
{
	m_bDebug = true;
    g_pLogFile = NULL;

	m_hInstRichEdit = ::LoadLibrary(_T("RICHED32.DLL"));
    if (0 == m_hInstRichEdit)
 		::MessageBox(NULL, _T("CMainDialog::CRichView  Failed to load RICHED32.DLL"), _T(""), MB_ICONWARNING);

	TCHAR tszIniPath[MAX_PATH], tszLogPath[MAX_PATH], tszTmpPath[MAX_PATH];
	//_tcscpy(m_tszCfgPath, thePlugin.GetPluginsConfigDir());

	GetModuleFileName(NULL, m_tszAppPath, MAX_PATH); //�õ���ǰģ��·��
	(_tcsrchr(m_tszAppPath, _T('\\')))[0] = 0;

	_stprintf(tszIniPath, _T("%s%s"), m_tszAppPath, _T("\\Data\\ReciteWords.ini"));
	
	m_pIniFile = new CIniFile(tszIniPath);

	g_bDebug = m_pIniFile->GetBool(_T("Debug"), _T("Enable"));
	if (g_bDebug)
	{
		m_pIniFile->GetString(_T("Debug"), _T("file"), tszLogPath);
        _stprintf(tszLogPath, _T("%s%s"), m_tszAppPath, tszLogPath);
        g_pLogFile = new CLogFile(tszLogPath);
	}
	LOGFUNBGN;
	
	_stprintf(m_tszDataPath, _T("%s%s"), m_tszAppPath, _T("\\Data\\"));

	m_pIniFile->GetString(_T("GUI"), _T("Skin"), tszTmpPath);

	_stprintf(m_tszSkinPath, _T("%s%s"), m_tszAppPath, tszTmpPath);
	_stprintf(m_tszDictPath, _T("%s%s"), m_tszAppPath, _T("\\Dict\\"));	
	_stprintf(m_tszGAudioPath, _T("%s%s"), m_tszAppPath, _T("\\Audio\\Google\\"));

	m_bMore = false;

	//m_pBmpCombox_bk = NULL;
	m_pDCCombox_bk = NULL;
	
	m_pMp3Player = new CMp3Player();
}

CMainDialog::~CMainDialog()
{
	m_pMainDict->UnloadDict();

	delete m_pMainDict;
	delete m_pWord;
	delete m_pStudyMode;

	delete m_pMp3Player;

	//if (m_hBmpCombox_bk != NULL) ::DeleteObject(m_hBmpCombox_bk);
	//if (m_pBmpCombox_bk != NULL) delete m_pBmpCombox_bk;
	//m_pDCCombox_bk->Destroy();
	if (m_pDCCombox_bk != NULL) delete m_pDCCombox_bk;

	Destroy(); // to be sure GetHwnd() returns NULL
	//delete m_pWebBrowser;
	
	::FreeLibrary(m_hInstRichEdit);

	delete m_pIniFile;
    
    if(g_pLogFile != NULL) delete g_pLogFile;
}

BOOL CMainDialog::OnInitDialog()
{
	// Set the Icon
	//SetIconLarge(IDI_MAIN);
	//SetIconSmall(IDI_MAIN);
	
	//InitOptions();

	SetParent(GetReciteWordsApp().GetDialog().GetHwnd());

	BuildFromFile(_T("haha"));

	//SetDlgItemText(IDC_RICHEDIT1, _T("Rich Edit Window"));

	m_hMainMenu = LoadMenu(GetReciteWordsApp().GetInstanceHandle(), MAKEINTRESOURCE(IDM_MAINMENU));
	m_hMainMenu = GetSubMenu(m_hMainMenu, 0);

	OnSize(true);

	SetWindowText(_T("ReciteWords"));

	//FocusEditWord();
	
	m_pMainDict = new CSQLiteDataBase;

	TCHAR tszMainDictPath[MAX_PATH];
	_stprintf(tszMainDictPath, _T("%s%s"), m_tszDictPath, _T("15000.dict"));
	m_pMainDict->LoadDict(tszMainDictPath);
	
	m_pStudyMode = new CStudyMode(m_pIniFile, m_pMainDict);
	m_pWord = new CWord;
	
	GetNextWord();

	//return TRUE;
	return FALSE;
}

//TODO:
//void CMainDialog::OnEidtWord_KeyDown
BOOL CMainDialog::PreTranslateMessage(MSG* pMsg)
{
	if (WM_KEYDOWN == pMsg->message)
	{
		switch (pMsg->wParam)
		{
		case VK_RETURN:
			//ListMore();
			CheckWord();
			return TRUE;
		}
	}
	//else if (WM_LBUTTONDOWN == pMsg->message)
	//{
	//	::ReleaseCapture();

	//}
	return CDialog::PreTranslateMessage(pMsg);
}

INT_PTR CMainDialog::DialogProc(UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	//LOGMSG(_T("DialogProc: %d."), uMsg);
	switch (uMsg)
	{
		case WM_INITDIALOG:
			return OnInitDialog();

		case WM_SIZE:
			OnSize();
			break;

		//case WM_NOTIFY:
		//	NMHDR* pnmh = (NMHDR*) lParam;
		//	if (pnmh->hwndFrom == )
		//	{
		//		if (LOWORD(pnmh->code) == DMN_CLOSE)
		//		{
		//			::SendMessage(, NPPM_SETMENUITEMCHECK, 
		//				funcItem[0]._cmdID, FALSE);
		//			return 0;
		//		}
		//	}
		//	break;
		case WM_LBUTTONDOWN:
			::ReleaseCapture();
			SendMessage(WM_NCLBUTTONDOWN, HTCAPTION, 0);
			break;

		case WM_MOUSEMOVE:
			//m_btnLookup.OnMouseMove(wParam, lParam);
			break;

		case WM_TIMER:
			//OnTimer((UINT_PTR)lParam);
			break;

		case WM_CTLCOLORSTATIC:
			UINT nCtlColor = uMsg - 0x0132;
			return (INT_PTR)OnCtlColor((HDC)wParam, (HWND)lParam, nCtlColor);
	}

	return DialogProcDefault(uMsg, wParam, lParam);
}

void CMainDialog::OnSize(bool bInitial)
{
	if (bInitial)
	{
		CRect r = GetWindowRect();
		//::MoveWindow(GetHwnd(), 0, 0, m_opt.getInt(OPT_VIEW_WIDTH), r.Height(), TRUE);
		return;
	}

	CRect r = GetClientRect();
	const int width = r.Width();
	const int height = r.Height();
	const int left = 2;
	int top = 1;
}

//
BOOL CMainDialog::OnCommand(WPARAM wParam, LPARAM lParam) {
	switch (LOWORD(wParam)) {
		case IDB_MENU:
			//OnMenuClicked();
			break;
		case IDB_MIN:
			//ShowWindow(SW_MINIMIZE);
			break;
		case IDB_CLOSE:
			//PostQuitMessage(0);
			break;

		case IDB_PRONOUNCE:
			// m_edtWord.SetWindowText(_T(""));
			// FocusEditWord();
			OnSpeech();
			break;

		case IDB_GIVEUP:
			//QueryMore(m_edtWord.GetWindowText().c_str());
			m_txtWordData.SetSel(-1, -1);
			m_txtWordData.ReplaceSel(_T("\n"));
			m_txtWordData.SetSel(-1, -1);
			m_txtWordData.ReplaceSel(m_pWord->GetSentences().c_str());
			OnSpeech();
			m_colorFedback = RGB(0, 0, 255);
			m_txtFedback.SetWindowText(_T("Work Hard!"));
			m_edtWord.SetWindowText(m_pWord->GetWord().c_str());
			m_edtWord.SetSel(0, -1, TRUE);
			FocusEditWord();

			m_pWord->IncreaseFamiliar();
			m_pStudyMode->UpdateWord(*m_pWord);
			//GetNextWord();
			break;
	};
	return FALSE;
}

LRESULT CMainDialog::OnNotify(WPARAM wParam, LPARAM lParam) {
	//LOGMSG(_T("Notify: %d."), ((LPNMHDR)lParam)->code);
	switch (((LPNMHDR)lParam)->code) {
	case LVN_COLUMNCLICK:
		//SetSortMode((eTagsSortMode) (TSM_NAME + ((LPNMLISTVIEW) lParam)->iSubItem));
		break;

	case LVN_ITEMACTIVATE:
		break;

	case TVN_SELCHANGED:
		break;

	case NM_DBLCLK:
		//if (IDC_LSTB_WORDS == LOWORD(wParam))
		//	OnWordsLstBoxItemDBClicked();
		break;

	case NM_CLICK:
		//if (IDC_LSTB_WORDS == LOWORD(wParam))
		//	OnWordsLstBoxItemClicked();
		break;
	}
	return 0;
}

void CMainDialog::OnMenuClicked() {
	DWORD dwPos = GetMessagePos();
	CPoint point(LOWORD(dwPos), HIWORD(dwPos));

	TrackPopupMenu(m_hMainMenu, TPM_LEFTBUTTON, point.x, point.y, 0, this->GetHwnd(), NULL);
}

void CMainDialog::OnDestroy() {
	// End the application
	::PostQuitMessage(0);
}

void CMainDialog::BuildFromFile(const TCHAR* file) {
	tString tmpPath;

	m_nHeight = m_pIniFile->GetInteger(_T("GUI"), _T("Height"));
	m_nWidth = m_pIniFile->GetInteger(_T("GUI"), _T("Width"));

	AttachItem(IDB_MENU, m_btnMenu);
	tmpPath = m_tszSkinPath;
	tmpPath = tmpPath + _T("menu_btn.bmp");
	m_btnMenu.Init(tmpPath, 560, 1, 31, 21, true);

	//mHFunMenu = LoadMenu(thePlugin.GetInstanceHandle(), MAKEINTRESOURCE(IDM_FUNCTION_CONTENTITEM));
	//mHFunMenu = GetSubMenu(mHFunMenu, 0);

	AttachItem(IDB_MIN, m_btnMin);
	tmpPath = m_tszSkinPath;
	tmpPath = tmpPath + _T("minimize_btn.bmp");
	m_btnMin.Init(tmpPath, 591, 1, 33, 21, true);

	AttachItem(IDB_MAX, m_btnMax);
	tmpPath = m_tszSkinPath;
	tmpPath = tmpPath + _T("maxmize_btn.bmp");
	m_btnMax.Init(tmpPath, 624, 1, 33, 21, true);

	// AttachItem(IDB_RESTORE, m_btnRestore);
	// tmpPath = tmpPath + _T("restore_btn.bmp");
	// m_btnRestore.Init(tmpPath, 624, 1, 33, 21, true);

	AttachItem(IDB_CLOSE, m_btnClose);
	tmpPath = m_tszSkinPath;
	tmpPath = tmpPath + _T("close_btn.bmp");
	m_btnClose.Init(tmpPath, 657, 1, 43, 21, true);
	//m_btnClose.MoveWindow(103, 63, 428, 26);

	LOGFONT _logfont;
	memset(&_logfont, 0, sizeof(_logfont));
	_logfont.lfHeight = 30;
	_logfont.lfWeight = 0;
	_logfont.lfQuality = CLEARTYPE_QUALITY;
	_logfont.lfPitchAndFamily = FF_DONTCARE;
	_tcscpy(_logfont.lfFaceName, _T("Arial"));

	m_fontEdit.CreateFontIndirect(&_logfont);

	AttachItem(IDC_EDIT_WORD, m_edtWord);
	m_edtWord.MoveWindow(99, 52, 400, 30);
	m_edtWord.SetFocus();
	m_edtWord.SetForegroundWindow();
	m_edtWord.SetFont((HFONT)m_fontEdit.GetHandle());

	AttachItem(IDB_PRONOUNCE, m_btnPronounce);
	m_btnPronounce.MoveWindow(99, 92, 80, 40);

	AttachItem(IDB_GIVEUP, m_btnGiveup);
	m_btnGiveup.MoveWindow(300, 92, 80, 40);

	AttachItem(IDC_WORD_DATA, m_txtWordData);
	
	//CHARFORMAT cf;
	//m_txtWordData.GetSelectionCharFormat(cf);
	//cf.dwMask |= CFM_SIZE | CFM_FACE;
	//cf.yHeight = 30;		//���ø߶�
	//_tcscpy(cf.szFaceName, _T("Arial"));//��������  
	//VERIFY(m_txtWordData.SetSelectionCharFormat(cf));

	m_txtWordData.SetFont(m_fontEdit, FALSE);

	PARAFORMAT2 pf;
	pf.cbSize = sizeof(PARAFORMAT2);
	pf.dwMask = PFM_NUMBERING | PFM_SPACEAFTER | PFM_LINESPACING;
	pf.wNumbering = PFN_BULLET;//ע��PFM_NUMBERING  
	pf.dxOffset = 10;
	pf.dySpaceAfter = 50;				//�μ��
	pf.dyLineSpacing = 25;				//�м��
	VERIFY(m_txtWordData.SetParaFormat(pf));

	m_txtWordData.MoveWindow(1, 142, m_nWidth - 2, 350);

	AttachItem(IDT_FEDBACK, m_txtFedback);
	m_txtFedback.SetFont(m_fontEdit, FALSE);
	m_txtFedback.MoveWindow(20, 500, m_nWidth - 2, 50);

	int w = GetSystemMetrics(SM_CXSCREEN);
	int h = GetSystemMetrics(SM_CYSCREEN);

	MoveWindow(w / 2 - m_nWidth / 2, h / 2 - m_nHeight/2, m_nWidth, m_nHeight);
}
	
void CMainDialog::OnSpeech(bool isUs) {
	const tString wd = m_pWord->GetWord();
	if(false == wd.empty()) {
		tString voicefile = m_tszGAudioPath;
		voicefile += wd.c_str();
		voicefile += _T(".mp3");

		if (TRUE == ::PathFileExists(voicefile.c_str())){
			m_pMp3Player->Load(voicefile.c_str());
			m_pMp3Player->Play();
		}
	}
}

void CMainDialog::FocusEditWord() {
	//m_edtWord.SetSel(0, -1, TRUE);	//select all
	m_edtWord.SetFocus();
}

HBRUSH CMainDialog::OnCtlColor(HDC hDC, HWND hWnd, UINT nCtlColor) {
	CDC* pDC = new CDC(hDC);

	bool tmpWnd = false;

	CWnd* pWnd = GetCWndPtr(hWnd);
	if (NULL != hWnd && 0 == pWnd) {
		pWnd = new CWnd();
		pWnd->Attach(hWnd);
		tmpWnd = true;
		//return 0L;
	}

	switch (nCtlColor) {
	case CTLCOLOR_STATIC:
		switch (pWnd->GetDlgCtrlID()) {
		case IDT_FEDBACK:
			//pDC->SetTextColor(RGB(255, 0, 0));
			pDC->SetTextColor(m_colorFedback);
			pDC->SetBkMode(TRANSPARENT); //�������屳��Ϊ͸��
			// TODO: Return a different brush if the default is not desired
			//return (HBRUSH)::GetStockObject(HOLLOW_BRUSH);  // ���ñ���ɫ
			return (HBRUSH)CreateSolidBrush(RGB(67, 160, 255));
		}
	case CTLCOLOR_DLG:
		RECT rect;
		rect.left = 1;
		rect.top = 22;
		rect.right = 1 + 499;
		rect.bottom = 22 + 38;
		pDC->SolidFill(RGB(255, 255, 255), rect);
		return (HBRUSH)::GetStockObject(NULL_BRUSH);
	}

	pDC->Detach();
	delete pDC;

	if (true == tmpWnd) {
		pWnd->Detach();
		delete pWnd;
	}
	return 0L;
}

void CMainDialog::OnDraw(CDC& dc) {
	//CPaintDC dc(this);
	CRect rect = GetClientRect();
	dc.SolidFill(RGB(67, 160, 255), rect);   //���ñ���

	rect.left = rect.left + 1;
	rect.top = rect.top + 37;
	rect.right = rect.right - 1;
	rect.bottom = rect.bottom - 51;
	dc.SolidFill(RGB(240, 240, 240), rect);
	
	//if (m_pDCCombox_bk != NULL)
	//	dc.StretchBlt(96, 49, 481, 37, m_pDCCombox_bk->GetHDC(), 0, 0, 1, 37, SRCCOPY);
}

void CMainDialog::CheckWord() {
	tString wd = m_edtWord.GetWindowText().c_str();
	if(_tcscmp(wd.c_str(), m_pWord->GetWord().c_str()) == 0){
		m_colorFedback = RGB(0, 255, 0);
		m_txtFedback.SetWindowText(_T("Good!"));
		GetNextWord();
	}
	else {
		//m_pWord->DecreaseFamiliar();
		//m_pStudyMode->UpdateWord(*m_pWord);
		//GetNextWord();
		m_edtWord.SetSel(0, -1, TRUE);	//select all
		m_colorFedback = RGB(255, 0, 0);
		m_txtFedback.SetWindowText(_T("WoW, Wrong Word"));
		OnSpeech();
	}
}

int CMainDialog::GetNextWord() {
	int ret = 0;
	do{
		ret = m_pStudyMode->GetNextWord(*m_pWord);
	} while (2 == ret);
	
	if(1 == ret){
		m_edtWord.SetWindowText(_T(""));
		m_txtWordData.SetWindowText(m_pWord->GetMeaning().c_str());
		//m_colorFedback = RGB(255, 0, 0);
		m_txtFedback.SetWindowText(_T(""));
		OnSpeech();
		FocusEditWord();
	}
	else if(0 == ret){
		m_edtWord.SetWindowText(_T(""));
		m_txtWordData.SetWindowText(_T("Congration! You finish it!"));
	}
	return ret;
}