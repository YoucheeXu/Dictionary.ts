/*******************************************************************************
 * class for reading Ini File on Unix/Linux/Window
*******************************************************************************/

#ifndef __CINIFILE_H__
#define __CINIFILE_H__


//************************* begin of -- include ******************************
//#ifndef _CRT_SECURE_NO_WARNINGS
//#define _CRT_SECURE_NO_WARNINGS
//#endif
//
//#ifndef _CRT_SECURE_NO_DEPRECATE
//#define _CRT_SECURE_NO_DEPRECATE
//#endif
#include "help.h"
#include <stdio.h>   // for FILE
#include <assert.h>
#include <map>
#include <string>
#include <tchar.h>

//************************* **end of -- include ******************************


//************************* begin of -- macro definitions ********************
//#define 	M_MAX_BUFFER_SIZE  6000
#define 	M_MAX_VALUE_BUFFER_SIZE 512
#define 	M_MAX_INTVAL_BUFFER_SIZE  32
//#define 	M_MAX_SECTION_SIZE 32
//************************* **end of -- macro definitions ********************

using namespace std;

class CIniFile
{
public:
	CIniFile(const TCHAR* tszfile);
	~CIniFile();
	
private:
	FILE* m_pFile;	//p_inifile
	//typedef map<tString, tString> keymap;
	map<tString, map<tString, tString>> m_mapData;
	//map<tString, tString>::iterator intertr;
	//bool m_pChanged;
	bool m_bModified;
	TCHAR m_tszfile[MAX_PATH];

public:

	bool GetString(const TCHAR* section, const TCHAR* key, TCHAR* value);
	bool SetString(const TCHAR* section, const TCHAR* key, const TCHAR* value);

	int GetInteger(const TCHAR* section, const TCHAR* key, int default_value = 0);
	bool SetInteger(const TCHAR* section, const TCHAR* key, const int value);

	long GetLong(const TCHAR* section, const TCHAR* key, long default_value = 0);
	bool SetLong(const TCHAR* section, const TCHAR* key, const long value);

	double GetDouble(const TCHAR* section, const TCHAR* key, double default_value = 0);
	bool SetDouble(const TCHAR* section, const TCHAR* key, const double value);

	bool GetBool(const TCHAR* section, const TCHAR* key, bool default_value = false);
	bool SetBool(const TCHAR* section, const TCHAR* key, const bool value);
	
	time_t GetTime(const TCHAR* section, const TCHAR* key, time_t default_value = 0);
	bool SetTime(const TCHAR* section, const TCHAR* key, const time_t value);

private:
	CIniFile(){};
	DISALLOW_COPY_AND_ASSIGN(CIniFile);
	//bool Init(void);
	//int OpenFile(const TCHAR* psz_file);
	int OpenFile(void);
	int CloseFile(void);
};

#endif // __CINIFILE_H__