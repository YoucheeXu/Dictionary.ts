﻿/************************************************************************
 * 项目名称 :  $rootnamespace$  
 * 项目描述 :     
 * 类 名 称 :  $safeitemrootname$
 * 版 本 号 :  v1.0.0.0 
 * 说    明 :     
 * 作    者 :  $username$
 * 创建时间 :  $time$
 * 更新时间 :  $time$
************************************************************************
 * Copyright @ 灵雨工作室 $year$. All rights reserved.
************************************************************************/
#include "stdafx.h"
#include "help.h"

bool g_bDebug = true;
//CLogFile* g_pLogFile;
using namespace std;

TCHAR* _tcstrim(TCHAR* str)
{
	//TCHAR* newstr;
	TCHAR newstr[256];
	int len = _tcslen(str);
	if (len == 1) return str;
	//newstr = new TCHAR[len];
	int j = 0;
	for (int i = 0; str[i] != _T('\0'); i++)
	{
		if (str[i] == _T(' ') || str[i] == _T('\n')) continue;
		newstr[j] = str[i];
		j++;
	}
	newstr[j] = _T('\0');
	_tcscpy(str, newstr);
	//delete newstr;
	return str;
}

void StringTrimLeft(tString& str)
{
	const tString drop1 = _T(" ");
	const tString drop2 = _T("　");
	const tString drop3 = _T("\n");

	str.erase(0, str.find_first_not_of(drop1));
	str.erase(0, str.find_first_not_of(drop2));
	str.erase(0, str.find_first_not_of(drop3));
}

void StringTrimRight(tString& str)
{
	const tString drop1 = _T(" ");
	const tString drop2 = _T("　");
	const tString drop3 = _T("\n");

	str.erase(str.find_last_not_of(drop1) + 1);
	str.erase(str.find_last_not_of(drop2) + 1);
	str.erase(str.find_last_not_of(drop3) + 1);
}

void StringTrim(tString& str)
{
	StringTrimLeft(str);
	StringTrimRight(str);
}


void StringReplace(tString& tOrg, const TCHAR* tszFrom, const TCHAR* tszTo)
{
	int pos = tOrg.find(tszFrom);
	int len = _tcslen(tszFrom);
	if (tString::npos != pos)
	{
		tOrg.replace(pos, len, tszTo);
		//pos = tOrg.find(tszFrom);
	}
}

int StringReplaceAll(tString& tOrg, const TCHAR* tszFrom, const TCHAR* tszTo)
{
	bool bDebug = true;
	//LOGINFO(_T("%s,\n %s, %s."), tOrg, tszFrom, tszTo);
	tString::size_type pos = tOrg.find(tszFrom);
	int len = _tcslen(tszFrom);

	int count = 0;
	while(tString::npos != pos)
	{
		count++;
		tOrg.replace(pos, len, tszTo);
		pos = tOrg.find(tszFrom);
	}
	return count;
}

//int StringRegReplaceAll(tString& tOrig, wregex regExpress, const TCHAR* tszReplace)
//{	
//	return NULL;
//}

void StringErase(tString& tOrg, const TCHAR* tszDrop)
{
	int pos = tOrg.find(tszDrop);
	int len = _tcslen(tszDrop);
	if (pos != tString::npos) tOrg.erase(pos, len);
}

int StringEraseAll(tString& tOrg, const TCHAR* tszDrop)
{
	int pos = tOrg.find(tszDrop);
	int len = _tcslen(tszDrop);
	
	int count = 0;
	while(pos != tString::npos)
	{
		count++;
		tOrg.erase(pos, len);
		pos = tOrg.find(tszDrop);
	}
	return count;
}