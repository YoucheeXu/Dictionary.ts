#ifndef IDC_STATIC
#define IDC_STATIC (-1)
#endif

#define IDD_RECITEWORDS                         101
#define IDI_MAIN								102
#define IDD_ABOUT                               103
#define IDM_MAINMENU                            105
#define IDT_CAPTION                             40000
#define IDB_MENU                                40001
#define IDB_MIN                                 40002
#define IDB_MAX                                 40003
#define IDB_CLOSE                               40004
#define IDB_PRONOUNCE                           40005
#define IDB_GIVEUP                              40006
#define IDC_EDIT_WORD                           40011
#define IDC_LSTB_WORDS                          40012
#define IDC_WORD_DATA							40013
#define IDT_FEDBACK								40014

#define IDD_FULLSCREEN							201

#define IDM_TOP                                 40100
#define IDM_NEWWORD								40110
#define IDM_EDITWORD                            40120
#define IDM_DELWORD                             40130
