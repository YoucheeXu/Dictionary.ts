//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by resource.rc
//
#define IDD_DICT                        101
#define IDI_MAIN                        102
#define IDD_ABOUT                       103
#define IDM_MAINMENU                    105
#define IDC_WB_DATA                     40000
#define IDC_PANEL_INPUT                 40009
#define IDC_EDIT_WORD                   40011
#define IDC_LSTB_WORDS                  40012
#define IDM_TOP                         40100
#define IDM_NEWWORD                     40110
#define IDM_EDITWORD                    40120
#define IDM_DELWORD                     40130
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
