//DictApp.h
#ifndef _DictApp_H_
#define _DictApp_H_

#include "DictDlg.h"

class CDictApp : public CWinApp
{
public:
	CDictApp();
	virtual ~CDictApp();

public:	
	//void Initialize(HINSTANCE hInstance);
	//void Uninitialize();
	virtual BOOL InitInstance();
	CDictDlg* GetDialog() { return &m_MyDialog; }

private:
	CDictDlg m_MyDialog;
	bool GetCommandStr();
};

// returns a pointer to the CDialogApp object
inline CDictApp& GetDialogApp() { return static_cast<CDictApp&>(GetApp()); }

#endif//_DictApp_H_