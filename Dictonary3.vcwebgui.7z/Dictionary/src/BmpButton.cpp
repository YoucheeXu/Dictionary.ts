#include "stdafx.h"
#include "BmpButton.h"
#include "LogFile.h"

#define BTN_NORMAL 0
#define BTN_FOCUSED 1
#define BTN_CLICKED 2
#define BTN_DISABLE 3

CBmpButton::CBmpButton()
{
	m_bInRect = false;
	m_b3States = true;
	//m_bInited = false;
	
	m_hScrBmp = NULL;
	//m_hNormalBmp = NULL;
	//m_hFocusedBmp = NULL; 
	//m_hClickedBmp = NULL;
	//m_hDisableBmp = NULL;
}

CBmpButton::~CBmpButton()
{
	// if (m_pBmpAllBits != NULL)
	// {
		// delete[] m_pBmpAllBits;
		// m_pBmpAllBits = NULL;
	// }

	if (m_hScrBmp != NULL) ::DeleteObject(m_hScrBmp);
	//if(m_hNormalBmp != NULL) ::DeleteObject(m_hNormalBmp);
	//if(m_hFocusedBmp != NULL) ::DeleteObject(m_hFocusedBmp);
	//if(m_hClickedBmp != NULL) ::DeleteObject(m_hClickedBmp);
	//if(m_hDisableBmp != NULL) ::DeleteObject(m_hDisableBmp);

	DeleteDC(m_hScrDC);
}

void CBmpButton::Init(tString bmpfile, int x, int y, int w, int h, bool is3States)
{
	//bmp = System.Drawing.Bitmap.FromFile(bmpfile)
	////bmp.MakeTransparent(Color.FromArgb(240, 240, 240))
	////bmp.MakeTransparent()
	//Me.Width = w
	//Me.Height = h
	
	m_nWidth = w;
	m_nHeight = h;
	m_b3States = is3States;

	assert(LoadFromFile(bmpfile.c_str()));

	//m_rectButton.left = x;
	//m_rectButton.top = y;
	//m_rectButton.right = x + w;
	//m_rectButton.bottom = y + h;

	// m_bmpNormal = CutImage(New Point(0, 0), New Point(Width, Height - 1), bmp)
	// CutBmp(CPoint(0, 0), CPoint(w, h - 1), m_bmpNormal);
	// CutBmp(0, 0, m_hNormalBmp);
	//m_hNormalBmp = CutBmp(0, 0);

	//m_hFocusedBmp = CutBmp(w, 0);

	//m_bmpClicked = CutImage(New Point(Width * 2, 0), New Point(Width * 3 - 1, Height - 1), bmp)
	// CutBmp(CPoint(w * 2, 0), CPoint(w * 3 - 1, h - 1), m_bmpClicked);
	//CutBmp(2*w, 0, m_hClickedBmp);
	//m_hClickedBmp = CutBmp(2 * w, 0);

	//m_bmpDisable = CutImage(New Point(Width * 3, 0), New Point(Width * 4 - 1, Height - 1), bmp)
	//if (false == m_b3states)
	//{
	//	// CutBmp(CPoint(w * 3, 0), CPoint(w * 4 - 1, h - 1), m_bmpDisable);
	//	//CutBmp(3*w, 0, m_hDisableBmp);
	//	m_hDisableBmp = CutBmp(3*w, 0);
	//}

	// DeleteDC(hScrDC);

	//Me.BackgroundImage = m_bmpNormal
	// this->SetBitmap((HBITMAP)m_bmpNormal);
	//SetBitmap(m_hNormalBmp);
	//SetBitmap(m_hNormalBmp);

	//SetButtonStyle(BS_BITMAP | BS_FLAT | WS_EX_TRANSPARENT, TRUE);
	//m_bInited = true;

	m_nState = BTN_NORMAL;
	MoveWindow(x, y, w, h);
	//SetWindowPos(&wndTop, x, y, w, h, SWP_SHOWWINDOW);
}

bool  CBmpButton::LoadFromFile(const TCHAR* bmpfile)
{
	// CDC* dcMem; //��ֵʡ��
	// //CBitmap bmp;
	// //if (FALSE == bmp.LoadBitmap(file))
	// //{
	// //	LOGINFO(_T("Can't load %s."), file);
	// //	return false;
	// //}
	// BITMAP bmptemp = { 0 };
	// //HBITMAP hbmp = (HBITMAP)bmp;
	// HBITMAP hBmp = (HBITMAP)::LoadImage(GetApp()->GetInstanceHandle(), file, 0, 0, 0, LR_LOADFROMFILE);
	// assert(hBmp);
	// if (!::GetObject(hBmp, sizeof(BITMAP), (LPBYTE)&bmptemp)) return false;
	// BYTE imgSize = bmptemp.bmBitsPixel / 8; //����24bit��32bitλͼ
	// // ����λͼ��Ϣ   
	// BITMAPINFO bi;
	// bi.bmiHeader.biSize = sizeof(bi.bmiHeader);
	// bi.bmiHeader.biWidth = bmptemp.bmWidth;
	// bi.bmiHeader.biHeight = bmptemp.bmHeight;
	// bi.bmiHeader.biPlanes = 1;
	// bi.bmiHeader.biBitCount = bmptemp.bmBitsPixel;
	// bi.bmiHeader.biCompression = BI_RGB;
	// bi.bmiHeader.biSizeImage = bmptemp.bmWidth * imgSize * bmptemp.bmHeight;
	// bi.bmiHeader.biClrUsed = 0;
	// bi.bmiHeader.biClrImportant = 0;

	// // ��ȡλͼ����   
	// CClientDC hdc(this);
	// BYTE* m_pBmpAllBits = new BYTE[bi.bmiHeader.biSizeImage];
	// ::ZeroMemory(m_pBmpAllBits, bi.bmiHeader.biSizeImage);
	// if (!::GetDIBits(hdc, hBmp, 0, bmptemp.bmHeight, m_pBmpAllBits, &bi, DIB_RGB_COLORS))
	// //if (!bmp.GetDIBits(hdc, 0, bmptemp.bmHeight, m_pBmpAllBits, &bi, DIB_RGB_COLORS)
	// {
		// delete[] m_pBmpAllBits;
		// m_pBmpAllBits = NULL;
		// return false;
	// }
	// return true;

	m_hScrBmp = (HBITMAP)LoadImage(NULL,  //Ӧ�ó���ʵ��   
		bmpfile,     //·��
		IMAGE_BITMAP,
		0,        //�������0,��˲���ָ��bitmap�Ŀ�(λͼ������)  
		0,        //�������0,��˲���ָ��bitmap�ĸ�(λͼ������)  
		LR_LOADFROMFILE | LR_CREATEDIBSECTION | LR_DEFAULTSIZE);
	
	if(NULL == m_hScrBmp) return false;

	m_hScrDC = CreateCompatibleDC(NULL);  //�����ڴ��豸������
	SelectObject(m_hScrDC, m_hScrBmp);

	if (NULL == m_hScrDC) return false;

	return true;
}

/* bool CBmpButton::CutBmp(CPoint start, CPoint ends, CBitmap &newbmp)
{
	//Dim f As New Bitmap(ends.X - start.X + 1, ends.Y - start.Y + 1)
	//newbmp.SetBitmapDimensionEx(ends.x - start.x + 1, ends.y - start.y + 1);
	
	//	For i As Integer = start.X To ends.X
	//	For j As Integer = start.Y To ends.Y
	//		Dim c As Color = b.GetPixel(i, j)
	//		f.SetPixel(i - start.X, j - start.Y, c)
	//	Next
	//Next
	//Return f 

	// int imgSize = 4;

	// HBITMAP hNewbmp = (HBITMAP)newbmp;

	// int newHeight = ends.y - start.y + 1;
	// int newWidth = ends.x - start.x + 1;

	// long newSizeByte = newHeight * newWidth * imgSize;
	// BYTE* lpNewBmpBits = new BYTE[newSizeByte];
	// int temp = 0;
	// BYTE buffer = 0;
	// for (int j = newHeight - 1; j >= 0; j--)
	// {
		// for (int i = newWidth - 1; i >= 0; i--)
		// {
			// buffer = m_pBmpAllBits[(j * newWidth + i) * imgSize];
			// memcpy(&lpNewBmpBits[temp++], &buffer, 1);
		// }
	// }

	// // ����λͼ��Ϣ   
	// BITMAPINFO newBi;
	// newBi.bmiHeader.biSize = sizeof(newBi.bmiHeader);
	// newBi.bmiHeader.biWidth = newWidth;
	// newBi.bmiHeader.biHeight = newHeight;
	// newBi.bmiHeader.biPlanes = 1;
	// newBi.bmiHeader.biBitCount = 32;
	// newBi.bmiHeader.biCompression = BI_RGB;
	// newBi.bmiHeader.biSizeImage = newSizeByte;
	// newBi.bmiHeader.biClrUsed = 0;
	// newBi.bmiHeader.biClrImportant = 0;

	// CClientDC hdc(this);
	// int ret = ::SetDIBits(hdc, hNewbmp, 0, newHeight, lpNewBmpBits, &newBi, DIB_RGB_COLORS);

	// delete [] lpNewBmpBits;
	// lpNewBmpBits = NULL;

	// return ret;
}*/
//
//bool CBmpButton::CutBmp(int x, int y, HBITMAP& hBmp)
//{
//	return false;
//}

/* HBITMAP CBmpButton::CutBmp(int x, int y)
//{
//	bool ret = false;
//	//�Ѿ����m_hScrDC����
//	//HDC hScrDC = CreateCompatibleDC(NULL);  //�����ڴ��豸������
//
//	SelectObject(m_hScrDC, m_hScrBmp);
//
//	HDC hMemDC = CreateCompatibleDC(NULL); 
//
//	//����һ������Ļ�豸���������ݵ�λͼ,����ǵõ���::DeleteObject(hBitmap);
//	//hBitmap = CreateCompatibleBitmap(hScrDC, rectWidth, RectHeight); 
//	HBITMAP hBmp = CreateCompatibleBitmap(m_hScrDC, m_nWidth, m_nHeight);
//	
//	//��λͼѡ���ڴ��豸������
//	HBITMAP hTmpBitmap = (HBITMAP)SelectObject(hMemDC, hBmp);
//
//	//��rectָ����ͼ�鿽�����ڴ��豸������
//	ret = BitBlt(hMemDC, 0, 0, m_nWidth, m_nHeight, m_hScrDC, x, y, SRCCOPY);
//
//	if (false == ret) return NULL;
//
//	//��ͼƬ�ŵ�hBmp��
//	hBmp = (HBITMAP)SelectObject(hMemDC, hTmpBitmap);
//
//	DeleteDC(hMemDC);
//	//DeleteDC(hScrDC);
//
//	return hBmp;
}*/

//TODO: OnMouseLeave / OnMouseEnter
void CBmpButton::OnMouseMove(WPARAM wParam, LPARAM lParam)
{
	CPoint point(GET_X_LPARAM(lParam), GET_Y_LPARAM(lParam));
	CRect rect = GetClientRect();

	if (!m_bInRect || GetCapture() != *this)     //�����밴ť
	{
		m_bInRect = true;     //���ý����־
		SetCapture();        //�������
		//m_Style = 1;         //���ð�ť״̬
		//SetBitmap(m_hFocusedBmp);
		m_nState = BTN_FOCUSED;
		Invalidate();        //�ػ水ť
	}
	else if (!rect.PtInRect(point))     //����뿪��ť
	{
		m_bInRect = false;    //��������־
		ReleaseCapture();    //�ͷŲ�������
		//m_Style = 0;         //���ð�ť״̬
		//SetBitmap(m_hNormalBmp);
		m_nState = BTN_NORMAL;
		Invalidate();        //�ػ水ť
	}
}

//void CBmpButton::OnMouseEnter()
//{
//	// this->SetBitmap((HBITMAP)m_bmpFocused);
//	this->SetBitmap(m_hFocusedBmp);
//}
//
//void CBmpButton::OnMouseLeave()
//{
//	// this->SetBitmap((HBITMAP)m_bmpNormal);
//	this->SetBitmap(m_hNormalBmp);
//}
//
void CBmpButton::OnLButtonDown(WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(wParam);
	UNREFERENCED_PARAMETER(lParam);

	// this->SetBitmap((HBITMAP)m_bmpClicked);
	//this->SetBitmap(m_hClickedBmp);
	m_nState = BTN_CLICKED;
}

void CBmpButton::OnLButtonUp(WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(wParam);
	UNREFERENCED_PARAMETER(lParam);

	// this->SetBitmap((HBITMAP)m_bmpFocused);
	// this->SetBitmap((HBITMAP)m_bmpFocused);
	//this->SetBitmap(m_hFocusedBmp);
	m_nState = BTN_FOCUSED;
}

LRESULT CBmpButton::OnMessageReflect(UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch (uMsg)
	{
	case WM_DRAWITEM:
		//OnDrawItem();
		int idCtrl = (UINT)wParam;
		LPDRAWITEMSTRUCT lpDrawItemStruct = (LPDRAWITEMSTRUCT)lParam;
		OnDrawItem(lpDrawItemStruct);
		return 1L;
	}
	return 0L;
}

void CBmpButton::OnDrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct)
{
	//CRect rect = GetWindowRect();
	//CBitmap bmp;
	//if (TRUE == IsWindowEnabled() && false == m_b3states)
	//{
	//	bmp.FromHandle(m_hDisableBmp);
	//}
	//else bmp.FromHandle(m_hNormalBmp);
	//CDC* pDC = CDC::FromHandle(lpDrawItemStruct->hDC);
	//pDC->DrawBitmap(rect.left, rect.top, m_nWidth, m_nHeight, bmp, 0);
	//CutBmp(CPoint(w * 3, 0), CPoint(w * 4 - 1, h - 1), m_bmpDisable);
	BitBlt(lpDrawItemStruct->hDC, 0, 0, m_nWidth, m_nHeight, m_hScrDC, m_nWidth*m_nState, 0, SRCCOPY);
}

LRESULT CBmpButton::WndProc(UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	//LOGMSG(_T("Button MSG: %d"), uMsg);
	if (FALSE == IsWindowEnabled()) m_nState = BTN_DISABLE;
	switch (uMsg)
	{
		case WM_MOUSEMOVE:		OnMouseMove(wParam, lParam);	break;
		case WM_LBUTTONDOWN:	OnLButtonDown(wParam, lParam);	break;
		case WM_LBUTTONUP:		OnLButtonUp(wParam, lParam);	break;
	}
	
	return WndProcDefault(uMsg, wParam, lParam);
}

//void CBmpButton::NotifyFocused(bool bFocused)
//{
//	if (true == bFocused) SetBitmap(m_hFocusedBmp);
//	else SetBitmap(m_hNormalBmp);
//}