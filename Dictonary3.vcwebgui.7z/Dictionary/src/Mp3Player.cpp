//Mp3Player.cpp
#include "stdafx.h"
#include "Mp3Player.h"
#include <uuids.h>
  
CMp3Player::CMp3Player()
{
    m_pIGB = NULL;
    m_pIMC = NULL;
    m_pIMEx = NULL;
    m_pIBA = NULL;
    m_pIMS = NULL;
    m_bReady = false;
    m_nDuration = 0;
}
  
CMp3Player::~CMp3Player()
{
    Cleanup();
}
  
void CMp3Player::Cleanup()
{
    if (m_pIMC) m_pIMC->Stop();
  
    if(m_pIGB)
    {
        m_pIGB->Release();
        m_pIGB = NULL;
    }
  
    if(m_pIMC)
    {
        m_pIMC->Release();
        m_pIMC = NULL;
    }
  
    if(m_pIMEx)
    {
        m_pIMEx->Release();
        m_pIMEx = NULL;
    }
  
    if(m_pIBA)
    {
        m_pIBA->Release();
        m_pIBA = NULL;
    }
  
    if(m_pIMS)
    {
        m_pIMS->Release();
        m_pIMS = NULL;
    }
    m_bReady = false;
}
  
bool CMp3Player::Load(LPCWSTR szFile)
{
    Cleanup();
    m_bReady = false;
    if (SUCCEEDED(CoCreateInstance( CLSID_FilterGraph,
        NULL,
        CLSCTX_INPROC_SERVER,
        IID_IGraphBuilder,
        (void **)&this->m_pIGB)))
    {
        m_pIGB->QueryInterface(IID_IMediaControl, (void **)&m_pIMC);
        m_pIGB->QueryInterface(IID_IMediaEventEx, (void **)&m_pIMEx);
        m_pIGB->QueryInterface(IID_IBasicAudio, (void**)&m_pIBA);
        m_pIGB->QueryInterface(IID_IMediaSeeking, (void**)&m_pIMS);
  
        HRESULT hr = m_pIGB->RenderFile(szFile, NULL);
        if (SUCCEEDED(hr))
        {
            m_bReady = true;
            if(m_pIMS)
            {
                m_pIMS->SetTimeFormat(&TIME_FORMAT_MEDIA_TIME);
                m_pIMS->GetDuration(&m_nDuration); // returns 10,000,000 for a second.
                // m_nDuration = m_nDuration;
            }
        }
    }
    return m_bReady;
}
  
bool CMp3Player::Play()
{
    if (m_bReady && m_pIMC)
    {
        HRESULT hr = m_pIMC->Run();
        return SUCCEEDED(hr);
    }
    return false;
}
  
bool CMp3Player::Pause()
{
    if (m_bReady && m_pIMC)
    {
        HRESULT hr = m_pIMC->Pause();
        return SUCCEEDED(hr);
    }
    return false;
}
  
bool CMp3Player::Stop()
{
    if (m_bReady && m_pIMC)
    {
        HRESULT hr = m_pIMC->Stop();
        return SUCCEEDED(hr);
    }
    return false;
}
  
bool CMp3Player::WaitForCompletion(long msTimeout, long* EvCode)
{
    if (m_bReady && m_pIMEx)
    {
        HRESULT hr = m_pIMEx->WaitForCompletion(msTimeout, EvCode);
        return *EvCode > 0;
    }
  
    return false;
}
  
bool CMp3Player::SetVolume(long vol)
{
    if (m_bReady && m_pIBA)
    {
        HRESULT hr = m_pIBA->put_Volume(vol);
        return SUCCEEDED(hr);
    }
    return false;
}
  
long CMp3Player::GetVolume()
{
    if (m_bReady && m_pIBA)
    {
        long vol = -1;
        HRESULT hr = m_pIBA->get_Volume(&vol);

        if(SUCCEEDED(hr)) return vol;
    }
  
    return -1;
}
  
__int64 CMp3Player::GetDuration()
{
    return m_nDuration;
}
  
__int64 CMp3Player::GetCurrentPosition()
{
    if (m_bReady && m_pIMS)
    {
        __int64 nCurpos = -1;
        HRESULT hr = m_pIMS->GetCurrentPosition(&nCurpos);
  
        if(SUCCEEDED(hr)) return nCurpos;
    }
  
    return -1;
}
  
bool CMp3Player::SetPositions(__int64* pCurrent, __int64* pStop, bool bAbsolutePositioning)
{
    if (m_bReady && m_pIMS)
    {
        DWORD dwflags = 0;
        if(bAbsolutePositioning)
            dwflags = AM_SEEKING_AbsolutePositioning | AM_SEEKING_SeekToKeyFrame;
        else
            dwflags = AM_SEEKING_RelativePositioning | AM_SEEKING_SeekToKeyFrame;
  
        HRESULT hr = m_pIMS->SetPositions(pCurrent, dwflags, pStop, dwflags);
  
        if(SUCCEEDED(hr)) return true;
    }  
    return false;
}