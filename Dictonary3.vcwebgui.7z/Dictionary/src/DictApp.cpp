#include "stdafx.h"
#include "DictApp.h"
#include "resource.h"
#include "GDictBase.h"

// global vars
bool g_bDebug;
CLogFile* g_pLogFile;

CDictApp::CDictApp() : m_MyDialog(IDD_DICT)
{
}

CDictApp::~CDictApp()
{
	//Uninitialize();
}

BOOL CDictApp::InitInstance()
{
	//get command line	
	if(false == GetCommandStr()) {
		//Display the Modal Dialog
		m_MyDialog.DoModal();
	}
	return TRUE;
}

bool CDictApp::GetCommandStr()
{
	LPWSTR *szArglist = NULL;   
	int nArgs = 0;   
	szArglist = CommandLineToArgvW(GetCommandLineW(), &nArgs);

	if(nArgs >= 2)
	{   
		//szArglist就是保存参数的数组
		//nArgs是数组中参数的个数		//数组的第一个元素表示进程的path，也就是szArglist[0]，其他的元素依次是输入参数。
		CDictBase* pDictBase = m_MyDialog.GetDictBase();
		pDictBase->QueryWrod(szArglist[1]);

		//取得参数后，释放CommandLineToArgvW申请的空间
		LocalFree(szArglist);
		return true;
	}
	return false;
}

//void CDictApp::Initialize(HINSTANCE hInstance)
//{    
//	SetResourceHandle(hInstance);
//	mHTabIcon = (HICON) ::LoadImage( hInstance, 
//		MAKEINTRESOURCE(IDC_LV_CV), IMAGE_ICON, 0, 0, 
//		LR_LOADMAP3DCOLORS | LR_LOADTRANSPARENT );
//	//m_TB_Icon.hToolbarBmp = (HBITMAP) ::LoadImage( hInstance,
//	// MAKEINTRESOURCE(IDB_TAGSVIEW), IMAGE_BITMAP, 0, 0, 
//	// LR_DEFAULTSIZE | LR_LOADMAP3DCOLORS );
//}

//void CDictApp::Uninitialize()
//{
//	if (mHTabIcon)
//	{
//		::DestroyIcon(mHTabIcon);
//		mHTabIcon = NULL;
//	}
//	//if ( m_TB_Icon.hToolbarBmp )
//	//{
//	//    ::DeleteObject(m_TB_Icon.hToolbarBmp);
//	//    m_TB_Icon.hToolbarBmp = NULL;
//	//}
//}