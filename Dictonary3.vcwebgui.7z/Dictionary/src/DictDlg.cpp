//DictDlg.cpp
#include "stdafx.h"
#include "DictApp.h"

#include "resource.h"

#include <wininet.h>
#define ERR_MSG_LEN 512
#define BUFFER_LEN  256
#pragma comment(lib, "wininet.lib")
#include "DictDlg.h"

#pragma warning(disable:4127) // Conditional expression is constant

CDictDlg::CDictDlg(UINT nResID) : CDialog(nResID)
{
	m_bDebug = true;
	m_bDelete = false;

	TCHAR tszIniPath[MAX_PATH], tszLogPath[MAX_PATH], tszTmpPath[MAX_PATH];

	GetModuleFileName(NULL, m_tszAppPath, MAX_PATH); //�õ���ǰģ��·��
	(_tcsrchr(m_tszAppPath, _T('\\')))[0] = 0;

	_stprintf(tszIniPath, _T("%s%s"), m_tszAppPath, _T("\\Data\\Dictionary.ini"));
	
	m_pIniFile = new CIniFile(tszIniPath);

	g_bDebug = m_pIniFile->GetBool(_T("Debug"), _T("Enable"));
	if (true == g_bDebug)
	{
		m_pIniFile->GetString(_T("Debug"), _T("file"), tszTmpPath);

		_stprintf(tszLogPath, _T("%s%s"), m_tszAppPath, tszTmpPath);

		g_pLogFile = new CLogFile(tszLogPath);
		LOGINFO(_T("LogDir: %s"), tszLogPath);
	}

	_stprintf(m_tszDataPath, _T("%s%s"), m_tszAppPath, _T("\\Data\\"));
	//_stprintf(m_tszDictPage, _T("%s%s"), m_tszDataPath, _T("Query\\dict.html"));

	m_pIniFile->GetString(_T("GUI"), _T("Skin"), tszTmpPath);

	_stprintf(m_tszSkinPath, _T("%s%s"), m_tszAppPath, tszTmpPath);
	_stprintf(m_tszDictPath, _T("%s%s"), m_tszAppPath, _T("\\Dict"));	
	_stprintf(m_tszAudioPath, _T("%s%s"), m_tszAppPath, _T("\\Audio"));

	m_bAgent = m_pIniFile->GetBool(_T("Agent"), _T("Agent"));

	if (true == m_bAgent)
	{
		m_pIniFile->GetString(_T("Agent"), _T("ip"), tszTmpPath);
		_stprintf(m_tszProxyAddress, _T("%s%s"), _T("HTTP=http://"), tszTmpPath);
        LOGINFO(_T("agenet address: %s"), m_tszProxyAddress);
	}

	m_bMore = false;
	//m_nDictTimer = 100;

	m_pDCCombox_bk = NULL;
	
	m_pMp3Player = new CMp3Player();
}

CDictDlg::~CDictDlg()
{
	m_pGDict->Unload();
	delete m_pIniFile;
	delete m_pGDict;
	delete m_pMp3Player;

	if (m_pDCCombox_bk != NULL) delete m_pDCCombox_bk;

	Destroy(); // to be sure GetHwnd() returns NULL
	//delete m_pWebBrowser;
	
	if (g_pLogFile != NULL) delete g_pLogFile;
}

BOOL CDictDlg::OnInitDialog()
{
	// Set the Icon
	SetIconLarge(IDI_MAIN);
	SetIconSmall(IDI_MAIN);
	
	//InitOptions();

	BuildFromFile(_T("haha"));

	m_pGDict = new CGDictBase(this);
	m_pGDict->Load(m_tszDictPath, m_tszAudioPath);

	m_hMainMenu = LoadMenu(GetDialogApp().GetInstanceHandle(), MAKEINTRESOURCE(IDM_MAINMENU));
	m_hMainMenu = GetSubMenu(m_hMainMenu, 0);

	OnSize(true);

	//FocusEditWord();

	return TRUE;
}

BOOL CDictDlg::PreTranslateMessage(MSG& msg)
{
	if (WM_KEYDOWN == msg.message)
	{
		switch (msg.wParam)
		{
		case VK_RETURN:
			//KillTimer(m_nDictTimer);
			//ListMore();
			//QueryMore(m_edtWord.GetWindowText().c_str());
			//return TRUE;
			if (m_bDelete == false) {
				m_webBrowser.InvokeScript(_T("query_word"), 0);
			}
			m_bDelete = false;
			return CDialog::PreTranslateMessage(msg);
			break;
		case VK_DELETE:
			tString word; //= m_edtWord.GetWindowText().c_str();
			//m_webBrowser.GetInnerHtmlByID(_T("btn_close"), word);
			VARIANT var = m_webBrowser.InvokeScript(_T("get_word"), 0);
			if (var.vt == VT_BSTR) {
				word = BSTRtoT(var.bstrVal);
			}

			if (word.length() <= 1) {
				LOGERR(_T("Can't get input word!"));
				return FALSE;
			}
			BOOL ret = FALSE;
			if (::GetKeyState(VK_SHIFT) < 0)
			{
				//'Call OnDelJSON(m_edtWord.Text, false);
				ret = m_pGDict->DelWord(word.c_str());
				//m_edtWord.SetWindowText(_T(""));
				tString retJ = TRUE == ret ? _T("Dict was deleted!") : _T("Dict was not deleted!");
				m_bDelete = true;
				MessageBox(retJ.c_str(), word.c_str(), MB_OK);
				m_webBrowser.InvokeScript(_T("clear_input"), 0);
			}
			else if (::GetKeyState(VK_CONTROL) < 0)
			{
				//m_edtWord.SetWindowText(_T(""));
				ret = m_pGDict->DelAudio(word.c_str());
				tString retA = TRUE == ret ? _T("Audio was deleted!\n") : _T("Audio not deleted!\n");
				ret = m_pGDict->DelWord(word.c_str());
				tString retJ = TRUE == ret ? _T("Dict was deleted!") : _T("Dict was not deleted!");
				m_bDelete = true;
				MessageBox((retA + retJ).c_str(), word.c_str(), MB_OK);
				m_webBrowser.InvokeScript(_T("clear_input"), 0);
			}
			break;
		}
	}

		// This was stolen from an SDI app using a form view.  
	//  
	// Pass keyboard messages along to the child window that has the focus.  
	// When the browser has the focus, the message is passed to its containing  
	// CAxWindow, which lets the control handle the message.  
	if ((msg.message < WM_KEYFIRST || msg.message > WM_KEYLAST) &&
		(msg.message < WM_MOUSEFIRST || msg.message > WM_MOUSELAST))
		return FALSE;
	HWND hWndCtl = ::GetFocus();

	if (IsChild(hWndCtl))
	{
		// find a direct child of the dialog from the window that has focus  
		while (::GetParent(hWndCtl) != m_hWnd)
			hWndCtl = ::GetParent(hWndCtl);
		// give control a chance to translate this message
		// if(::SendMessage(hWndCtl, WM_FORWARDMSG, 0, (LPARAM)pMsg) != 0)
		//if(::SendMessage (m_webBrowser.GetHwnd(), msg.message, msg.wParam, msg.lParam) != 0)
		//	return TRUE;
		m_webBrowser.PreTranslateMessage(msg);
	}
	// A normal control has the focus, so call IsDialogMessage() so that  
	// the dialog shortcut keys work (TAB, etc.)  
	// return IsDialogMessage(msg);

	return CDialog::PreTranslateMessage(msg);
}

INT_PTR CDictDlg::DialogProc(UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	//LOGMSG(_T("DialogProc: %d."), uMsg);
	switch (uMsg)
	{
		case WM_INITDIALOG:
			return OnInitDialog();

		case WM_SIZE:
			OnSize();
			break;

		case WM_LBUTTONDOWN:
			::ReleaseCapture();
			SendMessage(WM_NCLBUTTONDOWN, HTCAPTION, 0);
			break;

		case WM_MOUSEMOVE:
			//m_btnLookup.OnMouseMove(wParam, lParam);
			break;
		
		case WM_TIMER:
			//OnTimer((UINT_PTR)lParam);
			break;
	}

	return DialogProcDefault(uMsg, wParam, lParam);
}

void CDictDlg::OnSize(bool bInitial)
{
	if (bInitial)
	{
		CRect r = GetWindowRect();
		//::MoveWindow(GetHwnd(), 0, 0, m_opt.getInt(OPT_VIEW_WIDTH), r.Height(), TRUE);
		return;
	}

	CRect r = GetClientRect();
	const int width = r.Width();
	const int height = r.Height();
	const int left = 2;
	int top = 1;
}

//
BOOL CDictDlg::OnCommand(WPARAM wParam, LPARAM lParam)
{
	switch (LOWORD(wParam))
	{
		//case IDC_EDIT_WORD:
		//	if(EN_CHANGE == HIWORD(wParam)) OnEidtWord_TextChanged();
		//	break;
	};
	
	// Handle notification WM_COMMAND from CEdit
	/*if((HWND)lParam == m_lstWords.GetHwnd())
	{
		switch(HIWORD(wParam))
		{
		case CBN_SELCHANGE:
			// User made selection from list
			{
				OnWordsLstBoxItemClicked();
			}
			return TRUE;
		};
	};*/
	return FALSE;
}

LRESULT CDictDlg::OnNotify(WPARAM wParam, LPARAM lParam)
{
	//LOGMSG(_T("Notify: %d."), ((LPNMHDR)lParam)->code);
	switch (((LPNMHDR)lParam)->code)
	{
	case LVN_COLUMNCLICK:
		//SetSortMode((eTagsSortMode) (TSM_NAME + ((LPNMLISTVIEW) lParam)->iSubItem));
		break;

	case LVN_ITEMACTIVATE:
		break;

	case TVN_SELCHANGED:
		break;

	/*case NM_DBLCLK:
		if (IDC_LSTB_WORDS == LOWORD(wParam))
			OnWordsLstBoxItemDBClicked();
		break;

	case NM_CLICK:
		if (IDC_LSTB_WORDS == LOWORD(wParam))
			OnWordsLstBoxItemClicked();
		break;*/
	}
	return 0;
}

void CDictDlg::PopupMenu()
{
	DWORD dwPos = GetMessagePos();
	CPoint point(LOWORD(dwPos), HIWORD(dwPos));

	TrackPopupMenu(m_hMainMenu, TPM_LEFTBUTTON, point.x, point.y, 0, this->GetHwnd(), NULL);
}

//?
/*void CDictDlg::OnWordsLstBoxItemClicked()
{
	KillTimer(m_nDictTimer);
	int iItem = m_lstWords.GetCurSel();
	TCHAR tszWord[20];
	m_lstWords.GetText(iItem, tszWord);

	QueryMore(tszWord);
}*/

//?
/*void CDictDlg::OnWordsLstBoxItemDBClicked()
{
	KillTimer(m_nDictTimer);
	int iItem = m_lstWords.GetCurSel();
	TCHAR tszWord[20];
	m_lstWords.GetText(iItem, tszWord);
	//ListMore();
	QueryMore(tszWord);
}*/

void CDictDlg::OnDestroy()
{
	// End the application
	::PostQuitMessage(0);
}

void CDictDlg::BuildFromFile(const TCHAR* file)
{
	TCHAR tszTmpPath[MAX_PATH], tszHtmlPath[MAX_PATH];

	m_nHeight = m_pIniFile->GetInteger(_T("GUI"), _T("Height"));
	m_nWidth = m_pIniFile->GetInteger(_T("GUI"), _T("Width"));

	m_webBrowser.AttachDlgItem(IDC_WB_DATA, this->GetHwnd());

	m_webBrowser.SetLeft(1);
	m_webBrowser.SetWidth(m_nWidth - 2);
	m_webBrowser.SetHeight(m_nHeight - 2);
	m_webBrowser.MoveWindow(1, 1, m_nWidth - 2, m_nHeight-2);

	// Navigate to the home page
    m_pIniFile->GetString(_T("GUI"), _T("html"), tszTmpPath);
    _stprintf(tszHtmlPath, _T("%s%s"), m_tszDataPath, tszTmpPath);
	m_webBrowser.Navigate(tszHtmlPath);
	m_webBrowser.ConnectEvents();

	int w = GetSystemMetrics(SM_CXSCREEN);
	int h = GetSystemMetrics(SM_CYSCREEN);
	MoveWindow(w/2 - m_nWidth/2, h/2 - m_nHeight/2, m_nWidth, m_nHeight);
}

void CDictDlg::OnButtonClicked(const TCHAR* tszBtn) {
	if (0 == _tcscmp(tszBtn, _T("btn_menu"))) {
		PopupMenu();
		return;
	}
	else if (0 == _tcscmp(tszBtn, _T("btn_min"))) {
		ShowWindow(SW_MINIMIZE);
		return;
	}
	else if (0 == _tcscmp(tszBtn, _T("btn_max"))) {
	}
	else if (0 == _tcscmp(tszBtn, _T("btn_restore"))) {
	}
	else if (0 == _tcscmp(tszBtn, _T("btn_close"))) {
		PostQuitMessage(0);
		return;
	}
	else if (0 == _tcscmp(tszBtn, _T(""))) {
	}
}

//TODO:
/*void CDictDlg::OnEidtWord_TextChanged()
{
	tString tUrl = m_tszDataPath;
	tUrl = tUrl + _T("FrontPage\\index.html");
	tString tWord = m_edtWord.GetWindowText();
	StringTrim(tWord);

	int l = tWord.length();
	if (l > 0)
	{
		//int asccode = toascii(tWord.substr(l - 1, 1));
		int asccode = toascii(tWord[l-1]);
		if (!((asccode >= toascii('a') && asccode <= toascii('z')) || (asccode <= toascii('Z') && asccode >= toascii('A'))))
		{
			tWord = tWord.substr(0, l - 1);
			m_edtWord.SetWindowText(tWord.c_str());
			//m_edtWord.SelectionStart = tWord.Length();
		}
	}
	//_tcscpy(m_tszWord, tWord.c_str());
	//Trace("TextChanged: " + m_tszWord);
	l = tWord.length();
	if (l > 0)
	{
		//m_btnDel.ShowWindow(SW_SHOW);
		m_lstWords.ShowWindow(SW_SHOW);
		m_lstWords.ResetContent();

		// MainTimer.Stop();
		// MainTimer.Enabled = false;
		// MainTimer.Enabled = true;
		// MainTimer.Start();
		KillTimer(m_nDictTimer);
		SetTimer(m_nDictTimer, 5000, NULL);

		//mResult = true;
		tString tFindWord;
		bool bFind = m_pGDict->GetWordList(tWord.c_str(), tFindWord);

		while (true == bFind)
		{
			SendDlgItemMessage(IDC_LSTB_WORDS, LB_ADDSTRING, 0, (LPARAM)tFindWord.c_str());
			bFind = m_pGDict->GetWordList(tWord.c_str(), tFindWord);
		}
		m_lstWords.SetSel(0, true);
	}
	else
	{
		//m_btnDel.ShowWindow(SW_HIDE);
		m_lstWords.ShowWindow(SW_HIDE);

		//m_webBrowser.MoveWindow(1, 87, m_nWidth - 2, 421);
		m_webBrowser.Navigate(tUrl.c_str());
	}

	//mUrl = tUrl;
	//'m_webBrowser.Navigate(tUrl)

	//m_webBrowser.Update();
}*/

//TODO:
void CDictDlg::OnTextChanged(tString tWord)
{
	int l = tWord.length();
	/*if (l > 0)
	{
		//int asccode = toascii(tWord.substr(l - 1, 1));
		int asccode = toascii(tWord[l-1]);
		if (!((asccode >= toascii('a') && asccode <= toascii('z')) || (asccode <= toascii('Z') && asccode >= toascii('A'))))
		{
			tWord = tWord.substr(0, l - 1);
			m_edtWord.SetWindowText(tWord.c_str());
			//m_edtWord.SelectionStart = tWord.Length();
		}
	}*/

	l = tWord.length();
	if (l > 0)
	{
		tString tFindWord;
		bool bFind = m_pGDict->GetWordList(tWord.c_str(), tFindWord);

		while (true == bFind)
		{
			m_webBrowser.InvokeScript(_T("append_words_list"), 1, tFindWord.c_str());
			bFind = m_pGDict->GetWordList(tWord.c_str(), tFindWord);
		}
	}
}

//TODO: wait to test
bool CDictDlg::OnSaveHtml(tString html)
{
	tString htmlfile = m_tszDataPath;
	htmlfile = htmlfile + _T("query\\");
	//htmlfile = htmlfile + m_tszWord;
	htmlfile = htmlfile + _T("newhtml");
	htmlfile = htmlfile + _T(".html");
	FILE* pFile = _tfopen(htmlfile.c_str(), _T("w+"));
	
	_fputts(html.c_str(), pFile);
	
	// close file
	if(fclose(pFile) != -1)
	{
		pFile = NULL;
		return true;
	}
	else
	{
		return false;
	}
}
	
void CDictDlg::OnHoverSpeech(tString wd, bool isUs)
{
	if(false == wd.empty())
	{
		tString voicefile;

		if (false == m_pGDict->GetAudioPath(wd.c_str(), isUs, voicefile)){
            LOGERR(_T("Can't get %s' audio."), wd.c_str());
            return;
        }
		
		m_pMp3Player->Load(voicefile.c_str());
		m_pMp3Player->Play();
	}
}

/* void CDictDlg::DataWebBrowser_OnDoubleClick()
// {
	// mshtml.IHTMLDocument2 oDOM= m_webBrowser.Document.DomDocument;
	// //'m_edtWord.Text = oDOM.selection.createRange.htmlText.ToString.ToLower.Trim
	// m_edtWord.SetWindowText(oDOM.selection.createRange.Text.ToString.ToLower.Trim);
	// this->EditWord_TextChanged();
}*/

void CDictDlg::QueryMore(tString tWord)
{
	// if (!PrevInstance(mProxyName, false) && m_bAgent)
		//{
		// System.Diagnostics.Process.Start(mProxyProgram)
			//if( (int)(LRESULT)::ShellExecute(NULL, _T("open"), szUrl, NULL, NULL, SW_SHOWNORMAL ) > 32)
	// }
	// m_pGDict->QueryWrod(m_tszWord, mIsAgent)
	//_tcslen(m_edtWord.GetWindowText())
	//m_edtWord.Text = m_edtWord.Text.Trim
	//if (m_edtWord.Text.Length) <= 1 return

	//if (true == bDefault) tWord = m_edtWord.GetWindowText();

	StringTrim(tWord);
	if(tWord.size() <= 1) return;
	m_bMore = true;
	//KillTimer(m_nDictTimer);

	//m_webBrowser.MoveWindow(1, 87, m_nWidth - 2, 421);

	//FocusEditWord();

	bool ret = m_pGDict->QueryWrod(tWord.c_str());
		
	if(true == ret) {
		LOGINFO(_T("Query Word: %s OK!"), tWord.c_str());
	}
	else {
		LOGINFO(_T("Query Word: %s Wrong!"), tWord.c_str());
		return;
	}

	// m_webBrowser.QueryWord(tWord.c_str(), m_tszDictPage);
	m_webBrowser.InvokeScript(_T("google_search"), 0);
	OnHoverSpeech(tWord.c_str(), true);
	// m_webBrowser.SetInnerHtmlByID(_T("queryword"), tWord.c_str());
}

CDictBase* CDictDlg::GetDictBase() {
	return m_pGDict;
}

//To-Do: 
/*void CDictDlg::FocusEditWord() {

}*/

/*void CDictDlg::OnTimer(UINT_PTR nIDEvent) {
	// MainTimer.Stop();
	// MainTimer.Enabled = false;
	if (nIDEvent != m_nDictTimer) return;
	KillTimer(nIDEvent);
	//Trace("TimerTick: " + m_tszWord);
	tString tWord = m_edtWord.GetWindowText();
	tString tUrl = _T("http://dict.cn/mini.php?q=");
	tUrl = tUrl + tWord;
	// m_webBrowser.QueryWord(tWord.c_str(), tUrl.c_str());
}*/

//work in synchronous mode
bool CDictDlg::DownloadFile(tString url, tString file)
{
	BGNLOG;

	BYTE szOutputBuffer[BUFFER_LEN];
	DWORD dwDownloadedBytes = 0;
	FILE *pFile = NULL;
	HINTERNET hSession = NULL;
	HINTERNET handle2 = NULL;
	//TCHAR* tszText = GetWindowText();
	
	//bool isAgent = m_pIniFile->GetBool(_T("Agent"), _T("Agent"));
	bool bRet = false;
	try
	{
		if(true == m_bAgent)
		{
			hSession = InternetOpen(GetWindowText().c_str(), //User Agent
				INTERNET_OPEN_TYPE_PROXY,	// Preconfig or Proxy
				m_tszProxyAddress,	// Proxy name
				NULL,		// Proxy bypass, do not bypass any address
				0);		// 0 for Synchronous
		}
		else
		{
			hSession = InternetOpen(GetWindowText().c_str(), //application name
				INTERNET_OPEN_TYPE_PRECONFIG,	// Use configuration as IE
				NULL, NULL, 0);
		}

		if (hSession != NULL)
		{
			handle2 = InternetOpenUrl(hSession, (LPCWSTR)url.c_str(), NULL, 0,
				INTERNET_FLAG_NO_CACHE_WRITE | 	// Does not add the returned entity to the cache.
				INTERNET_FLAG_TRANSFER_BINARY | // 
				INTERNET_FLAG_RELOAD,	// Forces a download of the requested file, object, or directory listing from the origin server, not from the cache.
				0);
			if (handle2 != NULL)
			{
				if((pFile = _tfopen(file.c_str(), _T("wb+"))) != NULL)
				{
					do
					{
						BOOL bSuccess = InternetReadFile(handle2, szOutputBuffer, sizeof(szOutputBuffer), &dwDownloadedBytes);
						if(false == bSuccess)
						{
							DWORD dwError = GetLastError();
							if(ERROR_IO_PENDING == dwError)
							{
								LOGINFO(_T("Waiting for InternetReadFile to complete."));
							}
							else
							{
								LogInetError(dwError, _T("InternetReadFile"));
								return false;
							}
						}
						else
						{
							if (0 == dwDownloadedBytes) break;  // no data was received.
							fwrite(szOutputBuffer, sizeof(BYTE), dwDownloadedBytes, pFile);
						}
					} while (true);

					//fflush(pFile);
					fclose(pFile);
				}
				InternetCloseHandle(handle2);
				handle2 = NULL;
			}
			else
			{
				LogInetError(GetLastError(), _T("InternetOpenUrl"));
				return false;
			}
			InternetCloseHandle(hSession);
			hSession = NULL;
		}
		else
		{
			LogInetError(GetLastError(), _T("InternetOpen"));
			return false;
		}
	}
	catch (std::exception &e)
	{
		// Process the exception and quit 
		e.what();
		return false;
	}
	return true;
}

//void CDictDlg::OnDraw(CDC* pDC)
void CDictDlg::OnDraw(CDC& dc)
{
	CRect rect = GetClientRect();
	dc.SolidFill(RGB(67, 160, 255), rect);   //���ñ���
}

// This routine is used to log Windows dwErrors in human readable form.
// Arguments:
// dwErr - dwError number obtained from GetLastdwError()
// tszMsgEx - tszMsgExing pointer holding caller-context information
// Return Value: None.
VOID LogWinError(
	__in DWORD dwErr,
	__in LPCTSTR tszMsgEx)
{
	DWORD dwResult;
	LPVOID tszMsgBuffer = NULL;
	bool m_bDebug = true;

	dwResult = FormatMessage(
		FORMAT_MESSAGE_ALLOCATE_BUFFER |
		FORMAT_MESSAGE_FROM_SYSTEM |
		FORMAT_MESSAGE_IGNORE_INSERTS,
		NULL,
		dwErr,
		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
		(LPTSTR)&tszMsgBuffer,
		0, NULL);

	if (dwResult)
	{
		LOGMSG(_T("%ws: %ws"), tszMsgEx, tszMsgBuffer);
		LocalFree(tszMsgBuffer);
	}
	else
	{
		dwResult = GetLastError();
		LOGOUT(_T("Error %d while formatting message for %d in %ws.\n"), dwResult, dwErr, tszMsgEx);
	}
	return;
}

// This routine is used to log WinInet dwErrors in human readable form.
// Arguments:
// dwErr - dwError number obtained from GetLastdwError()
// tszMsgEx - tszMsgExing pointer holding caller-context information
// Return Value: None.
VOID LogInetError(
	__in DWORD dwErr,
	__in LPCTSTR tszMsgEx)
{
	DWORD dwResult;
	LPVOID tszMsgBuffer = NULL;
	bool m_bDebug = true;

	dwResult = FormatMessage(
		FORMAT_MESSAGE_ALLOCATE_BUFFER |
		FORMAT_MESSAGE_FROM_HMODULE |
		FORMAT_MESSAGE_IGNORE_INSERTS,
		GetModuleHandle(_T("wininet.dll")),
		dwErr,
		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
		(LPTSTR)&tszMsgBuffer,
		0, NULL);

	if (dwResult)
	{
		//fprintf(stderr, "%ws: %ws\n", tszMsgEx, tszMsgBuffer);
		LOGMSG(_T("%ws: %ws"), tszMsgEx, tszMsgBuffer);
		LocalFree(tszMsgBuffer);
	}
	else
	{
		dwResult = GetLastError();
		LOGOUT(_T("Error %d while formatting message for %d in %ws.\n"), dwResult, dwErr, tszMsgEx);
		LogWinError(dwResult, _T("LogInetError"));
	}
	return;
}