//DictBase.h
#ifndef __DICTBASE__H__
#define __DICTBASE__H__

#include <string>
#include <tchar.h>

using namespace std;

class CDictDlg;

class CDictBase
{
public:
	CDictBase() {};
	CDictBase(CDictDlg* pDlg) { pDlg == NULL; };
	virtual ~CDictBase() {};

public:

	virtual bool Load(const TCHAR* dictPath, const TCHAR* audioPath) = 0;
	virtual void Unload() = 0;

	virtual bool QueryWrod(const TCHAR* wd) = 0;

	virtual bool GetWordList(const tString word, tString& tFindWord) = 0;

	virtual bool DelWord(const TCHAR* wd) = 0;

	virtual bool DelAudio(const TCHAR* wd) = 0;
};

#endif //__DICTBASE__H__