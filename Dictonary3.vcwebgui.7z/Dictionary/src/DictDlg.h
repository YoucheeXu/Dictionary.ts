//DictDlg.h
#ifndef _DICTDLG_H_
#define _DICTDLG_H_

#include "help.h"
#include "BmpButton.h"
#include "DictWebBrowser.h"
#include "GDictBase.h"
#include "Mp3Player.h"
#include "IniFile.h"

// class CMp3Player;
// class CGDictBase;
//class CIniFile;
//class CInternetSever;

using namespace Win32xx;
using namespace std;

class CDictDlg : public CDialog
{
public :
	CDictDlg(UINT nResID);
	virtual ~CDictDlg();
	
private:
	DISALLOW_COPY_AND_ASSIGN(CDictDlg);
	
protected:
	virtual void OnDestroy();
	virtual BOOL OnInitDialog();
	virtual BOOL PreTranslateMessage(MSG& msg);
	virtual INT_PTR DialogProc(UINT uMsg, WPARAM wParam, LPARAM lParam);
	virtual BOOL OnCommand(WPARAM wParam, LPARAM lParam);
	virtual LRESULT OnNotify(WPARAM wParam, LPARAM lParam);
	//virtual HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	//virtual HBRUSH OnCtlColor(HDC hDC, HWND hWnd, UINT nCtlColor);
	//virtual LRESULT OnMessageReflect(UINT uMsg, WPARAM wParam, LPARAM lParam);
	virtual void OnOK(){
		//QueryMore(m_edtWord.GetWindowText().c_str());
	}
	//virtual void OnDraw(CDC* pDC);
	virtual void OnDraw(CDC& dc);

	//virtual void OnTimer (UINT_PTR nIDEvent);

	void OnSize(bool bInitial = false);
	
	//void OnEidtWord_KeyDown();
	//void OnEidtWord_TextChanged();
	
	void PopupMenu();
	//void OnWordsLstBoxItemClicked();
	//void OnWordsLstBoxItemDBClicked();

public:	
	void OnButtonClicked(const TCHAR* tszBtn);
    void OnTextChanged(tString tWord);

	bool DownloadFile(tString url, tString file);
	// bool DownloadFile2(tString url, tString file); // work in asynchronous 
	bool IsMore(){return m_bMore;}
	void SetMore(bool bMore){ m_bMore = bMore; }
	void QueryMore(tString tWord);
	//void FocusEditWord();
	// void ListMore();
	bool OnSaveHtml(tString html);
	void OnHoverSpeech(tString wd, bool isUs);
	CDictBase* GetDictBase();

private:

	HMENU m_hMainMenu;
	CIniFile* m_pIniFile;
	int m_nHeight;
	int m_nWidth;

	bool m_bDelete;

	TCHAR m_tszAppPath[MAX_PATH];
	TCHAR m_tszDataPath[MAX_PATH];
	TCHAR m_tszDictPage[MAX_PATH];
	TCHAR m_tszSkinPath[MAX_PATH];
	TCHAR m_tszDictPath[MAX_PATH];
	TCHAR m_tszAudioPath[MAX_PATH];

	bool m_bAgent;
	TCHAR m_tszProxyAddress[MAX_PATH];
	
	//UINT m_nDictTimer;

	CGDictBase* m_pGDict;

	TCHAR m_tszWord[20];
	
	bool m_bMore;

	//controls
	//CStatic m_panelInput;
	CDC* m_pDCCombox_bk;
	
	//CEdit m_edtWord;
	//CListBox m_lstWords;

	CDictWebBrowser m_webBrowser;

	CMp3Player* m_pMp3Player;

	CFont m_fontEdit;

	bool m_bDebug;

private:
	void BuildFromFile(const TCHAR* file);
};

VOID LogWinError(
	__in DWORD dwErr,
	__in LPCTSTR tszMsgEx);

VOID LogInetError(
	__in DWORD dwErr,
	__in LPCTSTR tszMsgEx);

#endif //_DICTDLG_H_