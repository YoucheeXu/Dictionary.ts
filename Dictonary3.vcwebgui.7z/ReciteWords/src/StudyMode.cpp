﻿//StudyMode.cpp
#include "stdafx.h"
#include "IniFile.h"
#include "StudyMode.h"

CStudyMode::CStudyMode(CIniFile* pIniFile, CSQLiteDataBase* pMainDict) {

	m_bDebug = true;
	m_bSaveConfig = false;
	
	m_nCurArray = 7;
	m_nIndexNewWord = 0;
	m_lStudyTime = 0;

	m_pIniFile = pIniFile;

	m_pMainDict = pMainDict;

	//m_iterNewWordArray = m_NewWordArray.start();

	//get Ebbinghaus memory curve words;
	m_nTotalWords = GetEbbinghausWords();
	//m_OldWordArray.insert(m_OldWordArray.end(), tmpWordArray.begin(), tmpWordArray.end());

	//get new words;
	m_NewWordArray.clear();
	int num = m_pIniFile->GetInteger(_T("StudyMode"), _T("limit"));
	int start = m_pIniFile->GetInteger(_T("StudyMode"), _T("start"));
	
	//get strange words;
	int num_StrangeWords = GetStrangeWords(m_NewWordArray, num);
	
	if(num_StrangeWords < num) {
		WordArray tmpWordArray;
		GetNewWords(tmpWordArray, start, num - num_StrangeWords);
		m_NewWordArray.insert(m_NewWordArray.end(), tmpWordArray.begin(), tmpWordArray.end());
	}
	
	m_nTotalWords += m_NewWordArray.size();
	
	m_nNextStart = start;
	m_OldWordArray.clear();
}

CStudyMode::~CStudyMode(){

	if (m_TimeWordArray[7].size() >= 1){
		SaveWordsState();
		m_pIniFile->SetInteger(_T("StudyMode"), _T("start"), m_nNextStart + m_nIndexNewWord);
	}
}

//to test
int CStudyMode::GetNextWord(CWord& word){
	/*switch(m_nCurArray) {
	case 8:
		if(m_Time8WordArray.size() >= 1) {
			word = m_Time8WordArray.back();
			m_Time8WordArray.pop_back();
			m_OldWordArray.push_back(word);
		}
		else m_nCurArray--;
		return true;
	case 7:
		if(m_Time7WordArray.size() >= 1) {
			word = m_Time7WordArray.back();
			m_Time7WordArray.pop_back();
			m_Time8WordArray.push_back(word);
		}
		else m_nCurArray--;
		return true;
	case 6:
		if(m_Time6WordArray.size() >= 1) {
			word = m_Time6WordArray.back();
			m_Time6WordArray.pop_back();
			m_Time7WordArray.push_back(word);
		}
		else m_nCurArray--;
		return true;
	case 5:
		if(m_Time5WordArray.size() >= 1) {
			word = m_Time5WordArray.back();
			m_Time5WordArray.pop_back();
			m_Time6WordArray.push_back(word);
		}
		else m_nCurArray--;
		return true;
	case 4:
		if(m_Time4WordArray.size() >= 1) {
			word = m_Time4WordArray.back();
			m_Time4WordArray.pop_back();
			m_Time5WordArray.push_back(word);
		}
		else m_nCurArray--;
		return true;
	case 3:
		if(m_Time3WordArray.size() >= 1) {
			word = m_Time3WordArray.back();
			m_Time3WordArray.pop_back();
			m_Time4WordArray.push_back(word);
		}
		else m_nCurArray--;
		return true;
	case 2:
		if(m_Time2WordArray.size() >= 1) {
			word = m_Time2WordArray.back();
			m_Time2WordArray.pop_back();
			m_Time3WordArray.push_back(word);
		}
		else m_nCurArray--;
		return true;
	case 1:
		if(m_Time1WordArray.size() >= 1) {
			word = m_Time1WordArray.back();
			m_Time1WordArray.pop_back();
			m_Time2WordArray.push_back(word);
		}
		else m_nCurArray--;
		return true;
	}*/
	long curTime = time(NULL);
	
	if (1 <= m_nCurArray && m_nCurArray <= 7) {
		if(m_TimeWordArray[m_nCurArray - 1].size() >= 1) {
			word = m_TimeWordArray[m_nCurArray - 1].back();
			m_TimeWordArray[m_nCurArray - 1].pop_back();
			word.SetLastDate(curTime);
			m_TimeWordArray[m_nCurArray].push_back(word);
			return 1;
		}
		else m_nCurArray--;
	}
	else if(0 == m_nCurArray){
		if(m_NewWordArray.size() >= 1) {
			word = m_NewWordArray.back();
			m_NewWordArray.pop_back();
			word.SetLastDate(curTime);
			m_TimeWordArray[0].push_back(word);
			m_nIndexNewWord ++;
			return 1;
		}
		else {
			m_nCurArray = 7;
			m_lStudyTime = time(NULL);
		}
	}
	//else if(m_nCurArray <= -1){
	//	int i = abs(m_nCurArray);
	//	if(m_TimeWordArray[8 - i].size() >= 1) {
	//		word = m_TimeWordArray[8 - i].back();
	//		m_TimeWordArray[8 - i].pop_back();
	//		word.SetLastDate(curTime);
	//		m_TimeWordArray[8 - i + 1].push_back(word);
	//		return 1;
	//	}
	//	else m_nCurArray--;
	//}
	
	if(m_nTotalWords = m_TimeWordArray[7].size()) return 0;
	
	//if (-9 == m_nCurArray) {
	//	m_nCurArray = -1;
	//	return 2;
	//}
	
	return 2;
}

bool CStudyMode::UpdateWord(const CWord word){
	WordArray::iterator iter;
	tString wd = word.GetWord();
	CWord tmpWord;
	for (iter = m_OldWordArray.begin(); iter != m_OldWordArray.end(); iter++){
		tmpWord = *iter;
		if (tmpWord.GetWord() == wd) {
			*iter = word;
			return true;
		}
	}
	return false;
}

//to test
int CStudyMode::GetEbbinghausWords() {

	//long time1, time2, time3, time4, time5, time6, time7, time8;
	//long curTime = DateTime.Now;
	time_t curTime = time(NULL);
	int size = 0;

	//WordArray tmpWordArray;
	
	TCHAR tszTime[20];
	
	for(int i=7; i>0; i--) {
		m_TimeWordArray[i].clear();
		_stprintf(tszTime, _T("%s%d"), _T("Time"), i+1);
		m_Time[i] = m_pIniFile->GetTime(_T("Time"), tszTime);
		m_pMainDict->GetWordListByDate(curTime - m_Time[i], m_TimeWordArray[i]);
		size += m_TimeWordArray[i].size();
	}
	
	/*//get Ebbinghaus time8 words;
	time8 = m_pIniFile->GetInteger(_T("Time"), _T("time8"));
	m_pMainDict->GetWordListByDate(curTime - time8, m_TimeWordArray[8]);

	//get Ebbinghaus time7 words;
	time7 = m_pIniFile->GetInteger(_T("Time"), _T("time7"));
	m_pMainDict->GetWordListByDate(curTime - time7, m_TimeWordArray[7]);
	
	//get Ebbinghaus time6 words;
	time6 = m_pIniFile->GetInteger(_T("Time"), _T("time6"));
	m_pMainDict->GetWordListByDate(curTime - time6, m_TimeWordArray[6]);

	//get Ebbinghaus time5 words;
	time5 = m_pIniFile->GetInteger(_T("Time"), _T("time5"));
	m_pMainDict->GetWordListByDate(curTime - time5, m_TimeWordArray[5]);

	//get Ebbinghaus time4 words;
	time4 = m_pIniFile->GetInteger(_T("Time"), _T("time4"));
	m_pMainDict->GetWordListByDate(curTime - time4, m_TimeWordArray[4]);
	
	//get Ebbinghaus time3 words;
	time3 = m_pIniFile->GetInteger(_T("Time"), _T("time3"));
	m_pMainDict->GetWordListByDate(curTime - time3, m_TimeWordArray[3]);
	
	//get Ebbinghaus time2 words;
	time2 = m_pIniFile->GetInteger(_T("Time"), _T("time2"));
	m_pMainDict->GetWordListByDate(curTime - time2, m_TimeWordArray[2]);
	
	//get Ebbinghaus time1 words;
	time1 = m_pIniFile->GetInteger(_T("Time"), _T("time1"));
	m_pMainDict->GetWordListByDate(curTime - time1, m_TimeWordArray[1]);

	//findWords.insert(findWords.end(), tmpWordArray.begin(), tmpWordArray.end());

	int size = 0;
	for(int i==0; i<8; i++) {
		size += m_TimeWordArray[i].size();
	}*/

	return size;
}

bool CStudyMode::GetStrangeWords(WordArray& wordArray, int num){
	return m_pMainDict->GetWordListByFamiliar(5, wordArray, num);
}

bool CStudyMode::GetNewWords(WordArray& wordArray, int start, int num) {
	return m_pMainDict->GetWordList(wordArray, start, num);
}

//ToDo
bool CStudyMode::SaveWordsState() {
	WordArray::iterator iter;
	CWord word;
	int n = 0;
	for(int i = 0; i<9; i++) {
		for (iter = m_TimeWordArray[i].begin(); iter != m_TimeWordArray[i].end(); iter++){
			word = *iter;
			n++;
			m_pMainDict->UpdateWord(word);
			//TODO
		}
	}
	if(m_nTotalWords == n) return true;
	return false;
}