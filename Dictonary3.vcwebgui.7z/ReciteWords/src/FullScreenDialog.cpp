///////////////////////////////////////
// FullScreenDialog.cpp

#include "stdafx.h"
#include "FullScreenDialog.h"
#include "resource.h"
#include "MainDialog.h"

// Definitions for the CFullScreenDialog class
CFullScreenDialog::CFullScreenDialog(UINT nResID) : CDialog(nResID)
{
	m_pMainDialog = new CMainDialog(IDD_RECITEWORDS);
}

CFullScreenDialog::~CFullScreenDialog()
{
	delete m_pMainDialog;
}

void CFullScreenDialog::OnDestroy()
{
	// End the application
	::PostQuitMessage(0);
}

INT_PTR CFullScreenDialog::DialogProc(UINT uMsg, WPARAM wParam, LPARAM lParam)
{
//	switch (uMsg)
//	{
		//Additional messages to be handled go here
//	}

	// Pass unhandled messages on to parent DialogProc
	return DialogProcDefault(uMsg, wParam, lParam);
}

BOOL CFullScreenDialog::OnInitDialog()
{
	// Set the Icon
	//SetIconLarge(IDW_MAIN);
	//SetIconSmall(IDW_MAIN);

	SetParent(GetDesktopWindow());
	CRect rect = GetDesktopWindow().GetWindowRect();
	SetWindowPos(HWND_TOP, rect.left, rect.top, rect.right, rect.bottom, SWP_SHOWWINDOW);

	m_pMainDialog->DoModal();

	return true;
}

void CFullScreenDialog::OnOK()
{
	MessageBox(_T("OK Button Pressed.  Program will exit now."), _T("Button"), MB_OK);
	CDialog::OnOK();
}
