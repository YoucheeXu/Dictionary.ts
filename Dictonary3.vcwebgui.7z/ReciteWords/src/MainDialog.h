//MainDialog.h
#ifndef _MAINDIALOG_H_
#define _MAINDIALOG_H_

#include "help.h"
#include "BmpButton.h"

class CMp3Player;
class CSQLiteDataBase;
class CIniFile;
class CStudyMode;
class CTestMode;
class CWord;

using namespace Win32xx;
using namespace std;

class CMainDialog : public CDialog
{
public :
	CMainDialog(UINT nResID);
	virtual ~CMainDialog();
	
private:
	DISALLOW_COPY_AND_ASSIGN(CMainDialog);
	
protected:
	virtual void OnDestroy();
	virtual BOOL OnInitDialog();
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	virtual INT_PTR DialogProc(UINT uMsg, WPARAM wParam, LPARAM lParam);
	virtual BOOL OnCommand(WPARAM wParam, LPARAM lParam);
	virtual LRESULT OnNotify(WPARAM wParam, LPARAM lParam);
	//virtual HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	virtual HBRUSH OnCtlColor(HDC hDC, HWND hWnd, UINT nCtlColor);
	//virtual LRESULT OnMessageReflect(UINT uMsg, WPARAM wParam, LPARAM lParam);
	//virtual void OnOK();
	virtual void OnDraw(CDC& dc);

	void OnSize(bool bInitial = false);

	void OnMenuClicked();

public:	
	void FocusEditWord();

	//void OnSpeech(const tString& wd, bool isUs = true);
	void OnSpeech(bool isUs = true);

private:

	HMENU m_hMainMenu;
	CIniFile* m_pIniFile;
	int m_nHeight;
	int m_nWidth;

	TCHAR m_tszAppPath[MAX_PATH];
	TCHAR m_tszDataPath[MAX_PATH];

	TCHAR m_tszSkinPath[MAX_PATH];
	TCHAR m_tszDictPath[MAX_PATH];
	TCHAR m_tszGAudioPath[MAX_PATH];

	CSQLiteDataBase* m_pMainDict;
	CStudyMode* m_pStudyMode;
	
	CWord* m_pWord;
	
	bool m_bMore;

	//controls
	CBmpButton m_btnMenu;
	CBmpButton m_btnMin;
	CBmpButton m_btnMax;
	CBmpButton m_btnClose;
	CBmpButton m_btnPronounce;
	CBmpButton m_btnGiveup;
	
	HMODULE m_hInstRichEdit;

	//CBitmap* m_pBmpCombox_bk;
	CDC* m_pDCCombox_bk;
	
	CEdit m_edtWord;
	CRichEdit m_txtWordData;

	CStatic m_txtFedback;
	COLORREF m_colorFedback;

	CMp3Player* m_pMp3Player;

	CFont m_fontEdit;

	bool m_bDebug;
	
	//tString m_tWord;

private:
	void BuildFromFile(const TCHAR* file);
	void CheckWord();
	int GetNextWord();
};

#endif //_MAINDIALOG_H_