#ifndef _MACROS_H_
#define _MACROS_H_

//#ifndef _CRT_SECURE_NO_WARNINGS
//#define _CRT_SECURE_NO_WARNINGS
//#endif
//
//#ifndef _CRT_SECURE_NO_DEPRECATE
//#define _CRT_SECURE_NO_DEPRECATE
//#endif

#include "LogFile.h"

//#define NDEBUG

extern bool g_bDebug;
//CLogFile* g_pLogFile;

// ��ֹʹ�ÿ������캯���� operator= ��ֵ�����ĺ�
// Ӧ����� private: ��ʹ��
#define DISALLOW_COPY_AND_ASSIGN(TypeName) \
	TypeName(const TypeName&); \
	void operator=(const TypeName&)

TCHAR* _tcstrim(TCHAR* str);
void StringTrimLeft(tString& str);
void StringTrimRight(tString& str);
void StringTrim(tString& str);
void StringReplace(tString& tOrg, const TCHAR* tszFrom, const TCHAR* tszTo);
int StringReplaceAll(tString& tOrg, const TCHAR* tszFrom, const TCHAR* tszTo);
//int StringRegReplaceAll(tString& tOrig, wregex regExpress, const TCHAR* tszReplace);
void StringErase(tString& tOrg, const TCHAR* tszDrop);
int StringEraseAll(tString& tOrg, const TCHAR* tszDrop);

#endif //_MACROS_H_