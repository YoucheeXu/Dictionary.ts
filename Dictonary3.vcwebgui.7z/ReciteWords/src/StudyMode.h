﻿//StudyMode.h
#ifndef _STUDYMODE_H_
#define _STUDYMODE_H_

#include "SQLiteDataBase.h"

class CIniFile;

class CStudyMode {
public:
	CStudyMode(){};
	CStudyMode(CIniFile* pIniFile, CSQLiteDataBase* pMainDict);
	~CStudyMode();
	
private:
	bool m_bDebug;
	CIniFile* m_pIniFile;
	CSQLiteDataBase* m_pMainDict;
	int m_nNextStart;
	bool m_bSaveConfig;
	long m_nIndexNewWord;
	int m_nTotalWords;
	
	int m_nCurArray;
	long m_lStudyTime;
	time_t m_Time[8];
	
	WordArray m_NewWordArray;
	
	//WordArray::iterator m_iterNewWordArray; 
	
	WordArray m_TimeWordArray[9];
	
	WordArray m_OldWordArray;

	//map<tString, CWord> m_mapWordArray;
	//map<tString, CWord>::iterator  m_iterWordArray; 

public:
    int GetNextWord(CWord& word);
	bool UpdateWord(const CWord word);

private:
    int GetEbbinghausWords();
	//int GetEbbinghausWords(WordArray& findWords, long time);
	
	bool GetNewWords(WordArray& wordArray, int start, int num);
	bool GetStrangeWords(WordArray& wordArray, int num);
	
	bool SaveWordsState();
};

#endif //_STUDYMODE_H_