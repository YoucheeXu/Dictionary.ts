//ReciteWordsApp.cpp
#include "stdafx.h"
#include "ReciteWordsApp.h"
#include "resource.h"
#include "LogFile.h"

// global vars
//CLogFile theLogFile;
//CReciteWordsApp theApp;
//bool g_bDebug;
//CLogFile* g_pLogFile;

//CReciteWordsApp::CReciteWordsApp()
CReciteWordsApp::CReciteWordsApp() : m_MyDialog(IDD_FULLSCREEN)
{
	//g_pLogFile = new CLogFile();
	g_bDebug = true;
}

CReciteWordsApp::~CReciteWordsApp()
{
	//Uninitialize();
	//delete g_pLogFile;
}

BOOL CReciteWordsApp::InitInstance()
{
	//m_MyDialog.SetDialogBkColor(RGB(0, 0, 255), RGB(255, 0, 0));

	//Display the Modal Dialog	
	m_MyDialog.DoModal();

	return TRUE;
	
	//CCommandLineInfo cmdInfo;
	//ParseCommandLine(cmdInfo);

	//Create the Frame Window
	/*if (0 == m_Frame.Create())	
	{
		// We get here if the Frame creation fails
		
		::MessageBox(NULL, _T("Failed to create Frame window"), _T("ERROR"), MB_ICONERROR);
		return FALSE; // returning FALSE ends the application
	}

	return TRUE;*/
}

//void CReciteWordsApp::Initialize(HINSTANCE hInstance)
//{    
//	SetResourceHandle(hInstance);
//	mHTabIcon = (HICON) ::LoadImage( hInstance, 
//		MAKEINTRESOURCE(IDC_LV_CV), IMAGE_ICON, 0, 0, 
//		LR_LOADMAP3DCOLORS | LR_LOADTRANSPARENT );
//	//m_TB_Icon.hToolbarBmp = (HBITMAP) ::LoadImage( hInstance,
//	// MAKEINTRESOURCE(IDB_TAGSVIEW), IMAGE_BITMAP, 0, 0, 
//	// LR_DEFAULTSIZE | LR_LOADMAP3DCOLORS );
//}

//void CReciteWordsApp::Uninitialize()
//{
//	if (mHTabIcon)
//	{
//		::DestroyIcon(mHTabIcon);
//		mHTabIcon = NULL;
//	}
//	//if ( m_TB_Icon.hToolbarBmp )
//	//{
//	//    ::DeleteObject(m_TB_Icon.hToolbarBmp);
//	//    m_TB_Icon.hToolbarBmp = NULL;
//	//}
//}

//{
//	If PrevInstance(IO.Path.GetFileNameWithoutExtension(Application.ExecutablePath), True) Then
//		Me.Close()
//		Return
//	End If
//}

//bool CReciteWordsApp::PrevInstance(ByVal sProName As String, Optional ByVal start As Boolean = False)
//{
//	Dim i As Integer
//	Try
//		i = Diagnostics.Process.GetProcessesByName(sProName).Length
//	Catch ex As Exception
//		i = 0
//	End Try
//
//	If start Then
//		Return i > 1
//	Else
//		Return i > 0
//	End If
//}