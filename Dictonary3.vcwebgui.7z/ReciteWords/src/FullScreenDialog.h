///////////////////////////////////////
// FullScreenDialog.h

#ifndef _FULLSCREENDIALOG_H_
#define _FULLSCREENDIALOG_H_

class CMainDialog;

// Declaration of the CFullScreenDialog class
class CFullScreenDialog : public CDialog
{
public:
	CFullScreenDialog(UINT nResID);
	virtual ~CFullScreenDialog();

protected:
	virtual void OnDestroy();
	virtual BOOL OnInitDialog();
	virtual INT_PTR DialogProc(UINT uMsg, WPARAM wParam, LPARAM lParam);
	//virtual BOOL OnCommand(WPARAM wParam, LPARAM lParam);
	virtual void OnOK();

private:
	CMainDialog* m_pMainDialog;
};

#endif //_FULLSCREENDIALOG_H_
