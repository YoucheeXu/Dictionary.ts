﻿//TestMode.cpp;
#include "stdafx.h"
#include "SQLiteDataBase.h"
#include "TestMode.h"

bool CTestMode::GetNextWord(tString wd, CWord& word) {
	return false;
}

//to do
bool CTestMode::GoNext() {
	return false;
}