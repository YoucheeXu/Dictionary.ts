﻿//TestMode.h
#ifndef _TESTMODE_H_
#define _TESTMODE_H_

class CTestMode {
public:
	CTestMode(){}
	~CTestMode(){}
	
private:
	int m_nNum1;
    int m_nNum2;
    int m_nTestNum;

public:
	bool GetNextWord(tString wd, CWord& word);
    bool GoNext();
};

#endif //_TESTMODE_H_