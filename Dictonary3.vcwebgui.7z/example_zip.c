	
#2 得分：0 回复于： 2009-07-22 18:33:09
zlib包不是有个example.c吗？ 

一个极简单的例程： 

$ cat z.c

#include <stdio.h>

#include <string.h>

#include <stdlib.h> 

#include <zlib.h>



static void gzip(const char *infile, const char *outfile)

{

  char buf[512];

  FILE *in;

  gzFile out;

  int len;



  if ((in = fopen(infile, "rb")) == NULL) {

    printf("Can't open input file %s
", infile);

    exit(1);

  }



  if ((out = gzopen(outfile, "wb")) == NULL) {

    printf("Can't open output file %s
", outfile);

    exit(1);

  }



  while ((len = fread(buf, 1, sizeof(buf), in)) > 0)

    gzwrite(out, buf, len);



  fclose(in);

  gzclose(out);

}



static void gunzip(const char *infile, const char *outfile)

{

  char buf[512];

  gzFile in;

  FILE *out;

  int len;



  if ((in = gzopen(infile, "rb")) == NULL) {

    printf("Can't open input file %s
", infile);

    exit(1);

  }



  if ((out = fopen(outfile, "wb")) == NULL) {

    printf("Can't open output file %s
", outfile);

    exit(1);

  }



  while ((len = gzread(in, buf, sizeof(buf))) > 0)

    fwrite(buf, 1, len, out);



  gzclose(in);

  fclose(out);

}



static void usage(char *bin)

{

  printf("usage: %s [-d] FILE
"

 "  -d   decompress
"

 "
", bin);

  exit(1);

}



int main(int ac, char *av[])

{

  char *infile, outfile[256];

  int compress = 1;



  if (ac < 2 || ac > 3)

    usage(av[0]);



  if (ac == 3) {

    if (strcmp(av[1], "-d"))

      usage(av[0]);

    compress = 0;

    infile = av[2];

    strcpy(outfile, infile);

    *strstr(outfile, ".gz") = '';

  }

  else {

    infile = av[1];

    sprintf(outfile, "%s.gz", infile);

  }



  if (compress)

    gzip(infile, outfile);

  else

    gunzip(infile, outfile);



  return 0;

}