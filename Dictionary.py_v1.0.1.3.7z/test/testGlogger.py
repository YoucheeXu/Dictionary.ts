#!/usr/bin/python3
# -*- coding: utf-8 -*-

import sys, os
from utils import *
import platform
from GDo import GDo
from globalVar import *

def main():
	global gLogger

	logFile = os.path.join(os.getcwd(), "d.log")
	gLogger = CreateLogger("testGlogger", logFile)
	# gLogger = CreateLogger("testGlogger")

	gLogger.info("Python {ver} {arch}".format(
			ver = platform.python_version(), arch = platform.architecture()[0]))

	a = GDo()

if __name__ == '__main__':
	main()