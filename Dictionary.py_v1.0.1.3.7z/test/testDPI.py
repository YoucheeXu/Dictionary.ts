import re
import platform
import os

def Get_HWND_DPI(window_handle):
	# To detect high DPI displays and avoid need to set Windows compatibility flags
	if os.name == "nt":
		from ctypes import windll, pointer, wintypes
		try:
			# Windows 8.1 6.3
			# Windows 8 6.2
			# Windows 7 6.1
			# Windows Server 2008 R2 6.1
			# Windows Server 2008 6.0
			# Windows Vista 6.0
			os_ver = float(re.match("\d+(\.\d+){0,1}", platform.win32_ver()[1]).group())
			if os_ver >= 6.3:
				# Minimum supported client:	Windows 8.1 [desktop apps only]
				PROCESS_DPI_UNAWARE = 0
				# DPI unaware. This app does not scale for DPI changes and is always assumed to have a scale factor of 100% (96 DPI). It will be automatically scaled by the system on any other DPI setting.
				PROCESS_SYSTEM_DPI_AWARE = 1
				# System DPI aware. This app does not scale for DPI changes. It will query for the DPI once and use that value for the lifetime of the app. If the DPI changes, the app will not adjust to the new DPI value. It will be automatically scaled up or down by the system when the DPI changes from the system value.
				PROCESS_PER_MONITOR_DPI_AWARE = 2
				# Per monitor DPI aware. This app checks for the DPI when it is created and adjusts the scale factor whenever the DPI changes. These applications are not automatically scaled by the system.
				windll.shcore.SetProcessDpiAwareness(PROCESS_SYSTEM_DPI_AWARE)	# 告诉操作系统使用程序自身的dpi适配
			elif os_ver >= 6.0:
				# Minimum supported client:	Windows Vista [desktop apps only]
				ret = windll.user32.SetProcessDPIAware()
				if ret == 0:
					print("Fait to SetProcessDPIAware")
			hWnd = wintypes.HWND(window_handle)
			DPI100pc = 96  # DPI 96 is 100% scaling
			X = wintypes.UINT()
			Y = wintypes.UINT()
			if os_ver >= 6.3:
				# Minimum supported client: Windows 2000 Professional [desktop apps only]
				MONITOR_DEFAULTTONEAREST = 2
				monitorhandle = windll.user32.MonitorFromWindow(hWnd, MONITOR_DEFAULTTONEAREST)
				# Minimum supported client	Windows 8.1 [desktop apps only]
				MDT_EFFECTIVE_DPI = 0
				MDT_ANGULAR_DPI = 1
				MDT_RAW_DPI = 2
				windll.shcore.GetDpiForMonitor(monitorhandle, MDT_EFFECTIVE_DPI, pointer(X), pointer(Y))
			else:
				# Minimum supported client:	Windows 2000 Professional [desktop apps only]
				hDC = windll.user32.GetDC(hWnd)
				# Minimum supported client: Windows 2000 Professional [desktop apps only]
				LOGPIXELSX = 88
				LOGPIXELSY = 90
				X = windll.gdi32.GetDeviceCaps(hDC, LOGPIXELSX);	# 每英寸逻辑像素数 水平
				Y = windll.gdi32.GetDeviceCaps(hDC, LOGPIXELSY); 	# 每英寸逻辑像素数 垂直
			# return X.value, Y.value, (X.value + Y.value) / (2 * DPI100pc)
			return X, Y, (X + Y) / (2 * DPI100pc)
		except Exception as e:
			print("Error: " + str(e))
		return 96, 96, 1  # Assume standard Windows DPI & scaling
	else:
		return None, None, 1  # What to do for other OSs?


def TkGeometryScale(s, cvtfunc):
	patt = r"(?P<W>\d+)x(?P<H>\d+)\+(?P<X>\d+)\+(?P<Y>\d+)"  # format "WxH+X+Y"
	R = re.compile(patt).search(s)
	G = str(cvtfunc(R.group("W"))) + "x"
	G += str(cvtfunc(R.group("H"))) + "+"
	G += str(cvtfunc(R.group("X"))) + "+"
	G += str(cvtfunc(R.group("Y")))
	return G

def MakeTkDPIAware(TKGUI):
	TKGUI.DPI_X, TKGUI.DPI_Y, TKGUI.DPI_scaling = Get_HWND_DPI(TKGUI.winfo_id())
	TKGUI.TkScale = lambda v: int(float(v) * TKGUI.DPI_scaling)
	TKGUI.TkGeometryScale = lambda s: TkGeometryScale(s, TKGUI.TkScale)


#Example use:
import tkinter


GUI = tkinter.Tk()
MakeTkDPIAware(GUI)  # Sets the windows flag + gets adds .DPI_scaling property
GUI.geometry(GUI.TkGeometryScale("600x200+200+100"))
gray = "#cccccc"
DemoFrame = tkinter.Frame(GUI, width=GUI.TkScale(580), height=GUI.TkScale(180), background=gray)
DemoFrame.place(x=GUI.TkScale(10), y=GUI.TkScale(10))
DemoFrame.pack_propagate(False)
LabelText = "Scale = " + str(GUI.DPI_scaling)
DemoLabel = tkinter.Label(DemoFrame, text=LabelText, width=10, height=1)
DemoLabel.pack(pady=GUI.TkScale(70))

GUI.mainloop()