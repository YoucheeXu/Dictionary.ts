#!/usr/bin/python3
#-*- encoding:utf-8 -*-
# -*- coding: utf-8 -*-
#coding=utf-8

import os
import json

def GetInWord(dict, wordInfoFile):

	datum = json.loads(dict, strict = False)
	# print(datum)

	if(datum["ok"]):
		info = datum["info"]

		with open(wordInfoFile, 'w', encoding = 'utf-8') as f:
			f.write(info)

		# print(info)
		info = info.replace('\\', '\\\\')
		# info = info.replace('\\u', '_u')
		# info = info.replace('/', '')
				
		datum = json.loads(info, strict = True)
		return datum["query"]

	return None

def query_word(word):

	wordFile =  os.path.join(os.getcwd(), word + ".json")
	wordInfoFile = os.path.join(os.getcwd(), word + ".info.json")

	if os.path.exists(wordFile):
		with open(wordFile, 'rb') as f:
			dict = f.read()
			inWord = GetInWord(dict, wordInfoFile)

		if(inWord):
			if inWord == word:
				print("%s's json is OK!" %word)
			else:
				datum = "Wrong word: " + word
				return False, datum
		else:
			datum = "No word in dictionary."
			return False, datum

	else:
		datum = "Fail to download: " + word
		return False, datum

	if(dict):
		dictDatum = json.loads(dict, strict = False)
		# print(dictDatum)

		if(dictDatum["ok"]):
			info = dictDatum["info"]

			# regex = re.compile(r'\\(?![/u"])')
			# info_fixed = regex.sub(r"\\\\", info)
			# dict = info_fixed
			datum = info
			# print("%s = %s" %(word, dict))
			return True, datum
	else:
		datum = "Fail to read: " + word
		return False, datum

	datum = "Unknown error!"
	return False, datum

word = "worn"
bDictOK, dict = query_word(word)
print(bDictOK, dict)