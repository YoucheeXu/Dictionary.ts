#!/usr/bin/python3
#-*- encoding:utf-8 -*-
# -*- coding: utf-8 -*-
#coding=utf-8

import os
import json

def GetInWord(info):

	info = info.replace('\\', '\\\\')				
	datum = json.loads(info, strict = True)
	return datum["query"]

def query_word(wordInfoFile):

	if os.path.exists(wordInfoFile):
		with open(wordInfoFile, 'r') as f:
			dict = f.read()
			inWord = GetInWord(dict)

		if(inWord):
			if inWord == word:
				print("%s's json is OK!" %word)
			else:
				datum = "Wrong word: " + inWord
				return False, datum
		else:
			datum = "No word in dictionary."
			return False, datum

	else:
		datum = "Fail to download: " + word
		return False, datum

	if(dict):
		dictDatum = json.loads(dict, strict = False)
		# print(dictDatum)

		if(dictDatum["ok"]):
			info = dictDatum["info"]
			datum = info
			return True, datum
	else:
		datum = "Fail to read: " + word
		return False, datum

	datum = "Unknown error!"
	return False, datum

word = "Template"
wordFile =  os.path.join(os.getcwd(), word + ".json")
print(wordFile)
bDictOK, dict = query_word(wordFile)
print(bDictOK, dict)