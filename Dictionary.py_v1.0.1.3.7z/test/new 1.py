from ctypes import *
from ctypes.wintypes import *

# defs

FindWindowF = WINFUNCTYPE(HWND, LPWSTR, LPWSTR)
FindWindow = FindWindowF(windll.user32.FindWindowW)

GetWindowTextF = WINFUNCTYPE(c_int, HWND, POINTER(c_wchar), c_int)
GetWindowText = GetWindowTextF(windll.user32.GetWindowTextW)

# code

text = create_unicode_buffer(255)

hwnd = FindWindow(None, 'E:\\Green\\Dictonary3\\new 1.py - Notepad++')
GetWindowText(hwnd, text, sizeof(text))

print text.value