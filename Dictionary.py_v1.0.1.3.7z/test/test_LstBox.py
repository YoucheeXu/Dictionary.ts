#!/usr/bin/python
# -*- coding: UTF-8 -*-

# ~ import ttk
# ~ from Tkinter import *
# ~ root = Tk()
# ~ tree = ttk.Treeview(root, columns=('col1','col2','col3'))

# ~ tree.column('col1', width=100, anchor='center')
# ~ tree.column('col2', width=100, anchor='center')
# ~ tree.column('col3', width=100, anchor='center')
# ~ tree.heading('col1', text='col1')
# ~ tree.heading('col2', text='col2')
# ~ tree.heading('col3', text='col3')

# ~ def onDBClick(event):
    # ~ item = tree.selection()[0]
    # ~ print "you clicked on ", tree.item(item, "values")
    
# ~ for i in range(10):
    # ~ tree.insert('',i,values=('a'+str(i),'b'+str(i),'c'+str(i)))
# ~ tree.bind("<Double-1>", onDBClick)


# ~ tree.pack()
# ~ root.mainloop()

# ~ import ttk
# ~ from Tkinter import *
# ~ root = Tk()
# ~ tree = ttk.Treeview(root, columns=('col1','col2','col3'))

# ~ tree.column('col1', width=100, anchor='center')
# ~ tree.column('col2', width=100, anchor='center')
# ~ tree.column('col3', width=100, anchor='center')
# ~ tree.heading('col1', text='col1')
# ~ tree.heading('col2', text='col2')
# ~ tree.heading('col3', text='col3')

# ~ def onDBClick(event):
    # ~ item = tree.selection()[0]
    # ~ print "you clicked on ", tree.item(item, "values")
    
# ~ for i in range(10):
    # ~ tree.insert('',i,values=('a'+str(i),'b'+str(i),'c'+str(i)))
# ~ tree.bind("<Double-1>", onDBClick)


# ~ tree.pack()
# ~ root.mainloop()

# ~ from tkinter import *
# ~ import ttk
# ~ root = Tk()
# ~ root.geometry("800x600")

# ~ tv = ttk.Treeview(root, height =10,columns=('c1','c2','c3'))
# ~ for i in range(1000):
    # ~ tv.insert('',i,values=('a'+str(i),'b'+str(i),'c'+str(i)))
# ~ tv.pack()

# ~ #----vertical scrollbar------------
# ~ vbar = ttk.Scrollbar(root,orient=VERTICAL,command=tv.yview)
# ~ tv.configure(yscrollcommand=vbar.set)
# ~ tv.grid(row=0,column=0,sticky=NSEW)
# ~ vbar.grid(row=0,column=1,sticky=NS)

# ~ #----horizontal scrollbar----------
# ~ hbar = ttk.Scrollbar(root,orient=HORIZONTAL,command=tv.xview)
# ~ tv.configure(xscrollcommand=hbar.set)
# ~ hbar.grid(row=1,column=0,sticky=EW)
# ~ root.mainloop()


import tkinter
from  tkinter import ttk  #导入内部包
 
win=tkinter.Tk()
tree=ttk.Treeview(win)#表格
tree["columns"]=("姓名","年龄","身高")
tree.column("姓名",width=100)   #表示列,不显示
tree.column("年龄",width=100)
tree.column("身高",width=100)
 
tree.heading("姓名",text="姓名-name")  #显示表头
tree.heading("年龄",text="年龄-age")
tree.heading("身高",text="身高-tall")
 
tree.insert("",0,text="line1" ,values=("1","2","3")) #插入数据，
tree.insert("",1,text="line1" ,values=("1","2","3"))
tree.insert("",2,text="line1" ,values=("1","2","3"))
tree.insert("",3,text="line1" ,values=("1","2","3"))
 
tree.pack()
win.mainloop()
