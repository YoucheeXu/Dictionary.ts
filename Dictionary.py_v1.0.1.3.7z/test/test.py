#!/usr/bin/python3
# -*- coding: utf-8 -*-

import os

# audioFile = "/home/youchee/Green/Dictionary/Audio/Google/able.mp3"
audioFile = "/home/youchee/Green/Dictionary/audio/Google/able.mp3"
# print(os.path.exists(audioFile))
wordFile = "/home/youchee/Green/Dictionary/dict/Google/a/able.json"
print(os.path.exists(wordFile))

