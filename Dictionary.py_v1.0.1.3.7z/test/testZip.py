'''
Created on Dec 24, 2012 
将文件归档到zip文件，并从zip文件中读取数据 
@author: liury_lab 
'''
# 压缩成zip文件 
from zipfile import *  #@UnusedWildImport 
import os 

my_dir = 'd:/中华十大名帖/' 
# 压缩模式有ZIP_STORED和ZIP_DEFLATED，ZIP_STORED只是存储模式，不会对文件进行压缩，这个是默认值，如果你需要对文件进行压缩，必须使用ZIP_DEFLATED模式
myzip = ZipFile('d:/中华十大名帖.zip', 'w', ZIP_DEFLATED) 
for file_name in os.listdir(my_dir): 
	file_path = my_dir + file_name 
	print(file_path) 
	myzip.write(file_path) 
myzip.close()

print('finished') 

# 从zip 文件中读取数据 
# 直接检查一个zip格式的归档文件中部分或所有的文件，
# 同时还要避免将这些文件展开到磁盘上 
my_zip = ZipFile('d:/中华十大名帖.zip') 
for file_name in my_zip.namelist(): 
	print('File:', file_name, end = ' ') 
	file_bytes = my_zip.read(file_name) 
	print('has ', len(file_bytes), ' bytes')

from win32com.shell import shell,shellcon
debug=False
def deltorecyclebin(filename):
    print('deltorecyclebin', filename)
    # os.remove(filename) #直接删除文件，不经过回收站
    if not debug:
        res= shell.SHFileOperation((0,shellcon.FO_DELETE,filename,None, shellcon.FOF_SILENT | shellcon.FOF_ALLOWUNDO | shellcon.FOF_NOCONFIRMATION,None,None))  #删除文件到回收站
        if not res[1]:
            os.system('del '+filename)

pip install Send2Trash
from send2trash import send2trash
send2trash('some_file')