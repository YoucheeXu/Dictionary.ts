#!/usr/bin/python
#encoding:utf-8
import urllib.request
import os

img = "http://vip.zuiku8.com/1810/妖精的尾巴最终季-01.mp4"

def Schedule(a,b,c):
   '''
   a:已经下载的数据块
   b:数据块的大小
   c:远程文件的大小
   '''
   per = 100.0*a*b/c
   if per > 100:
      per = 100
   print('%.2f%%' %per)


def main():
   path = img.split(".")[-1]
   urllib.request.urlretrieve(img, path, Schedule)

if __name__ == '__main__':
   main()