#!/usr/bin/python3
#-*- encoding:utf-8 -*-
# -*- coding: utf-8 -*-
#coding=utf-8

import os
import sys
# import globalVar

import json
import re


jsonFile1 = "E:\\Green\\Dictionary\\dict\\Google\\a\\abed.json"
jsonFile2 = "E:\\Green\\Dictionary\\dict\\Google\\a\\abet.json"
# jsonFile = "E:\\Green\\Dictionary\\dict\\Google\\a\\abandon.json"

# file = open(jsonFile, encoding = 'utf-8')
# file = open(jsonFile)
# try:
	 # dict0 = file.read()
# except Exception as err:
	# print(err)
# finally:
	 # file.close()
# print(dict)

with open(jsonFile1, 'rb') as f:
# with open(jsonFile, encoding = 'utf-8') as f:
	dict0 = f.read()
	n = len(dict0)
	print(dict0[:18])
	# print("{".encode('utf-8'))
	# print(bytes("{", 'utf-8'))
	'''
	for n in range(10):
		print(dict0[n], dict0[:n])
		# dictZero = dict0[n:]
		print(dict0[:n])

	print(dict0[:18])
	'''
	# dict0 = dict0.replace(u": \"{", u": {")
	# dict0 = dict0.replace(u"}\"", u"}")
	# print(dict0[:18])
	datum = json.loads(dict0, strict = False)
	for key,value in datum.items():
		print(key, value)

	print(datum["ok"])
	info = datum["info"]

	regex = re.compile(r'\\(?![/u"])')
	info_fixed = regex.sub(r"\\\\", info)
	datum = json.loads(info_fixed, strict = False)
	print(datum["query"])

# 
# 
# print(dict0[:18])
# 



# print(dict0[:6])
# # datum = json.loads(dict0_fixed, strict = False)
# 

# regex = re.compile(r'\\(?![/u"])')
# dict0_fixed = regex.sub(r"\\\\", dict0)

# for key,value in datum.items():
	# print(key, value)

# print(datum["ok"])
# print(type(datum["ok"]))

sys.exit()

dict1 = '''
{
	"info": {
		\"query\": \"abed\",
		\"sourceLanguage\": \"en\",
		\"targetLanguage\": \"zh-Hans\",
		\"primaries\": [{
			\"type\":\"headword\",
			\"terms\": [{
				\"type\":\"text\",
				\"text\":\"abed\",
				\"language\":\"en\"
				}, {
					\"type\":\"phonetic\",
					\"text\":\"/\u0259\u02c8bed/\",
					\"language\":\"en\",
					\"labels\":[{
						\"text\":\"DJ\",
						\"title\":\"Phonetic\"
					}]
				},{
					\"type\":\"phonetic\",
					\"text\":\"/\u0259\\x27b\u025bd/\",
					\"language\":\"en\",
					\"labels\": [{
						\"text\":\"KK\",
						\"title\":\"Phonetic\"
					}]
				}
			],
			\"entries\":[{
				\"type\":\"meaning\",
				\"terms\":[{
					\"type\":\"text\",
					\"text\":\"in bed\",
					\"language\":\"en\"
				},
				{\"type\":\"text\",
				\"text\":\"\u5728\u5e8a\u4e0a\",
				\"language\":\"zh-Hans\",
				\"labels\":[{\"text\":\"adverb\",
				\"title\":\"Part-of-Speech\"},
				{\"text\":\"old-use\",
				\"title\":\"Register\"}]}],
				\"entries\":[{\"type\":\"example\",
				\"terms\":[{\"type\":\"text\",
				\"text\":\"lying abed\",
				\"language\":\"en\"},
				{\"type\":\"text\",
				\"text\":\"\u8eba\u5728\u5e8a\u4e0a\",
				\"language\":\"zh-Hans\"}]}]
			}]}],
		\"webDefinitions\":[{\"type\":\"headword\",
		\"terms\":[{\"type\":\"text\",
		\"text\":\"abed\",
		\"language\":\"en\"}],
		\"entries\":[{\"type\":\"meaning\",
		\"terms\":[{\"type\":\"text\",
		\"text\":\"in bed\",
		\"language\":\"en\"},
		{\"type\":\"url\",\"text\":\"\\x3ca href\\x3d\\x22http://wordnetweb.princeton.edu/perl/webwn?s\\x3dabed\\x22\\x3ehttp://wordnetweb.princeton.edu/perl/webwn?s\\x3dabed\\x3c/a\\x3e\",
		\"language\":\"en\"}]},
		{\"type\":\"meaning\",
		\"terms\":[{\"type\":\"text\",
		\"text\":\"Abed is a word meaning \\x26quot;to be in bed\\x26quot;. Its use tends to be archaic. As a surname, it may refer to: * Fazle Hasan Abed (born 1936), Bangladeshi social worker * P\u00e9p\u00e9 Abed (1911-2006), Lebanese adventurer and entrepreneur * Ramzi Abed (born 1973), American film director * Shilu Abed (died 1997), ...\",
		\"language\":\"en\"},
		{\"type\":\"url\",
		\"text\":\"\\x3ca href\\x3d\\x22http://en.wikipedia.org/wiki/Abed\\x22\\x3ehttp://en.wikipedia.org/wiki/Abed\\x3c/a\\x3e\",
		\"language\": \"en\"
		}]}]}]
	},
	"ok": true
}
'''

# regex = re.compile(r'\\(?![/u"])')
# dict1_fixed = regex.sub(r"\\\\", dict1)

# # print(dict1[:18])
# # datum = json.loads(dict1, strict = False)
# datum = json.loads(dict1_fixed, strict = False)

# for key,value in datum.items():
	# print(key, value)

# print(datum["ok"])
# print(type(datum["ok"]))

# sys.exit()

dict2 = '''
		{\"query\": \"abed\",
		\"sourceLanguage\": \"en\",
		\"targetLanguage\": \"zh-Hans\",
		\"primaries\": [{
			\"type\":\"headword\",
			\"terms\": [{
				\"type\":\"text\",
				\"text\":\"abed\",
				\"language\":\"en\"
				}, {
					\"type\":\"phonetic\",
					\"text\":\"/\u0259\u02c8bed/\",
					\"language\":\"en\",
					\"labels\":[{
						\"text\":\"DJ\",
						\"title\":\"Phonetic\"
					}]
				},{
					\"type\":\"phonetic\",
					\"text\":\"/\u0259\\x27b\u025bd/\",
					\"language\":\"en\",
					\"labels\": [{
						\"text\":\"KK\",
						\"title\":\"Phonetic\"
					}]
				}
			],
			\"entries\":[{
				\"type\":\"meaning\",
				\"terms\":[{
					\"type\":\"text\",
					\"text\":\"in bed\",
					\"language\":\"en\"
				},
				{\"type\":\"text\",
				\"text\":\"\u5728\u5e8a\u4e0a\",
				\"language\":\"zh-Hans\",
				\"labels\":[{\"text\":\"adverb\",
				\"title\":\"Part-of-Speech\"},
				{\"text\":\"old-use\",
				\"title\":\"Register\"}]}],
				\"entries\":[{\"type\":\"example\",
				\"terms\":[{\"type\":\"text\",
				\"text\":\"lying abed\",
				\"language\":\"en\"},
				{\"type\":\"text\",
				\"text\":\"\u8eba\u5728\u5e8a\u4e0a\",
				\"language\":\"zh-Hans\"}]}]
			}]}],
		\"webDefinitions\":[{\"type\":\"headword\",
		\"terms\":[{\"type\":\"text\",
		\"text\":\"abed\",
		\"language\":\"en\"}],
		\"entries\":[{\"type\":\"meaning\",
		\"terms\":[{\"type\":\"text\",
		\"text\":\"in bed\",
		\"language\":\"en\"},
		{\"type\":\"url\",\"text\":\"\\x3ca href\\x3d\\x22http://wordnetweb.princeton.edu/perl/webwn?s\\x3dabed\\x22\\x3ehttp://wordnetweb.princeton.edu/perl/webwn?s\\x3dabed\\x3c/a\\x3e\",
		\"language\":\"en\"}]},
		{\"type\":\"meaning\",
		\"terms\":[{\"type\":\"text\",
		\"text\":\"Abed is a word meaning \\x26quot;to be in bed\\x26quot;. Its use tends to be archaic. As a surname, it may refer to: * Fazle Hasan Abed (born 1936), Bangladeshi social worker * P\u00e9p\u00e9 Abed (1911-2006), Lebanese adventurer and entrepreneur * Ramzi Abed (born 1973), American film director * Shilu Abed (died 1997), ...\",
		\"language\":\"en\"},
		{\"type\":\"url\",
		\"text\":\"\\x3ca href\\x3d\\x22http://en.wikipedia.org/wiki/Abed\\x22\\x3ehttp://en.wikipedia.org/wiki/Abed\\x3c/a\\x3e\",
		\"language\": \"en\"
		}]}]}]
		}
'''

# regex = re.compile(r'\\(?![/u"])')
# dict2_fixed = regex.sub(r"\\\\", dict2)
# # print(dict2_fixed)

# # print(dict2[:386])

# # datum = json.loads(dict2, strict = False)
# datum = json.loads(dict2_fixed, strict = False)

# for key,value in datum.items():
	# print(key, value)

# sys.exit()

dict3 = '''
{"info": "{\"query\":\"abed\",\"sourceLanguage\":\"en\",\"targetLanguage\":\"zh-Hans\",\"primaries\":[{\"type\":\"headword\",\"terms\":[{\"type\":\"text\",\"text\":\"abed\",\"language\":\"en\"},{\"type\":\"phonetic\",\"text\":\"/\u0259\u02c8bed/\",\"language\":\"en\",\"labels\":[{\"text\":\"DJ\",\"title\":\"Phonetic\"}]},{\"type\":\"phonetic\",\"text\":\"/\u0259\\x27b\u025bd/\",\"language\":\"en\",\"labels\":[{\"text\":\"KK\",\"title\":\"Phonetic\"}]}],\"entries\":[{\"type\":\"meaning\",\"terms\":[{\"type\":\"text\",\"text\":\"in bed\",\"language\":\"en\"},{\"type\":\"text\",\"text\":\"\u5728\u5e8a\u4e0a\",\"language\":\"zh-Hans\",\"labels\":[{\"text\":\"adverb\",\"title\":\"Part-of-Speech\"},{\"text\":\"old-use\",\"title\":\"Register\"}]}],\"entries\":[{\"type\":\"example\",\"terms\":[{\"type\":\"text\",\"text\":\"lying abed\",\"language\":\"en\"},{\"type\":\"text\",\"text\":\"\u8eba\u5728\u5e8a\u4e0a\",\"language\":\"zh-Hans\"}]}]}]}],\"webDefinitions\":[{\"type\":\"headword\",\"terms\":[{\"type\":\"text\",\"text\":\"abed\",\"language\":\"en\"}],\"entries\":[{\"type\":\"meaning\",\"terms\":[{\"type\":\"text\",\"text\":\"in bed\",\"language\":\"en\"},{\"type\":\"url\",\"text\":\"\\x3ca href\\x3d\\x22http://wordnetweb.princeton.edu/perl/webwn?s\\x3dabed\\x22\\x3ehttp://wordnetweb.princeton.edu/perl/webwn?s\\x3dabed\\x3c/a\\x3e\",\"language\":\"en\"}]},{\"type\":\"meaning\",\"terms\":[{\"type\":\"text\",\"text\":\"Abed is a word meaning \\x26quot;to be in bed\\x26quot;. Its use tends to be archaic. As a surname, it may refer to: * Fazle Hasan Abed (born 1936), Bangladeshi social worker * P\u00e9p\u00e9 Abed (1911-2006), Lebanese adventurer and entrepreneur * Ramzi Abed (born 1973), American film director * Shilu Abed (died 1997), ...\",\"language\":\"en\"},{\"type\":\"url\",\"text\":\"\\x3ca href\\x3d\\x22http://en.wikipedia.org/wiki/Abed\\x22\\x3ehttp://en.wikipedia.org/wiki/Abed\\x3c/a\\x3e\",\"language\":\"en\"}]}]}]}", "ok": true}
'''

dict3 = dict3.replace("\"{", "{")
dict3 = dict3.replace("}\"", "}")

regex = re.compile(r'\\(?![/u"])')
dict3_fixed = regex.sub(r"\\\\", dict3)
# print(dict3_fixed)

print(dict3[:13])

# datum = json.loads(dict3, strict = False)
datum = json.loads(dict3_fixed, strict = False)

for key,value in datum.items():
	print(key, value)

# str0 = '\"/\u0259\u02c8bed/\"'
# str1 = b'\u0259'.decode('unicode-escape')
# str2 = b'\u8bf7'.decode('unicode-escape')
# print(str0)