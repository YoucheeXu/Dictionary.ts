#! /usr/bin/env python
# -*- coding: utf-8 -*-
#coding:utf-8

from SDictBase import *
import datetime

sFile = sys.path[0] + "\\Dict\\15000.dict"
mySDict = SDictBase()
if mySDict.open(sFile) == False:
	print("can't open: " + sFile)
	exit(-1)

wd = "o''clock"

txtLst = []
mySDict.update_item(wd, 'familiar', '10')
mySDict.get_all(wd, txtLst)

# mySDict.update_item(wd, 'familiar', '0.0')
# mySDict.update_item(wd, 'lastdate', None)

print("txtLst: ", txtLst)

# # mySDict.update_word2('attain', 'Symbol', "?''tein")

for item in txtLst:
	print("%s, " %item)

# lastDate = mySDict.get_word_item(wd, "LastDate")

# print("LastDate: ", lastDate)

# if lastDate == None:
        # print("%s is new!" %wd)

# selDate = datetime.date.today() - datetime.timedelta(1)
# lastdate = datetime.date.strftime(selDate, "%Y-%m-%d")
# where = "level = 'CET6' and lastdate = date('" + lastdate + "') and familiar < 10"

# num = mySDict.get_count(where)
# print("lastdate: " + lastdate + ", len: " + str(num))

mySDict.close()
