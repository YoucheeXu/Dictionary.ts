#!/usr/bin/python3
# -*- coding: utf-8 -*-

mp4 = "http://vip.zuiku8.com/1810/妖精的尾巴最终季-01.mp4"

#create the object, assign it to a variable
proxy = urllib.request.ProxyHandler({'http': '127.0.0.1'})
# construct a new opener using your proxy settings
opener = urllib.request.build_opener(proxy)
# install the openen on the module-level
urllib.request.install_opener(opener)
# make a request
urllib.request.urlretrieve('http://www.google.com')