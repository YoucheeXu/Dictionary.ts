#!/usr/bin/python3
# -*- coding: utf-8 -*-

import zipfile
import mp3play
import io
import os

curPath = os.getcwd()

audioZip = os.path.join(curPath, "audio", "Google.zip")

archive = zipfile.ZipFile(audioZip, 'r')
file_data = archive.read('able.mp3')
# bytes_io = io.BytesIO(file_data)

# surface = pygame.image.load(bytes_io)

# clip = mp3play.load(bytes_io)
clip = mp3play.load(file_data)
clip.play()
time.sleep(min(30, clip.seconds() + 0.3))
clip.stop()