def abc():
	global a
	a = 5
	print(a)

def abc2():
	print(a)


abc()
abc2()