import threading
class MyThread(threading.Thread):

	def __init__(self, func, args):
		threading.Thread.__init__(self)
		self.func = func
		self.args = args
		self.result = self.func(*self.args)

	def get_result(self):
		try:
			return self.result
		except Exception:
			# print(traceback.print_exc())
			return "threading result except"

#	复制以上代码 原本代码改写如下

def say_hello(i, v):
	ret =  {"hello": i}
	v.append(ret)
	return ret

def threading_get_return():
	vendorCode = []
	th_list = []
	v = []
	for i in range(1000):
		j = i*i
		th = MyThread(say_hello, args=(i, v))
		th.start()
		th_list.append(th)		
   	
	print(v)
	
	for th in th_list:
		th.join()
		result = th.get_result()
		vendorCode.append(result)

	print(vendorCode)

if __name__ == '__main__':
	threading_get_return()