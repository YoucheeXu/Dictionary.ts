import ctypes
import os
import platform
from tkinter import *
from tkinter.ttk import *

def Get_HWND_DPI(window_handle):
	# To detect high DPI displays and avoid need to set Windows compatibility flags
	if os.name == "nt":
		from ctypes import windll, pointer, wintypes
		try:
			# Windows 8.1 6.3
			# Windows 8 6.2
			# Windows 7 6.1
			# Windows Server 2008 R2 6.1
			# Windows Server 2008 6.0
			# Windows Vista 6.0
			os_ver = float(re.match("\d+(\.\d+){0,1}", platform.win32_ver()[1]).group())
			if os_ver >= 6.3:
				# Minimum supported client:	Windows 8.1 [desktop apps only]
				PROCESS_DPI_UNAWARE = 0
				# DPI unaware. This app does not scale for DPI changes and is always assumed to have a scale factor of 100% (96 DPI). It will be automatically scaled by the system on any other DPI setting.
				PROCESS_SYSTEM_DPI_AWARE = 1
				# System DPI aware. This app does not scale for DPI changes. It will query for the DPI once and use that value for the lifetime of the app. If the DPI changes, the app will not adjust to the new DPI value. It will be automatically scaled up or down by the system when the DPI changes from the system value.
				PROCESS_PER_MONITOR_DPI_AWARE = 2
				# Per monitor DPI aware. This app checks for the DPI when it is created and adjusts the scale factor whenever the DPI changes. These applications are not automatically scaled by the system.
				windll.shcore.SetProcessDpiAwareness(PROCESS_SYSTEM_DPI_AWARE)	# 告诉操作系统使用程序自身的dpi适配
			elif os_ver >= 6.0:
				# Minimum supported client:	Windows Vista [desktop apps only]
				ret = windll.user32.SetProcessDPIAware()
				if ret == 0:
					print("Fait to SetProcessDPIAware")
			hWnd = wintypes.HWND(window_handle)
			DPI100pc = 96  # DPI 96 is 100% scaling
			X = wintypes.UINT()
			Y = wintypes.UINT()
			if os_ver >= 6.3:
				# Minimum supported client: Windows 2000 Professional [desktop apps only]
				MONITOR_DEFAULTTONEAREST = 2
				monitorhandle = windll.user32.MonitorFromWindow(hWnd, MONITOR_DEFAULTTONEAREST)
				# Minimum supported client	Windows 8.1 [desktop apps only]
				MDT_EFFECTIVE_DPI = 0
				MDT_ANGULAR_DPI = 1
				MDT_RAW_DPI = 2
				windll.shcore.GetDpiForMonitor(monitorhandle, MDT_EFFECTIVE_DPI, pointer(X), pointer(Y))
			else:
				# Minimum supported client:	Windows 2000 Professional [desktop apps only]
				hDC = windll.user32.GetDC(hWnd)
				# Minimum supported client: Windows 2000 Professional [desktop apps only]
				LOGPIXELSX = 88
				LOGPIXELSY = 90
				X = windll.gdi32.GetDeviceCaps(hDC, LOGPIXELSX);	# 每英寸逻辑像素数 水平
				Y = windll.gdi32.GetDeviceCaps(hDC, LOGPIXELSY); 	# 每英寸逻辑像素数 垂直
			# return X.value, Y.value, (X.value + Y.value) / (2 * DPI100pc)
			return X, Y, (X + Y) / (2 * DPI100pc)
		except Exception as e:
			print("Error: " + str(e))
		return 96, 96, 1  # Assume standard Windows DPI & scaling
	else:
		return None, None, 1  # What to do for other OSs?


def fac(x):
    if x==0 or x==1:
        return 1
    elif x>1:
        return x*fac(x-1)
root=Tk()
# # 调用api设置成由应用程序缩放
# # ctypes.windll.shcore.SetProcessDpiAwareness(1)
# # 调用api获得当前的缩放因子
# ScaleFactor=ctypes.windll.shcore.GetScaleFactorForDevice(0)
# # 设置缩放因子
X, Y, ScaleFactor = Get_HWND_DPI(root.winfo_id())
print(X, Y, ScaleFactor)
root.tk.call('tk', 'scaling', ScaleFactor/75)
root.title('计算阶乘')
frame1=Frame(root)
frame1.pack(side='top',anchor='center',expand='yes')
lable1=Label(frame1,text='input')
lable2=Label(frame1,text='output')
entry1=Entry(frame1)
entry2=Entry(frame1)
def button1_clicked():
    entry2.delete(0,END)
    entry2.insert(0,str(fac(eval(entry1.get()))))
button1=Button(frame1,text='Run',command=button1_clicked)
button2=Button(frame1,text='Quit',command=root.quit)
lable1.grid(row=0,column=0,pady=3,padx=3)
lable2.grid(row=1,column=0,pady=3,padx=3)
entry1.grid(row=0,column=1,pady=3,padx=3)
entry2.grid(row=1,column=1,pady=3,padx=3)
button1.grid(row=2,column=0,sticky=W,pady=3,padx=3)
button2.grid(row=2,column=1,sticky=E,pady=3,padx=3)
root.mainloop()