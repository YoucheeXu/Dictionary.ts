import threading

def say_hello(i, vendorCode):
	#  return {"hello": i}
	vendorCode.append({"hello": i})

def threading_get_return():
	vendorCode = []
	th_list = []
	for i in range(1000):
		th = threading.Thread(say_hello, args=(i, vendorCode))
		th.start()
		th_list.append(th)
		# vendorCode.append(result)
   	
   	#	运用局部变量 此处一定要join
	for th in th_list:
		th.join()

if __name__ == '__main__':
	threading_get_return()