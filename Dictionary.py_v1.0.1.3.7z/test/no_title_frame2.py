#!/usr/bin/python3
# -*- coding: utf-8 -*-

import sys, os, shutil
sys.dont_write_bytecode = True

import tkinter as tk
import tkinter.ttk as ttk

from cefpython3 import cefpython as cef

sys.path.append("..")
from utils import *

WindowUtils = cef.WindowUtils()

# Constants
# Tk 8.5 doesn't support png images
IMAGE_EXT = ".png" if tk.TkVersion > 8.5 else ".gif"

class MainFrame(tk.Frame):

	def __init__(self):

		self.__enableMove = False

	def Create(self, width, height, fileURL):

		self.__browser_frame = None
		self.__navigation_bar = None

		# Root
		self.__root = tk.Tk()

		# self.__root.attributes('-alpha', 0.0) #For icon
		# self.__root.iconify()
		# self.__window = tk.Toplevel(self.__root)
		# self.__window.geometry(size)

		tk.Grid.rowconfigure(self.__root, 0, weight = 1)
		tk.Grid.columnconfigure(self.__root, 0, weight = 1)

		# MainFrame
		tk.Frame.__init__(self, self.__root)
		self.master.title("Dictionary")
		self.master.protocol("WM_DELETE_WINDOW", self.__on_close)
		# self.bind("<Destroy>", self.__destory)
		self.bind("<Configure>", self.__on_configure)
		self.master.bind("<Configure>", self.__on_root_configure)
		self.__setup_icon()								

		# # NavigationBar
		# self.__navigation_bar = NavigationBar(self)
		# self.__navigation_bar.grid(row=0, column=0,
		#						  sticky=(tk.N + tk.S + tk.E + tk.W))
		# tk.Grid.rowconfigure(self, 0, weight=0)
		# tk.Grid.columnconfigure(self, 0, weight=0)

		# BrowserFrame
		self.__browser_frame = BrowserFrame(self, fileURL, self.__navigation_bar)
		self.__browser_frame.grid(row = 1, column = 0,
								 sticky = (tk.N + tk.S + tk.E + tk.W))
		tk.Grid.rowconfigure(self, 1, weight = 1)
		tk.Grid.columnconfigure(self, 0, weight = 1)

		# Pack MainFrame
		self.pack(fill = tk.BOTH, expand = tk.YES)

		screenwidth = self.__root.winfo_screenwidth()
		screenheight = self.__root.winfo_screenheight()  
		size = '%dx%d+%d+%d' % (width, height, (screenwidth - width)/2, (screenheight - height)/2)

		gLogger.info("size: %s" %size)

		self.__root.geometry(size)

		if IsWindows():
			self.__root.iconbitmap(default = 'main.ico')

			self.__root.overrideredirect(True)	#no title

			self.__root.after(10, lambda: self.__set_appwindow())

		elif IsLinux():
			self.__root.wm_attributes('-type', 'splash')

	def __set_appwindow(self):
		if IsWindows():

			from ctypes import windll

			GWL_EXSTYLE = -20
			WS_EX_APPWINDOW = 0x00040000
			WS_EX_TOOLWINDOW = 0x00000080

			hWnd = windll.user32.GetParent(self.__root.winfo_id())
			gLogger.info("hWnd: %d" %hWnd)

			if Is32bit():
				style = windll.user32.GetWindowLongW(hWnd, GWL_EXSTYLE)			# 32bit python
			else:
				style = windll.user32.GetWindowLongPtrW(hWnd, GWL_EXSTYLE)		# 64bit python
			style = style & ~WS_EX_TOOLWINDOW
			style = style | WS_EX_APPWINDOW
			if Is32bit():
				res = windll.user32.SetWindowLongW(hWnd, GWL_EXSTYLE, style)
			else:
				res = windll.user32.SetWindowLongPtrW(hWnd, GWL_EXSTYLE, style)		# 64bit python

			# re-assert the new window style
			self.__root.wm_withdraw()
			self.__root.after(10, lambda: self.__root.wm_deiconify())

	def __on_root_configure(self, _):
		# global gLogger

		gLogger.debug("MainFrame.on_root_configure")
		if self.__browser_frame:
			self.__browser_frame.on_root_configure()

	def __on_configure(self, event):
		# global gLogger

		gLogger.debug("MainFrame.on_configure")
		if self.__browser_frame:
			width = event.width
			height = event.height
			if self.__navigation_bar:
				height = height - self.__navigation_bar.winfo_height()
			self.__browser_frame.on_mainframe_configure(width, height)

	def __on_close(self):
		# global gLogger

		gLogger.info("MainFrame.on_close")
		if self.__browser_frame:
			self.__browser_frame.on_root_close()
		self.master.destroy()		

	def start_move(self, x, y):
		# gLogger.info("startMove!")
		self.__enableMove = True
		# self.x = event.x
		self.__x = x
		# self.y = event.y
		self.__y = y

		self.__root_x = self.__root.winfo_rootx()
		self.__root_y = self.__root.winfo_rooty()

		# gLogger.info("self.x: %d self.y: %d" %(self.__x, self.__y))
		# gLogger.info("self.root_x: %d self.root_y: %d" %(self.__root_x, self.__root_y))

	def moving(self, x, y):
		if(not self.__enableMove): return

		newX = self.__root_x + x - self.__x 
		# newX = self.winfo_x() + x - self.x 
		newY = self.__root_y + y - self.__y
		# newY = self.winfo_y() + y - self.y

        # deltax = event.x - self.x
        # deltay = event.y - self.y
        # x = self.winfo_x() + deltax
        # y = self.winfo_y() + deltay

		# gLogger.info("newX: %d newY: %d" %(newX, newY))

		# self.__root.geometry("+%s+%s" %(newX, newY))
		self.__root.geometry("+%s+%s" %(newX, newY))

	def stop_move(self, x, y):
		# gLogger.info("stopMove!")
		self.__enableMove = False
		self.__x = None
		self.__y = None

	def get_browser(self):
		if self.__browser_frame:
			return self.__browser_frame.get_browser()
		return None

	def get_browser_frame(self):
		if self.__browser_frame:
			return self.__browser_frame
		return None

	def min(self):
		return
		# self.master.wm_withdraw()
		# self.master.wm_iconify()
		self.master.update_idletasks()
		self.master.overrideredirect(False)
		#root.state('withdrawn')
		self.master.state('iconic')

	def restore(self):
		self.master.wm_deiconify()

	def __frame_mapped(self, e):
		# self.master.update_idletasks()
		# self.master.state('normal')
		pass

	def __setup_icon(self):
		icon_path = os.path.join(os.path.dirname(__file__), "main" + IMAGE_EXT)
		if os.path.exists(icon_path):
			self.icon = tk.PhotoImage(file = icon_path)
			# noinspection PyProtectedMember
			self.master.call("wm", "iconphoto", self.master._w, self.icon)

class BrowserFrame(tk.Frame):

	def __init__(self, master, fileURL, navigation_bar = None):
		self.__navigation_bar = navigation_bar
		self.closing = False
		self.__browser = None
		tk.Frame.__init__(self, master)
		self.bind("<FocusIn>", self.__on_focus_in)
		self.bind("<FocusOut>", self.__on_focus_out)
		self.bind("<Configure>", self.__on_configure)
		# self.master.master.protocol("WM_DELETE_WINDOW", self.on_root_close)
		self.focus_set()
		self.__fileURL = fileURL

	def __embed_browser(self):

		window_info = cef.WindowInfo()
		rect = [0, 0, self.winfo_width(), self.winfo_height()]
		window_info.SetAsChild(self.__get_window_handle(), rect)

		'''
		# INFO = 0, 
		# WARNING = 1, 
		# ERROR = 2, 
		# FATAL = 3
		# default is 0
		'''
		# options.add_argument('log-level=3')
	
		custom_settings = {
			"file_access_from_file_urls_allowed": True,\
			"universal_access_from_file_urls_allowed": True,\
			"web_security_disabled": True
		}

		# self.__fileURL = os.path.join(os.getcwd(), "gui/about_all.html")
		# gLogger.info("self.__fileURL = %s" %self.__fileURL)

		# self.__browser = cef.CreateBrowserSync(window_info, url="http://html5test.com/")
		self.__browser = cef.CreateBrowserSync(window_info, url = "file:///" + self.__fileURL, settings = custom_settings)

		assert self.__browser

		# global dictBrowser
		# dictBrowser = self.__browser
		# globalVar.GetApp().set_browser(self.__browser)

		# js
		js = cef.JavascriptBindings()
		js.SetObject('external', GetApp())
		self.__browser.SetJavascriptBindings(js)

		self.__browser.SetClientHandler(LoadHandler())
		self.__browser.SetClientHandler(FocusHandler(self))
		self.__message_loop_work()

	def __get_window_handle(self):
		if self.winfo_id() > 0:
			return self.winfo_id()
		elif MAC:
			# On Mac window id is an invalid negative value (Issue #308).
			# This is kind of a dirty hack to get window handle using
			# PyObjC package. If you change structure of windows then you
			# need to do modifications here as well.
			# noinspection PyUnresolvedReferences
			from AppKit import NSApp
			# noinspection PyUnresolvedReferences
			import objc
			# Sometimes there is more than one window, when application
			# didn't close cleanly last time Python displays an NSAlert
			# window asking whether to Reopen that window.
			# noinspection PyUnresolvedReferences
			return objc.pyobjc_id(NSApp.windows()[-1].contentView())
		else:
			raise Exception("Couldn't obtain window handle")

	def __message_loop_work(self):
		cef.MessageLoopWork()
		self.after(10, self.__message_loop_work)

	def __on_configure(self, _):
		if not self.__browser:
			self.__embed_browser()

	def on_root_configure(self):
		# Root <Configure> event will be called when top window is moved
		if self.__browser:
			self.__browser.NotifyMoveOrResizeStarted()

	def on_mainframe_configure(self, width, height):
		# gLogger.info("on_mainframe_configure")
		if self.__browser:
			if IsWindows():
				WindowUtils.OnSize(self.get_window_handle(), 0, 0, 0)
			elif IsLinux():
				self.__browser.SetBounds(0, 0, width, height)
			self.__browser.NotifyMoveOrResizeStarted()

	def __on_focus_in(self, _):

		gLogger.debug("BrowserFrame.on_focus_in")
		if self.__browser:
			self.__browser.SetFocus(True)

	def __on_focus_out(self, _):
		# global gLogger

		gLogger.debug("BrowserFrame.on_focus_out")
		if self.__browser:
			self.__browser.SetFocus(False)

	def on_root_close(self):
		gLogger.info("BrowserFrame.on_root_close")
		if self.__browser:
			self.__browser.CloseBrowser(True)
			self.__clear_browser_references()
		self.destroy()

	def get_browser(self):
		if self.__browser:
			return self.__browser
		return None

	def __clear_browser_references(self):
		# Clear browser references that you keep anywhere in your
		# code. All references must be cleared for CEF to shutdown cleanly.
		self.__browser = None

class LoadHandler(object):

	# def __init__(self, browser_frame):
	def __init__(self):
		# self.__browser_frame = browser_frame
		pass

	# def OnLoadStart(self, browser, **_):
		# if self.__browser_frame.master.navigation_bar:
			# self.__browser_frame.master.navigation_bar.set_url(browser.GetUrl())
		# # gLogger.info("LoadHandler.OnLoadStart")

	def OnLoadEnd(self, browser, **_):
		# browser.ExecuteFunction("log", "info", "LoadHandler.OnLoadEnd", False)
		gLogger.info("LoadHandler.OnLoadEnd")
		GetApp().add_tabs()

class FocusHandler(object):

	def __init__(self, browser_frame):
		self.__browser_frame = browser_frame

	def OnTakeFocus(self, next_component, **_):
		gLogger.debug("FocusHandler.OnTakeFocus, next = {next}"
					 .format(next=next_component))

	def OnSetFocus(self, source, **_):
		gLogger.debug("FocusHandler.OnSetFocus, source = {source}"
					 .format(source = source))
		return False

	def OnGotFocus(self, **_):
		"""Fix CEF focus issues (#255). Call browser frame's focus_set
		   to get rid of type cursor in url entry widget."""
		gLogger.debug("FocusHandler.OnGotFocus")
		# self.__browser_frame.focus_set()

class dictApp():

	def __init__(self):

		self.__bAgent = False

		# self.__dictBaseLst = []
		self.__dictBaseDict = {}
		self.__nTab = 0
		self.__curDictBase = None

	def __del__(self):
		print("dict App close")

	def Start(self, width, height, fileURL):
		self.__nTab = 0
		# self.__curDictBase = self.get_curDB()
		# self.__DictParseFun = self.__curDictBase.get_parseFun()

		self.__window = MainFrame()
		self.__window.Create(width, height, fileURL)	

	def mainloop(self):
		self.__window.mainloop()

	def OnButtonClicked(self, id):
		# global gLogger

		if id == "btn_close":
			# self.__window.destroy()
			self.__window.master.destroy()
			# sys.exit()

		elif id == "btn_min": self.__window.min()
		else: 
			gLogger.info(id)

	def add_tabs(self):
		pass

def main():
	global gLogger
	global app

	app = dictApp()

	settings = {
		"debug": True,
		"log_severity": cef.LOGSEVERITY_ERROR,
		"log_file": "log//debug.log"
	}
	cef.Initialize(settings = settings)

	frame = MainFrame()

	mainPath = os.path.abspath(os.path.join(os.getcwd(), ".."))

	logFile = os.path.join(mainPath, "log", "text.log")

	gLogger = CreateLogger("Dictionary", logFile)

	fileURL = os.path.join(mainPath, "gui", "GUI.html")

	width = 701
	height = 548

	app.Start(width, height, fileURL)
	app.mainloop()

	cef.Shutdown()

def IsWindows():
	return True

def Is32bit():
	return True

def GetApp():
	global app
	return app

if __name__ == '__main__':
    main()