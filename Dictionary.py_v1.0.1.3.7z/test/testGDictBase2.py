#!/usr/bin/python3
# -*- coding: utf-8 -*-

from GDictBase2 import *
import mp3play

def main():
	curPath = os.getcwd()
	dictZip = os.path.join(curPath, "dict", "Google2.zip")
	audioZip = os.path.join(curPath, "audio", "Google2.zip")
	dictbase = GDictBase2(dictZip, audioZip)

	# dict, audio = dictbase.query_word("abate")
	# New word
	dict, audio = dictbase.query_word("able")

	print(dict)
	playMp3(audio)

def playMp3(mp3):
	try:
		clip = mp3play.load(mp3)
		clip.play()
		time.sleep(min(30, clip.seconds() + 0.3))
		clip.stop()
	except:
		_logging.error("wrong mp3: " + mp3)

if __name__ == '__main__':
	main()