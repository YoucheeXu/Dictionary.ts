#!/usr/bin/python3
#-*- encoding:utf-8 -*-
# -*- coding: utf-8 -*-
#coding=utf-8


class TemplateJson():
	def Open(self, json):
		self.__json = json

	def SetWord(self, word):
		self.__json["query"] = word
		# self.__json["primaries"][0]["terms"][0]["text"] = word
		word_term = {"type": "text", "text": word, "language": "en"}
		self.__json["primaries"][0]["terms"].append(word_term)

	def AddWord(self, symbol, sound = None):
		
		# self.__json["primaries"][0]["terms"][1]["text"] = symbol
		symbol_term = "type": "phonetic", "text": symbol, "language": "en", "labels": 
				[{"text": "KK", "title": "Phonetic" }, {"text": "US", "title": "Phonetic"}]
		if(sound):
			# self.__json["primaries"][0]["terms"][2]["text"] = symbol
			sound_term = {"type": "sound", "text": sound, "language": "und"}
			self.__json["primaries"][0]["terms"].append(symbol_term)

	def AddGroup(self, type, meaning, example):
		# self.__json["primaries"][0]["entries"][0]["labels"][0]["text"] = type
		type_term = {"text": type, "title": "Part-of-Speech"}
		self.__json["primaries"][0]["entries"][0]["labels"].append(type_term)
		'''
		{
			"type": "meaning",
			"terms": [{
					"type": "text",
					"text": "to have something on your body as a piece of clothing, an ornament, etc.",
					"language": "en"
				}, {
					"type": "text",
					"text": "\u7a7f\uff1b\u6234\uff1b\u4f69\u5e26",
					"language": "zh-Hans",
					"labels": [{
							"text": "VN",
							"title": "Grammar"
						}
					]
				}
			],
			"entries": [{
					"type": "example",
					"terms": [{
							"type": "text",
							"text": "Do I have to wear a tie?",
							"language": "en"
						}, {
							"type": "text",
							"text": "\u6211\u5f97\u7cfb\u9886\u5e26\u5417\uff1f",
							"language": "zh-Hans"
						}
					]
				}, {
					"type": "example",
					"terms": [{
							"type": "text",
							"text": "to wear a coat/hat/ring/badge/watch",
							"language": "en"
						}, {
							"type": "text",
							"text": "\u7a7f\u5916\u8863\uff1b\u6234\u5e3d\u5b50\uff0f\u6212\u6307\uff0f\u5fbd\u7ae0\uff0f\u624b\u8868",
							"language": "zh-Hans"
						}
					]
				}, {
					"type": "example",
					"terms": [{
							"type": "text",
							"text": "Was she wearing a seat belt?",
							"language": "en"
						}, {
							"type": "text",
							"text": "\u5979\u7cfb\u7740\u5ea7\u6905\u5b89\u5168\u5e26\u5417\uff1f",
							"language": "zh-Hans"
						}
					]
				}, {
					"type": "example",
					"terms": [{
							"type": "text",
							"text": "He wore glasses.",
							"language": "en"
						}, {
							"type": "text",
							"text": "\u4ed6\u6234\u7740\u773c\u955c\u3002",
							"language": "zh-Hans"
						}
					]
				}, {
					"type": "example",
					"terms": [{
							"type": "text",
							"text": "She always wears black(\\x3d black clothes).",
							"language": "en"
						}, {
							"type": "text",
							"text": "\u5979\u603b\u662f\u7a7f\u9ed1\u8272\u8863\u670d\u3002",
							"language": "zh-Hans"
						}
					]
				}
			]
		}
		'''
		self.__json["primaries"][0]["entries"][0]["entries"][1]