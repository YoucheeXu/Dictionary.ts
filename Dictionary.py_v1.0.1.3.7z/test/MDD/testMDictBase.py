#!/usr/bin/python3
#-*- encoding:utf-8 -*-
# -*- coding: utf-8 -*-
#coding=utf-8

import sys, io

from utils import *
from globalVars import *

from MDictBase import MDictBase

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf8')
# sys.stdout = io.TextIOWrapper(sys.stdout.buffer,encoding='gb18030')

logFile = "MDictBase.log"
gLogger = CreateLogger("MDictBase", logFile)
SetLogger(gLogger)

# dictBase = MDictBase("柯林斯COBUILD高阶英汉双解学习词典.mdx")
dictBase = MDictBase("牛津英语搭配词典.mdd", True)

# word = "good"
# bRet, dict = dictBase.query_word(word)
# gLogger.info("dict = %s" %dict.encode("UTF_8"))
# gLogger.info("dict = %s" %dict.encode('GBK', 'ignore'))
# print("dict = %s" %dict)
# gLogger.info("dict = %s" %dict)

while True:
	word = input("请输入：")
	bRet, dict = dictBase.query_word(word)
	gLogger.info("dict = %s" %dict)