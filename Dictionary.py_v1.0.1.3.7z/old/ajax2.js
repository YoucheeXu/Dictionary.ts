$(document).ready(function () {
	// JQuery code to be added in here.
	//alert('doc ready')
	//norm_search();
	//ajax_search();
	//$('#search_box').focus();
	//google_search();
	//alert('\x26quot;');
});

function google_search(){
	var word = $('#queryword').html();
	//alert(word);
	word = word.replace(/\ /g, "_");

	if ($('#pane1 first').html() == "false") {
		return
	}
	var furl = 'http://www.google.com/dictionary/json?callback=dict_api.callbacks.id100&q=test&sl=en&tl=en&restrict=pr%2Cde&client=te';
	var furl2 = 'http://dictionary.so8848.com/ajax_search/?q=class';
	var curl2 = '../../Dict/Google/' + word.substr(0, 1) + '/' + word + '.json';
	var url = "";
	if(word == "class2"){
		url = furl2;
	}
	else{
		url = curl2;
	}
	//alert(document.documentMode);
	//alert(url);
	$.ajax({
		type:'get',
		url: url,
		datatype: 'json',
		cache: false,
		//async: false,
		success: function(data){
			var obj = eval("(" + data + ")");
			if (obj.ok != false) {
				var obj = eval("(" + obj.info + ")");
				var display = process_primary(obj.primaries)
					$('#pane1 p').html(display)
					//changeSound();
				/*if (display.length > 1000) {
					$('#button_ads').attr('style', '');
				}
				$.get('http://dictionary.so8848.com/suggestion', {
					q : word
				}, function (data) {
					$('.wordtype').first().before(data);
				});*/
				//window.external.OnSaveHtml(display);
			} else {
				/*$.get('http://dictionary.so8848.com/suggestion', {
					q : word
				}, function (data) {
					$('#toggle_example').first().after(data.replace("Similar", "Wow, not in the dict. Check out the suggested"));
					alert("fail: " + data);
				});
				alert("fail: " + word);*/
				google_suggest(word);
			}
		},
		error: function(err){
			$('#pane1 p').html("cannot find " + word + " in google");;
		}
	});
	$('#pane1 first').html("false");
	//$('#first2').html("false")
	//window.external.OnHoverSpeech(word, 1);
}

function google_suggest(word) {
	var curl2 = 'http://dictionary.so8848.com/suggestion/?q=' + word;
	alert(curl2);
	$.ajax({
		type:'get',
		url: curl2,
		datatype: 'json',
		cache: false,
		//async: false,
		success: function(data){
			$('#toggle_example').first().after(data.replace("Similar", "Wow, not in the dict. Check out the suggested"));
			alert("fail: " + data);		
		},
		error: function(err){
			$('#pane1 p').html("cannot find the suggestion of " + word + " in google");
		}
	});
}

function ajax_search() {
	word = $('#queryword').html();
	$.get('http://dictionary.so8848.com/ajax_search', {
		q : word
	}, function (data) {
		var obj = eval("(" + data + ")");
		if (obj.ok != false) {
			var obj = eval("(" + obj.info + ")");
			var display = process_primary(obj.primaries)
				$('#pane1 p').html(display)
				changeSound();
			if (display.length > 1000) {
				$('#button_ads').attr('style', '');
			}
			$.get('http://dictionary.so8848.com/suggestion', {
				q : word
			}, function (data) {
				$('.wordtype').first().before(data);
			});
		} else {
			$.get('http://dictionary.so8848.com/suggestion', {
				q : word
			}, function (data) {
				$('#toggle_example').first().after(data.replace("Similar", "Wow, not in the dict. Check out the suggested"));
			});
		}
	});
}

function norm_search() {
	content = $('#searchresult').html();
	var obj = eval("(" + content + ")");
	word = $('#queryword').html();
	if (obj.ok != false) {
		var obj = eval("(" + obj.info + ")");
		var display = process_primary(obj.primaries)
			$('#content').html(display);
		changeSound();
		if (display.length > 1500) {
			$('#button_ads').attr('style', '');
		}
		$.get('/suggestion', {
			q : word
		}, function (data) {
			$('.wordtype').first().before(data);
		});
	} else {
		$.get('/suggestion', {
			q : word
		}, function (data) {
			$('#toggle_example').first().after(data.replace("Similar", "Wow, not in the dict. Check out the suggested"));
		});
	}
}

$('#collocation').click(function () {
	if ($('#pane2 first').html() != "true") {
		//    alert($('#pane2 first').html())
		return
	}
	word = $('#queryword').html();
	$.get('http://dictionary.so8848.com/ajax_collocation_search', {
		q : word
	}, function (data) {
		$('#pane2 p').html(data);
	});
	$('#pane2 first').html("false");
})

$('#googleenglish').click(function () {
	var word = $('#queryword').html();
	//var curl = getUrl(word);
	var curl = '../../Dict/Google2/' + word.substr(0, 1) + '/' + word + '.json';
	var script = document.createElement('script');
	script.setAttribute('src', curl);
	document.getElementsByTagName('head')[0].appendChild(script);
	script.onload = function () {
		var content = process_primary(dict.primaries);
		var webdef = process_primary(dict.webDefinitions);
		document.getElementById("pane4").innerHTML = content + webdef;
		//document.getElementById("pane4").innerHTML = content;}			
		changeSound();
	}
	//translate(word);
});

$('#wordnet').click(function () {
	var word = $('#queryword').html();
	//alert(word);
	word = word.replace(/\ /g, "_");
	//alert(word);
	var curl = 'http://wordnet-online.freedicts.com/ajax/' + word;
	//curl = "http://gdicts.com/word/meaning/good"
	//alert(curl)

	//$.getJSON( curl, function( data ){
	//  console.log( data.title ); // Logs "jQuery Howto"
	//alert('getJSON');});
	//
	//
	//$.ajax({
	//  type:     "GET",
	//  url:      "https://graph.facebook.com/10150232496792613",
	//  dataType: "jsonp",
	//  success: function(data){
	//      alert(data.id);
	//      $('#pane3 p').html(data.id);
	//  }});
	//

	if ($('#pane3 first').html() != "true") {
		//alert($('#pane2 first').html())
		return
	}

	var request = $.ajax({
			//url: "http://wordnet-online.freedicts.com/ajax/good",
			url : curl,
			type : "GET",
			dataType : "text",
			crossDomain : true
		});

	request.success(function (data) {
		$('#pane3 p').html(data);
	});

	request.done(function (msg) {
		//  $( "#log" ).html( msg );
		//alert('request sucess');

	});

	request.fail(function (xhr, textStatus, ajaxOptions, thrownError) {
		$('#pane3 p').html("cannot find " + word + " in wordnet");
		//alert( "Request failed: " + textStatus );
		//alert(xhr.responseText);
		//alert(xhr.status);
		//alert(thrownError);
	});

	//$.ajax({
	//	type: 'GET',
	//	url: 'http://www.blogoola.com/data/destinations.json',
	//	async: false,
	//	jsonpCallback: 'jsonCallback',
	//	contentType: "application/json",
	//	dataType: 'jsonp',
	//	success: function(data)
	//	{
	//		alert(JSON.stringify(data));
	//		console.log(json);
	//	},
	//	error: function(e)
	//	{
	//	   alert(e.message);
	//	}});
	//

	// Works with $.get too!

	//alert('http://wordnet-online.freedicts.com/ajax/' + word)
	//url = 'http://wordnet-online.freedicts.com/ajax/' + word
	//$.get(url, {q:word}, function(data){
	//    $('#pane3 p').html(data);
	//    alert(url)});
	//
	$('#pane3 first').html("false");
});

$('#likes').click(function () {
	var catid;
	catid = $(this).attr("data-catid");
	//alert("I am an alert box!");
	$.get('/rango/like_category/', {
		category_id : catid
	}, function (data) {
		$('#like_count').html(data);
		$('#likes').hide();
	});
});

$('#suggestion').keyup(function () {
	var query;
	query = $(this).val();
	$.get('/rango/suggest_category/', {
		suggestion : query
	}, function (data) {
		$('#cats').html(data);
	});
});