#!/usr/bin/python3
#-*- encoding:utf-8 -*-
# -*- coding: utf-8 -*-
#coding=utf-8

import os
# import globalVar
from globalVar import *
from ZipArchive import *
import tempfile
import json
from DictBase import *

#################################################
class GDictBase2(DictBase):

	def __init__(self, dictZip, audioZip):

		self.__dictZip = ZipArchive(dictZip)
		self.__audioZip = ZipArchive(audioZip)
		self.__tempDir = tempfile.gettempdir()
		print(self.__tempDir)

	def query_word(self, word):
		# dict = None
		audio = None

		fileName = word + ".json"
		if(self.__dictZip.bFileIn(fileName)):
			dict = self.__dictZip.readFile(fileName)
		else:
			wordFile = os.path.join(self.__tempDir, word + ".json")
			jsonURL = "http://dictionary.so8848.com/ajax_search?q=" + word
			GetApp().download_file(jsonURL, wordFile);

			if os.path.exists(wordFile):
				with open(wordFile, 'rb') as f:
					dict = f.read()
					if(self.__VerifyJson(wordFile, word, dict)):
						# self.__dictZip.addFile(wordFile)
						# addFile(self, fileName, datum)
						# print(dict)
						self.__dictZip.addFile(fileName, dict)

				os.remove(wordFile)

		fileName = word + ".mp3"
		if(self.__audioZip.bFileIn(fileName)):
			audio = self.__audioZip.readFile(fileName)
		else:
			audioFile = os.path.join(self.__tempDir, word + ".mp3")
			audioURL = "https://ssl.gstatic.com/dictionary/static/sounds/oxford/" + word + "--_us_1.mp3"

			GetApp().download_file(audioURL, audioFile);
			if os.path.exists(audioFile):
				with open(audioFile, 'rb') as f:
					audio = f.read()
					self.__audioZip.addFile(fileName, audio)

				os.remove(audioFile)

		return dict, audio

	def __VerifyJson(self, jsonFile, word, dict):
		try:
			# with open(jsonFile, 'rb') as f:
				# dict = f.read()
				# print(dict)

			datum = json.loads(dict, strict = False)

			if(datum["ok"]):
				info = datum["info"]

				regex = re.compile(r'\\(?![/u"])')
				info_fixed = regex.sub(r"\\\\", info)
				datum = json.loads(info_fixed, strict = False)
				if(datum["query"] == word):
					return True

		except Exception as err:
			print(err)

		return False

	def get_wordsLst(self, wdMatchLst, word):

		self.__dictZip.searchFile(word + ".*/.json", wdMatchLst)

		if len(wdMatchLst) >= 1: return True
		else: return False

	def del_word(self, word):
		raise NotImplementedError("don't suppor to del dict of  " + word)
		return False

	def del_audio(self, word):
		raise NotImplementedError("don't suppor to del audio of  " + word)
		return False