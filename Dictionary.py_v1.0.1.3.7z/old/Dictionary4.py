#! /usr/bin/env python
# -*- coding: utf-8 -*-

# Example of embedding CEF Python browser using Tkinter toolkit.
# This example has two widgets: a navigation bar and a browser.
#
# NOTE: This example often crashes on Mac (Python 2.7, Tk 8.5/8.6)
#	   during initial app loading with such message:
#	   "Segmentation fault: 11". Reported as Issue #309.
#
# Tested configurations:
# - Tk 8.5 on Windows/Mac
# - Tk 8.6 on Linux
# - CEF Python v55.3+
#
# Known issue on Linux: When typing url, mouse must be over url
# entry widget otherwise keyboard focus is lost (Issue #255
# and Issue #284).

# fun added:
	# movable
	# after querying word focus on word input box

# To-Do: 
	# miniable
	# record name of wrong json or mp3 file and delete wrong file
	# double click to query word
	# read and write mp3 in compressed file
	# read and write json in compressed file
	# function of other buttons
	# display or hide cmd window on command
	# loud and clear hint when go wrong
	# judge proxy is ok or not

# Bugs fixed: 
	# proxy dosen't work in download_file fun of dictApp

# Bugs:
	# sometimes it display duplicated word in word list panel including paste word in input box

from cefpython3 import cefpython as cef
try:
	import tkinter as tk
except ImportError:
	import Tkinter as tk
import tkMessageBox
import sys
import os
import platform
import logging as _logging
# import urllib.request		# only for python3
import urllib
import urllib2			# only for python2
import mp3play
import time

from ctypes import windll

GWL_EXSTYLE = -20
WS_EX_APPWINDOW = 0x00040000
WS_EX_TOOLWINDOW = 0x00000080

from GDictBase import *
from globalVar import *

# only for python2

# Fix for PyCharm hints warnings
WindowUtils = cef.WindowUtils()

# Platforms
WINDOWS = (platform.system() == "Windows")
LINUX = (platform.system() == "Linux")
MAC = (platform.system() == "Darwin")

# Globals
logger = _logging.getLogger("Dictionary4")

# Constants
# Tk 8.5 doesn't support png images
IMAGE_EXT = ".png" if tk.TkVersion > 8.5 else ".gif"

def main():

	lFile = sys.path[0] + '\\log\\Dictionary4_log.log'
	_logging.basicConfig(level = _logging.DEBUG,
		format = '%(asctime)s %(filename)s[line:%(lineno)d] %(levelname)s:\n%(message)s',
		datefmt = '%Y-%m-%d %H:%M:%S',
		filename = lFile,
		filemode = 'w')
	logger.setLevel(_logging.INFO)
	# logger.setLevel(_logging.NOTSET)
	stream_handler = _logging.StreamHandler()
	formatter = _logging.Formatter("[%(filename)s] %(message)s")
	stream_handler.setFormatter(formatter)
	logger.addHandler(stream_handler)

	logger.info("CEF Python {ver}".format(ver = cef.__version__))
	logger.info("Python {ver} {arch}".format(
			ver = platform.python_version(), arch = platform.architecture()[0]))
	logger.info("Tk {ver}".format(ver = tk.Tcl().eval('info patchlevel')))
	assert cef.__version__ >= "55.3", "CEF Python v55.3+ required to run this"

	# global app
	app = dictApp()
	# globalVar.SetApp(app)
	SetApp(app)

	sys.excepthook = cef.ExceptHook  # To shutdown all CEF processes on error

	# root = tk.Tk()
	# # root.attributes("-alpha",0.0)
	# global window
	# window = MainFrame(root)

	# Tk must be initialized before CEF otherwise fatal error (Issue #306)
	# settings = {
		# "debug": True,
		# "log_severity": cef.LOGSEVERITY_INFO,
		# "log_file": "debug.log",
	# }
	# cef.Initialize(settings = settings)
	cef.Initialize()
	app.mainloop()
	cef.Shutdown()

	logger.info("All are done!")

# def GetApp(): return globalVar.app

def set_appwindow(root):
	hwnd = windll.user32.GetParent(root.winfo_id())
	# style = windll.user32.GetWindowLongPtrW(hwnd, GWL_EXSTYLE)	#Python x64
	style = windll.user32.GetWindowLongW(hwnd, GWL_EXSTYLE)
	style = style & ~WS_EX_TOOLWINDOW
	style = style | WS_EX_APPWINDOW
	# res = windll.user32.SetWindowLongPtrW(hwnd, GWL_EXSTYLE, style)	#Python x64
	res = windll.user32.SetWindowLongW(hwnd, GWL_EXSTYLE, style)
	# re-assert the new window style
	root.wm_withdraw()
	root.after(10, lambda: root.wm_deiconify())

class MainFrame(tk.Frame):

	def __init__(self, root):
		self.browser_frame = None
		self.navigation_bar = None

		width = 701
		height = 551

		screenwidth = root.winfo_screenwidth()
		screenheight = root.winfo_screenheight()  
		size = '%dx%d+%d+%d' % (width, height, (screenwidth - width)/2, (screenheight - height)/2)

		# print("size: ", size)

		# Root
		root.geometry(size)
		root.overrideredirect(True)	 #no title

		root.after(10, lambda: set_appwindow(root))

		tk.Grid.rowconfigure(root, 0, weight = 1)
		tk.Grid.columnconfigure(root, 0, weight = 1)

		# MainFrame
		tk.Frame.__init__(self, root)
		self.master.title("Dictionary")
		self.master.protocol("WM_DELETE_WINDOW", self.on_close)
		self.master.bind("<Configure>", self.on_root_configure)
		self.setup_icon()
		self.bind("<Configure>", self.on_configure)
		self.bind("<FocusIn>", self.on_focus_in)
		self.bind("<FocusOut>", self.on_focus_out)

		# # NavigationBar
		# self.navigation_bar = NavigationBar(self)
		# self.navigation_bar.grid(row=0, column=0,
		#						  sticky=(tk.N + tk.S + tk.E + tk.W))
		# tk.Grid.rowconfigure(self, 0, weight=0)
		# tk.Grid.columnconfigure(self, 0, weight=0)

		# BrowserFrame
		self.browser_frame = BrowserFrame(self, self.navigation_bar)
		self.browser_frame.grid(row = 1, column = 0,
								 sticky = (tk.N + tk.S + tk.E + tk.W))
		tk.Grid.rowconfigure(self, 1, weight = 1)
		tk.Grid.columnconfigure(self, 0, weight = 1)

		# Pack MainFrame
		self.pack(fill = tk.BOTH, expand = tk.YES)

		# self.bind("<Map>", self.frame_mapped)

	def on_root_configure(self, _):
		logger.debug("MainFrame.on_root_configure")
		if self.browser_frame:
			self.browser_frame.on_root_configure()

	def on_configure(self, event):
		logger.debug("MainFrame.on_configure")
		if self.browser_frame:
			width = event.width
			height = event.height
			if self.navigation_bar:
				height = height - self.navigation_bar.winfo_height()
			self.browser_frame.on_mainframe_configure(width, height)

	def on_focus_in(self, _):
		logger.debug("MainFrame.on_focus_in")

	def on_focus_out(self, _):
		logger.debug("MainFrame.on_focus_out")

	def on_close(self):
		print("on_close")
		if self.browser_frame:
			self.browser_frame.on_root_close()
		self.master.destroy()

	def get_browser(self):
		if self.browser_frame:
			return self.browser_frame.browser
		return None

	def get_browser_frame(self):
		if self.browser_frame:
			return self.browser_frame
		return None

	def min(self):
		return
		# self.master.wm_withdraw()
		# self.master.wm_iconify()
		self.master.update_idletasks()
		self.master.overrideredirect(False)
		#root.state('withdrawn')
		self.master.state('iconic')

	def restore(self):
		self.master.wm_deiconify()

	def frame_mapped(self, e):
		self.master.update_idletasks()
		self.master.overrideredirect(True)
		self.master.after(1, lambda: set_appwindow(self.master))
		self.master.state('normal')

	def setup_icon(self):
		# resources = os.path.join(os.path.dirname(__file__), "resources")
		resources = os.path.join(os.path.dirname(__file__), "data")
		icon_path = os.path.join(resources, "main" + IMAGE_EXT)
		if os.path.exists(icon_path):
			self.icon = tk.PhotoImage(file = icon_path)
			# noinspection PyProtectedMember
			self.master.call("wm", "iconphoto", self.master._w, self.icon)

class BrowserFrame(tk.Frame):

	def __init__(self, master, navigation_bar = None):
		self.navigation_bar = navigation_bar
		self.closing = False
		self.browser = None
		tk.Frame.__init__(self, master)
		self.bind("<FocusIn>", self.on_focus_in)
		self.bind("<FocusOut>", self.on_focus_out)
		self.bind("<Configure>", self.on_configure)
		self.focus_set()

	def embed_browser(self):
		window_info = cef.WindowInfo()
		rect = [0, 0, self.winfo_width(), self.winfo_height()]
		window_info.SetAsChild(self.get_window_handle(), rect)
		#self.browser = cef.CreateBrowserSync(window_info, url="https://bing.com/")

		settings = {
			"file_access_from_file_urls_allowed": True,
		}
		self.browser = cef.CreateBrowserSync(window_info, url = "file:///Data/GUI_3.html", settings = settings)
		assert self.browser

		# global dictBrowser
		# dictBrowser = self.browser
		# globalVar.GetApp().set_browser(self.browser)

		# js
		js = cef.JavascriptBindings()
		# external = External()
		# js.SetObject('external', external)
		# js.SetObject('external', globalVar.GetApp())
		js.SetObject('external', GetApp())
		self.browser.SetJavascriptBindings(js)

		self.browser.SetClientHandler(LoadHandler(self))
		self.browser.SetClientHandler(FocusHandler(self))
		self.message_loop_work()

	def get_window_handle(self):
		if self.winfo_id() > 0:
			return self.winfo_id()
		elif MAC:
			# On Mac window id is an invalid negative value (Issue #308).
			# This is kind of a dirty hack to get window handle using
			# PyObjC package. If you change structure of windows then you
			# need to do modifications here as well.
			# noinspection PyUnresolvedReferences
			from AppKit import NSApp
			# noinspection PyUnresolvedReferences
			import objc
			# Sometimes there is more than one window, when application
			# didn't close cleanly last time Python displays an NSAlert
			# window asking whether to Reopen that window.
			# noinspection PyUnresolvedReferences
			return objc.pyobjc_id(NSApp.windows()[-1].contentView())
		else:
			raise Exception("Couldn't obtain window handle")

	def message_loop_work(self):
		cef.MessageLoopWork()
		self.after(10, self.message_loop_work)

	def on_configure(self, _):
		if not self.browser:
			self.embed_browser()

	def on_root_configure(self):
		# Root <Configure> event will be called when top window is moved
		if self.browser:
			self.browser.NotifyMoveOrResizeStarted()

	def on_mainframe_configure(self, width, height):
		if self.browser:
			if WINDOWS:
				WindowUtils.OnSize(self.get_window_handle(), 0, 0, 0)
			elif LINUX:
				self.browser.SetBounds(0, 0, width, height)
			self.browser.NotifyMoveOrResizeStarted()

	def on_focus_in(self, _):
		logger.debug("BrowserFrame.on_focus_in")
		if self.browser:
			self.browser.SetFocus(True)

	def on_focus_out(self, _):
		logger.debug("BrowserFrame.on_focus_out")
		if self.browser:
			self.browser.SetFocus(False)

	def on_root_close(self):
		if self.browser:
			self.browser.CloseBrowser(True)
			self.clear_browser_references()
		self.destroy()

	def clear_browser_references(self):
		# Clear browser references that you keep anywhere in your
		# code. All references must be cleared for CEF to shutdown cleanly.
		self.browser = None

class LoadHandler(object):

	def __init__(self, browser_frame):
		self.browser_frame = browser_frame

	def OnLoadStart(self, browser, **_):
		if self.browser_frame.master.navigation_bar:
			self.browser_frame.master.navigation_bar.set_url(browser.GetUrl())

class FocusHandler(object):

	def __init__(self, browser_frame):
		self.browser_frame = browser_frame

	def OnTakeFocus(self, next_component, **_):
		logger.debug("FocusHandler.OnTakeFocus, next = {next}"
					 .format(next=next_component))

	def OnSetFocus(self, source, **_):
		logger.debug("FocusHandler.OnSetFocus, source = {source}"
					 .format(source = source))
		return False

	def OnGotFocus(self, **_):
		"""Fix CEF focus issues (#255). Call browser frame's focus_set
		   to get rid of type cursor in url entry widget."""
		logger.debug("FocusHandler.OnGotFocus")
		# self.browser_frame.focus_set()

class dictApp():

	def __init__(self):

		self.__dictbase = GDictBase()
		dictPath = sys.path[0] + "\\dict\\"
		audioPath = sys.path[0] + "\\audio\\"
		self.__dictbase.set_path(dictPath, audioPath)

		self.enableMove = False

		# root.attributes("-alpha",0.0)

		self.__root = tk.Tk()
		self.__window = MainFrame(self.__root)

	def get_browser(self):
		return self.__window.get_browser()

	def get_curDB(self):
		return self.__dictbase

	def mainloop(self):
		self.__window.mainloop()

	def play_MP3(self, mp3):

		#2.创建合成器对象，解析出最初的几帧音频数据
		import pymedia.muxer as muxer
		dm = muxer.Demuxer('mp3')
		frames = dm.parse(mp3)
		logging.debug(len(frames))

		#3.根据解析出来的 Mp3 编码信息，创建解码器对象
		import pymedia.audio.acodec as acodec
		dec = acodec.Decoder(dm.streams[0])
		#像下面这样也行
		#params = {'id': acodec.getCodecID('mp3'), 'bitrate': 128000, 'sample_rate': 44100, 'ext': 'mp3', 'channels': 2}
		#dec= acodec.Decoder(params)

		#4.解码第一帧音频数据
		frame = frames[0]
		#音频数据在 frame 数组的第二个元素中
		#r = dec.decode(frame[1])
		r = dec.decode(mp3)
		logging.debug("sample_rate:%s, channels:%s" %(r.sample_rate,r.channels))
		#注意：这一步可以直接解码 r = dec.decode(data)，而不用读出第一帧音频数据
		#但是开始会有一下噪音，如果是网络流纯音频数据，不包含标签信息，则不会出现杂音

		#5.创建音频输出对象
		import pymedia.audio.sound as sound
		snd = sound.Output(r.sample_rate, r.channels, sound.AFMT_S16_LE)

		#6.播放
		if r: snd.play(r.data)

		# #7.继续读取、解码、播放
		# while True:
			# data = f.read(512)
			# if len(data)>0:
				# r = dec.decode(data)
				# if r: snd.play(r.data)
			# else:
				# break

		#8.延时，直到播放完毕
		import time
		while snd.isPlaying(): time.sleep(.5)
		return True

	def dwf_callbackfunc(self, blocknum, blocksize, totalsize):
		'''回调函数
		@blocknum: 已经下载的数据块
		@blocksize: 数据块的大小
		@totalsize: 远程文件的大小
		'''
		percent = 100.0 * blocknum * blocksize / totalsize
		if percent > 100:
			percent = 100
		print("%.2f%%"% percent)

	def download_file(self, url, local):
		try:
			print("Going to download %s" %url)
			proxy = 'http://127.0.0.1:8087'
			# proxy = '127.0.0.1:8087'
			proxy_handler = urllib2.ProxyHandler({'http': proxy})
			# opener = urllib2.build_opener(proxy_handler, urllib2.ProxyHandler)
			opener = urllib2.build_opener(proxy_handler)

			# urllib2.install_opener(opener)
			# urllib.urlretrieve(url, local, self.dwf_callbackfunc)

			# proxies = {'http': 'http://127.0.0.1:8087'}
			# opener = urllib.FancyURLopener(proxies)
			# opener.retrieve(url, local, self.dwf_callbackfunc)

			r = opener.open(url)
			file = open(local, 'wb')
			file.write(r.read())
			file.close()

		except Exception, ex:
			logger.error("fail to get %s" %url)
			print(Exception, ": ", ex)
		return True

	def OnButtonClicked(self, id):
		if id == "btn_close": tk.Tk().quit()
		elif id == "btn_min": self.__window.min()
		else: print(id)

	def startMove(self, x, y):
		self.enableMove = True
		# self.x = event.x
		self.x = x
		# self.y = event.y
		self.y = y

		self.root_x = self.__root.winfo_rootx()
		self.root_y = self.__root.winfo_rooty()

		# print("self.x: ", self.x, "self.y: ", self.y)
		# print("self.root_x: ", self.root_x, "self.root_y: ", self.root_y)

	def stopMove(self, x, y):
		self.enableMove = False
		self.x = None
		self.y = None

	def moving(self, x, y):
		if(not self.enableMove): return

		newX = self.root_x + x - self.x 
		newY = self.root_y + y - self.y

		self.__root.geometry("+%s+%s" %(newX, newY))

	def QueryWord(self, word):
		# globalVar.GetApp().get_curDB().query_word(word)
		self.get_curDB().query_word(word)
		# Execute Javascript function
		self.__window.get_browser().ExecuteFunction("google_search")
		self.speech_word(word, True);

	def speech_word(self, word, isUs):
		# print("going to speech %s" %word)
		mp3 = sys.path[0] + "\\Audio\\Google\\" + word + ".mp3"
		if os.path.isfile(mp3) == False:
			logger.error("The is no mp3: " + mp3)
			tkMessageBox.showerror(word, "The is no mp3: " + mp3)
			return "break"

		try:
			clip = mp3play.load(mp3)
			# print(mp3)
			# clip = mp3play.AudioClip(mp3)
			clip.play()
			time.sleep(min(30, clip.milliseconds()/1000 + 1))
			clip.stop()
		except Exception, ex:
			logger.error("wrong mp3: " + mp3)
			tkMessageBox.showerror(word, "wrong mp3: " + mp3)
			print(Exception, ": ", ex)

	def OnTextChanged(self, word):
		wdsLst = []
		# ret = globalVar.GetApp().get_curDB().get_wordslst(wdsLst, word)
		ret = self.get_curDB().get_wordslst(wdsLst, word)
		if (not ret): return False

		for wd in wdsLst:
			self.__window.get_browser().ExecuteFunction("append_words_list", wd)
			# print("found word: %s" %wd)

	def wrongJson(self, word): 
		ret = self.__dictbase.del_word(word)
		if ret == True: 
			# tkMessageBox.showinfo("Info", "Success to delete " + word)
			print("Success to delete " + word)

if __name__ == '__main__':
	main()
