﻿
var timer01;
var timer02;

/* 带链接文字鼠标点击时去掉虚线 */
$(function(){
	$('a,input[type="button"],input[type="radio"],input[type="submit"]').bind('focus',function(){
		if(this.blur){
			this.blur();	
		};																	   
	});	   
});

/* 点击出现提示框 */
$(function(){
	
	$(".open_vip").click(function(){
		$(".tips02").fadeIn(100);
		timer02 = setTimeout("hide02()",2000);
	})
	$(".tips02").mouseover(function(){
		clearTimeout(timer02);
	})
	$(".tips02").mouseout(function(){
		timer02 = setTimeout("hide02()",2000);
	})
	
	$(".upgrade_dict").click(function(){
		$(".tips01").fadeIn(100);
		timer01 = setTimeout("hide01()",2000);
	})
	$(".tips01").mouseover(function(){
		clearTimeout(timer01);
	})
	$(".tips01").mouseout(function(){
		timer01 = setTimeout("hide01()",2000);
	})
	
})
function change_state() {
	clearTimeout(timer01);
	clearTimeout(timer02);
	$(".tips01").hide();
	$(".tips02").hide();
}
function hide01() {
		$(".tips01").fadeOut(200);
	}
function hide02() {
		$(".tips02").fadeOut(200);
	}
	
/* 按钮三态 */

$(function(){
	$(".btn_renew").mouseover(function(){
		$(this).addClass("btn_renew_hover");							  
	});
	$(".btn_renew").mousedown(function(){
		$(this).addClass("btn_renew_down");							  
	});
	$(".btn_renew").mouseout(function(){
		$(this).removeClass("btn_renew_down");							  
	});
	$(".btn_renew").mouseout(function(){
		$(this).removeClass("btn_renew_hover");							  
	});
})

$(function(){
	$(".btn_open").mouseover(function(){
		$(this).addClass("btn_open_hover");							  
	});
	$(".btn_open").mousedown(function(){
		$(this).addClass("btn_open_down");							  
	});
	$(".btn_open").mouseout(function(){
		$(this).removeClass("btn_open_down");							  
	});
	$(".btn_open").mouseout(function(){
		$(this).removeClass("btn_open_hover");							  
	});
})