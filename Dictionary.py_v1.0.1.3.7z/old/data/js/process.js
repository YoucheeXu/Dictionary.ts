﻿INDEX = 1

function process_primary(dict_primary){
    var primary = dict_primary;
    var xml = "";
    if(primary instanceof Array){
        for(var i in primary){
            var data = primary[i];
            xml += process_primary(data);
        }
    }
    else if(typeof(primary) == "object"){
        var hasChild = false;
        var hasType = false;
        if(primary.type != undefined){
            hasType = true;
            if(primary.type == "container"){
            	xml += '<div class = "wordtype">' + primary.labels[0].text + ':</div>';
            	xml += '<div class = "'+ primary.type + '1">' + process_terms(primary.terms, primary.type);
            }else{
				if(primary.labels != undefined){
					xml += '<div class = "'+ primary.type + '">' + '<div class="labels">' + primary.labels[0].text + '</div>' + process_terms(primary.terms, primary.type);				
				}				
				else{
					xml += '<div class = "'+ primary.type + '">' + process_terms(primary.terms, primary.type);
				}
			}
            if(primary.entries != undefined){
                xml += process_primary(primary.entries);
            }
            xml += "</div>";
        }
    }
    else if(typeof(primary) == "string"){
		xml += process_primary( eval("("+primary+")") );
	}
    return xml;
}              

function process_terms(dict_terms, type){
	var terms = dict_terms
	var xml = ""
	if(terms instanceof Array){
        for(var i in terms){
            var data = terms[i];
            xml += process_terms(data,type);
        }
    }
    else if(typeof(terms) == "object"){
        var hasType = false;
        if(terms.type != undefined){
            hasType = true;
            if(terms.type !="text" || type == "headword" || type =="related"){
				if(terms.type == "sound")
				{
					/*xml += '<div class="'+ terms.type + '">';
					//xml += terms.text +"</div>";
					xml += '<embed type="application/x-shockwave-flash" src="SpeakerApp16.swf" width="20" height="20" id="movie28564" name="movie28564" bgcolor="#000000" quality="high" flashvars="sound_name='+ terms.text + '"wmode="transparent">'
					xml += "</div>"*/
					xml += getSound(terms.text);
					// alert(xml);
				}
				else{
					xml += '<div class = "'+ terms.type + '">';
					xml += terms.text +"</div>";					
				}
            }
            else{
            	xml += terms.text;
            }
        }
    }
    return xml
}

function process_term(dict_terms){
	var terms = dict_terms

    for(var i in terms){
    	var data = terms[i];
        xml += (data.text);
    }
    return xml
}

function getChange(){
	var url = window.location.href;
	var index = url.search("word=");
	if(index != -1){
		word = url.substring(index + 5)
		var script = document.createElement('script');
		script.setAttribute('src', getUrl(word));
		document.getElementsByTagName('head')[0].appendChild(script); 
	}
}

function changeSound(){
	sounds = document.getElementsByClassName("sound");
	//sounds = document.getElementsByName("sound");
	for (i in sounds){
		sounds[i].innerHTML = getSound(escape(sounds[i].innerHTML));
	}
}

function getUrl(word){
	var url = "http://www.google.com/dictionary/json?callback=getJson&q="+word+"&sl=en&tl=zh-cn&restrict=pr,de&client=te"
	return url
}

/*function getSound(url){
	// sound = '<object data="http://www.google.com/dictionary/flash/SpeakerApp16.swf" type="application/x-shockwave-flash" width=" 16" height="16" id="pronunciation">\
	// sound = '<object data="SpeakerApp16.swf" type="application/x-shockwave-flash" width=" 16" height="16" id="pronunciation">\
			// <param name="movie" value="Speaker.swf">\
			// <param name="flashvars" value="sound_name='+ url+'">\
	// </object>';
	// sound = '<embed type="application/x-shockwave-flash" src="SpeakerApp16.swf" width="20" height="20" id="movie28564" name="movie28564" bgcolor="#000000" quality="high" flashvars="sound_name=../../Audio/Google/class.mp3" wmode="transparent">';
	sound = '<embed type="application/x-shockwave-flash" src="SpeakerApp16.swf" width="20" height="20" id="movie28564" name="movie28564" bgcolor="#000000" quality="high" flashvars="sound_name='+ url + '"wmode="transparent">';
	return sound;
}*/

function getFlashObject_top(movieName) {
    if (window.document[movieName]) {
        return window.document[movieName];
    }   
    if (navigator.appName.indexOf("Microsoft Internet")==-1) {
        if (document.embeds && document.embeds[movieName])
          return document.embeds[movieName];
    } else  {
        return document.getElementById(movieName);
    }   
}

var timer = null;
function player_callback(c) {
    // var asound = getFlashObject_top("asound_top");
    // if(asound){
        // asound.SetVariable("f",c);
        // asound.GotoFrame(1);
		// //alert(c);
    // }
	// else alert("can't get asound_top!");
    return false;

}
function asplay(c){
    clearTimeout(timer);
    var mp3_1 = "player_callback('" + c + "')";
    timer = setTimeout(mp3_1, 100);
	//alert("haha!");
}

/*function getSound(url){
	//sound = '<a href = "javascript:;" class = "laba" onmouseover = "asplay(\'' + url +'\');" onmouseout = "clearTimeout(timer);" onclick = "asplay(\'' + url + '\');" ></a>'
	sound = '<div class="sound"><a href="javascript:;" class="laba" onmouseover="asplay(\'' + url +'\');" onmouseout ="clearTimeout(timer);" onclick="asplay(\'' + url + '\');" ></a></div>'
	return sound;
}*/

function getSound(url){
	sound = '<div class = "sound"><a href = "' + url + '" class = "laba" onmouseover = "asplay(\'' + url +'\');" onmouseout = "clearTimeout(timer);"></a></div>'
	//sound = '<div class="sound"><a href="javascript:;" class="laba" onmouseover="asplay(\'' + url +'\');" onmouseout ="clearTimeout(timer);" onclick = "response.setHeader("Content-disposition", "attachment;filename = \'"' + url + '\');" ></a></div>'
	
	return sound;
}

function formSubmit(){
	var value = document.getElementById("form_value");
	var word = value.value
	var script = document.createElement('script');
	script.setAttribute('src', getUrl(word));
	document.getElementsByTagName('head')[0].appendChild(script); 
	//alert(getUrl(word))
	script.onload = function() {
		var content = process_primary(dict.primaries);
		var webdef = process_primary(dict.webDefinitions);
		document.getElementById("content").innerHTML = content;
		changeSound();
		document.getElementById("webdef").innerHTML = webdef;
	}
	translate(word);
}

var search = function(searchbox){
	if(searchbox == undefined){searchbox="searchbox";}
	if(lastword == word){return;}
	var word=$(searchbox).value.trim().toLowerCase();
	if(word.match(/\w+/) == null){
		$(searchbox).value = "";
		$(searchbox).focus();
		//alert("请输入要查询的英文单词");return false;
	}
	if(word.length==0){$(searchbox).focus();return false;}
	
	window.location.href = g_word_prefix+"/"+word;
	return false;
}

function enter(){
	if (event.keyCode == 13)    {
		formSubmit();
	}
}

function translate(word){
	var url = "https://www.googleapis.com/language/translate/v2?key=AIzaSyCTAervvQn5LZBCMgMcwHi4y5K7js71hU0&source=en&target=zh&callback=translateText&q="+word;
	var script = document.createElement('script');
	script.setAttribute('src',url);
	document.getElementsByTagName('head')[0].appendChild(script); 
	script.onload = function() {
		document.getElementById("translate").innerHTML = tl;
	}	
}

tl = null;
function translateText(response) {
	tl =  response.data.translations[0].translatedText;
}