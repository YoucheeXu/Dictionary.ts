Win32xx 840

bug:
1��menu display not normal
2��alert will not popup in other tabs except "google" tab
3��when click other tabs words_list_box don't disapear except "google" tab

To-Do:
# orangize code about dictdlg
# change the method to transfer message to dictdlg
    dictdlg register msg in webbrowser
    webbrowser tranfer msg to dictdlg
# danamic add or remove tab
# add tab to add tab
# list words in list word box or quick list box
# move dictapp with mouse
# complete recite word app
# auto record wrong word or missing word
# support mdict
# add plugin function about reading new dict
# add "X" on tab
# recover "TOP"
# download file by javascript through agent
# read dict in zip format
    http://gildas-lormeau.github.io/zip.js/
# reroute console msg to logout

�����Ӧ�ʵ��������ܼ�ֱ�ӷ��ʵ�ַhttp://xtk.azurewebsites.net/BingDictService.aspx?Word=x  x�Ǵ�����Ĵ������json

pip install configparser
easy_install mp3play-0.1.15-py2.5.egg

pip install cefpython3==57.1

monotonically