# Readme

## Windows
### Dictionary

i only test dictionary with python3 on Windows 10

```shell
pip3 install configparser
pip3 install cefpython3==66.0
```

### ReciteWords
i fix a bug of [mp3play](https://pypi.org/project/mp3play/) which cause it can't run with python3

i only test ReciteWords with python3 on Windows 10

```shell
pip3 install configparser
```

## Linux
### Dictionary

i only test with python3 on Ubuntu 18.04

```bash
pip3 install configparser
pip3 install cefpython3==66.0
```

### ReciteWords

i only test with python3 on Ubuntu 18.04

ReciteWords need mplayer to pronounce word

```bash
pip3 install configparser
```

## Mac OS
i don't have any mac device, so unkonwn to everything