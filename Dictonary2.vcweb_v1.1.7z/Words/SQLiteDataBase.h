// SQLiteDataBase.h

// tWord tSymbol tMeaning tSentences nLevel nFamiliar lLastDate

class CWord{
public:
	CWord(){}
	~CWord(){}
	
private:
	union
	{
		struct
		{
			tString m_tWord;
			tString m_tSymbol;
			tString m_tMeaning;
			tString m_tSentences;
			tString m_tLevel;
			tString m_tFamiliar;
			tString m_tLastDate;
		};
		tString m_tWords[7];
	};
	
public:
	// subscript operator for const objects returns value
	inline tString operator [] (int i) const
	{
		assert(1 <= i <= 7);
		switch (i)
		{
		case 1:
			return m_tWord;
		case 2:
			return m_tSymbol;
		case 3:
			return m_tMeaning;
		case 4:
			return m_tSentences;
		case 5:
			return m_tLevel;
		case 6:
			return m_tFamiliar;
		case 7:
			return m_tLastDate;
		}
	}
	// subscript operator for non-const objects returns modifiable value
	inline tString& operator [] (int i)
	{
		assert(1 <= i <= 7);
		switch (i)
		{
		case 1:
			return m_tWord;
		case 2:
			return m_tSymbol;
		case 3:
			return m_tMeaning;
		case 4:
			return m_tSentences;
		case 5:
			return m_tLevel;
		case 6:
			return m_tFamiliar;
		case 7:
			return m_tLastDate;
		}
	}
	
	tString GetWord const(){return m_tWord;}
	tString GetWord const(){return m_tSymbol;}
	tString GetWord const(){return m_tMeaning;}
	tString GetWord const(){return m_tSentences;}
	int GetWord const(){return _ttoi(m_tLevel.c_str());}
	int GetWord const(){return _ttoi(m_tFamiliar.c_str());}
	long GetWord const(){return _ttol(m_tLastDate.c_str());}
}

typedef vector<CWord*> WordArray;

class CSQLiteDataBase {
public:
	CSQLiteDataBase();
	~CSQLiteDataBase();
	
private:	
    sqlite3* m_pDataBase;
    tString mWord;
    tString mSymbol;
    tString mDefinition;
    tString mSentence;
    bool mMark;

public:	
	bool LoadDict(const tString filename);

	void UnloadDict();

    bool GetContent(const tString wd, CWord &word);
	
	bool GetSimilarWordList(const tString word, WordArray& findWords);
	bool GetWordListByDate(long afterDate, WordArray& findWords);
	bool GetWordListByFamiliar(int lessFamiliar, WordArray& findWords);
	bool GetStrangeWordList(long afterDate, int lessFamiliar, WordArray& findWords);
	
	bool UpdateLevel(const tString word, int level);
	bool UpdateFamiliar(const tString word, int familiar);
	bool UpdateLastDate(const tString word, int lastDate);
	
	bool InsertWord(const CWord* pWord);
	bool DeleteWord(const tString word);
	
private:
	bool CreateTabel(char letter);
	bool GetWordList(const tString sql, WordArray& findWords);
	bool UpdateData(const tString word, const tString item, const tString value);
	bool ExecSql(const tString sql);
}