﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmWords
    Inherits System.Windows.Forms.Form

    'Form 重写 Dispose，以清理组件列表。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows 窗体设计器所必需的
    Private components As System.ComponentModel.IContainer

    '注意:  以下过程是 Windows 窗体设计器所必需的
    '可以使用 Windows 窗体设计器修改它。  
    '不要使用代码编辑器修改它。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmWords))
        Me.TxtWord = New System.Windows.Forms.TextBox()
        Me.btnPronounce = New System.Windows.Forms.Button()
        Me.BtnTip = New System.Windows.Forms.Button()
        Me.BtnFinish = New System.Windows.Forms.Button()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.WordPlayer = New AxWMPLib.AxWindowsMediaPlayer()
        Me.BtnForget = New System.Windows.Forms.Button()
        Me.BtnFamiliar = New System.Windows.Forms.Button()
        Me.BtnNext = New System.Windows.Forms.Button()
        Me.labWord = New System.Windows.Forms.Label()
        Me.rtxDefinition = New System.Windows.Forms.RichTextBox()
        Me.labSymbol = New System.Windows.Forms.Label()
        CType(Me.WordPlayer, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TxtWord
        '
        Me.TxtWord.Location = New System.Drawing.Point(565, 101)
        Me.TxtWord.Name = "TxtWord"
        Me.TxtWord.Size = New System.Drawing.Size(195, 20)
        Me.TxtWord.TabIndex = 0
        '
        'btnPronounce
        '
        Me.btnPronounce.Location = New System.Drawing.Point(445, 146)
        Me.btnPronounce.Name = "btnPronounce"
        Me.btnPronounce.Size = New System.Drawing.Size(32, 24)
        Me.btnPronounce.TabIndex = 1
        Me.btnPronounce.Text = "Pronounce"
        Me.btnPronounce.UseVisualStyleBackColor = True
        '
        'BtnTip
        '
        Me.BtnTip.Location = New System.Drawing.Point(565, 143)
        Me.BtnTip.Name = "BtnTip"
        Me.BtnTip.Size = New System.Drawing.Size(52, 27)
        Me.BtnTip.TabIndex = 2
        Me.BtnTip.Text = "Tip"
        Me.BtnTip.UseVisualStyleBackColor = True
        '
        'BtnFinish
        '
        Me.BtnFinish.Location = New System.Drawing.Point(708, 143)
        Me.BtnFinish.Name = "BtnFinish"
        Me.BtnFinish.Size = New System.Drawing.Size(52, 27)
        Me.BtnFinish.TabIndex = 3
        Me.BtnFinish.Text = "Finish"
        Me.BtnFinish.UseVisualStyleBackColor = True
        '
        'WordPlayer
        '
        Me.WordPlayer.Enabled = True
        Me.WordPlayer.Location = New System.Drawing.Point(608, 49)
        Me.WordPlayer.Name = "WordPlayer"
        Me.WordPlayer.OcxState = CType(resources.GetObject("WordPlayer.OcxState"), System.Windows.Forms.AxHost.State)
        Me.WordPlayer.Size = New System.Drawing.Size(75, 23)
        Me.WordPlayer.TabIndex = 5
        '
        'BtnForget
        '
        Me.BtnForget.Location = New System.Drawing.Point(233, 253)
        Me.BtnForget.Name = "BtnForget"
        Me.BtnForget.Size = New System.Drawing.Size(52, 27)
        Me.BtnForget.TabIndex = 6
        Me.BtnForget.Text = "Forget"
        Me.BtnForget.UseVisualStyleBackColor = True
        '
        'BtnFamiliar
        '
        Me.BtnFamiliar.Location = New System.Drawing.Point(384, 253)
        Me.BtnFamiliar.Name = "BtnFamiliar"
        Me.BtnFamiliar.Size = New System.Drawing.Size(52, 27)
        Me.BtnFamiliar.TabIndex = 7
        Me.BtnFamiliar.Text = "Familiar"
        Me.BtnFamiliar.UseVisualStyleBackColor = True
        '
        'BtnNext
        '
        Me.BtnNext.Location = New System.Drawing.Point(312, 253)
        Me.BtnNext.Name = "BtnNext"
        Me.BtnNext.Size = New System.Drawing.Size(52, 27)
        Me.BtnNext.TabIndex = 8
        Me.BtnNext.Text = "Next"
        Me.BtnNext.UseVisualStyleBackColor = True
        '
        'labWord
        '
        Me.labWord.AutoSize = True
        Me.labWord.Enabled = False
        Me.labWord.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.labWord.Location = New System.Drawing.Point(227, 72)
        Me.labWord.Name = "labWord"
        Me.labWord.Size = New System.Drawing.Size(78, 31)
        Me.labWord.TabIndex = 9
        Me.labWord.Text = "Word"
        '
        'rtxDefinition
        '
        Me.rtxDefinition.Location = New System.Drawing.Point(233, 122)
        Me.rtxDefinition.Name = "rtxDefinition"
        Me.rtxDefinition.Size = New System.Drawing.Size(193, 81)
        Me.rtxDefinition.TabIndex = 10
        Me.rtxDefinition.Text = ""
        '
        'labSymbol
        '
        Me.labSymbol.AutoSize = True
        Me.labSymbol.Enabled = False
        Me.labSymbol.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.labSymbol.Location = New System.Drawing.Point(353, 96)
        Me.labSymbol.Name = "labSymbol"
        Me.labSymbol.Size = New System.Drawing.Size(54, 16)
        Me.labSymbol.TabIndex = 11
        Me.labSymbol.Text = "Symbol"
        '
        'frmWords
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Menu
        Me.ClientSize = New System.Drawing.Size(829, 374)
        Me.Controls.Add(Me.labSymbol)
        Me.Controls.Add(Me.rtxDefinition)
        Me.Controls.Add(Me.labWord)
        Me.Controls.Add(Me.BtnNext)
        Me.Controls.Add(Me.BtnFamiliar)
        Me.Controls.Add(Me.BtnForget)
        Me.Controls.Add(Me.WordPlayer)
        Me.Controls.Add(Me.BtnFinish)
        Me.Controls.Add(Me.BtnTip)
        Me.Controls.Add(Me.btnPronounce)
        Me.Controls.Add(Me.TxtWord)
        Me.KeyPreview = True
        Me.Name = "frmWords"
        Me.Text = "Words"
        CType(Me.WordPlayer, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TxtWord As System.Windows.Forms.TextBox
    Friend WithEvents btnPronounce As System.Windows.Forms.Button
    Friend WithEvents BtnTip As System.Windows.Forms.Button
    Friend WithEvents BtnFinish As System.Windows.Forms.Button
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents WordPlayer As AxWMPLib.AxWindowsMediaPlayer
    Friend WithEvents BtnForget As System.Windows.Forms.Button
    Friend WithEvents BtnFamiliar As System.Windows.Forms.Button
    Friend WithEvents BtnNext As System.Windows.Forms.Button
    Friend WithEvents labWord As System.Windows.Forms.Label
    Friend WithEvents rtxDefinition As System.Windows.Forms.RichTextBox
    Friend WithEvents labSymbol As System.Windows.Forms.Label

End Class
