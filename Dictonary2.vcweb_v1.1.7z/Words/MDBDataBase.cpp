﻿//MDBDataBase.cpp
#include "MDBDataBase.h"

CMDBDataBase::CMDBDataBase() {
	m_connn = New OleDbConnection
    m_strDictName = ""
}

CMDBDataBase::~CMDBDataBase() {
	
}

bool CMDBDataBase::LoadDict(tString name){
        m_strDictName = Application.StartupPath + "\Data\" + name
        m_connn.ConnectionString = "Provider = Microsoft.Jet.OLEDB.4.0; Data Source =" + m_strDictName
        Try
            m_connn.Open()
        Catch ex As Exception
            MessageBox.Show(ex.ToString)
        End Try
        Return True
    End Function
}

void CMDBDataBase::UnloadDict() {
    m_connn.Close()	
}

bool CMDBDataBase::GetContent(tString wd, tString& meaning, tString& sentences) {
	Dim cmd As OleDbCommand = m_connn.CreateCommand
	Dim n As Integer = 0
	Dim dbReader As OleDbDataReader

	cmd.CommandText = "select explain from WordList where Word='" + wd + "'"

	Try
		dbReader = cmd.ExecuteReader

		While dbReader.Read
			content = dbReader.Item(0)
			n += 1
			type = Int(1).ToString
		End While

	Catch ex As Exception
		MessageBox.Show(ex.ToString)
		Return False
	End Try
	If n > 0 Then
		Return True
	Else
		Return False
	End If
}
	
bool CMDBDataBase::GetWordList(const tString word, tString& tFindWord) {
	//int l = _tcslen(wd);
	int l = word.length();

	TCHAR wordsPath[MAX_PATH];

	_stprintf(wordsPath, _T("%s%s%s"), m_tszGDictPath1, word.substr(0, 1).c_str(), _T("\\"));

	if (-1 == _taccess(wordsPath, 00))
	{
		_tmkdir(wordsPath);
		return false;
	}

	_stprintf(wordsPath, _T("%s%s%s"), wordsPath, word.c_str(), _T("*.json"));

	//find the first file
	//_tfinddata_t filedata;
	_tfinddata64_t filedata;
	int result = 5;

	if (-1 == m_hFile) m_hFile = _tfindfirst64(wordsPath, &filedata);
	else result = _tfindnext64(m_hFile, &filedata);
	if ((m_hFile != -1 && 5 == result) || 0 == result)
	{
		//search all files recursively.
		while (_tcslen(filedata.name) == 1 && filedata.name[0] == _T('.') ||
			_tcslen(filedata.name) == 2 && filedata.name[0] == _T('.') &&
			filedata.name[1] == _T('.'))
		{
			result = _tfindnext64(m_hFile, &filedata);
			if (-1 == result)
			{
				m_hFile = -1;
				_findclose(m_hFile);
				return false;
			}
		}

		if (filedata.attrib & _A_SUBDIR) assert(NULL);
		else
		{
			tFindWord = filedata.name;
			tFindWord = tFindWord.substr(0, tFindWord.find(_T(".")));
			//_tcscpy(filedata.name, tfindWord.c_str());
			//return filedata.name;
			return true;
		}
	}
	else
	{
		//close search handle
		_findclose(m_hFile);
		m_hFile = -1;
		return false;
	}
	return false;
}

int CMDBDataBase::GetWordList(const tString word, tString& wdlist) {
	Dim cmd As OleDbCommand = m_connn.CreateCommand
	Dim n As Integer = 0
	Dim dbReader As OleDbDataReader

	cmd.CommandText = "select Word from WordList where Word like '" + wd + "%'"
	Try
		dbReader = cmd.ExecuteReader

		While dbReader.Read
			wdlist = wdlist + dbReader.Item(0) + "@"
			n = n + 1
		End While
	Catch ex As Exception
		MessageBox.Show(ex.ToString)
		Return False
	End Try
	If n > 0 Then
		Return True
	Else
		Return False
	End If
}