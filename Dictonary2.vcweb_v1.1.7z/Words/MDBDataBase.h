//MDBDataBase.h

class CMDBDataBase {
public:
	CMDBDataBase();
	~CMDBDataBase();
	
private:
	Property m_connn As OleDb.OleDbConnection
	Property m_strDictName As String

public:	
	bool LoadDict(tString name);

	void UnloadDict();

    bool GetContent(tString wd, tString& meaning, tString& sentences);
	
	bool GetWordList(const tString word, tString& tFindWord);
}