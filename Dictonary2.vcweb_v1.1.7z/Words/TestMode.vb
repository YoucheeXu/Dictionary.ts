﻿Public Class CTestMode
	Private mNum1 As Integer = 1
    Private mNum2 As Integer = 1
    Private mTestNum As Integer = 1
	'to test
    Sub New()

    End Sub
	'to test
    Private Function GetNextWord() As String
        If mNum1 < frmWords.mStudyMode.mWordList.Length Then
            mNum1 = mNum1 + 1
            Return frmWords.mStudyMode.mWordList(mNum1 - 2)
        End If
        If mNum2 < frmWords.mStudyMode.mNewWordList.Length Then
            mNum2 = mNum2 + 1
            Return frmWords.mStudyMode.mNewWordList(mNum2 - 2)
        End If

        Return ""
    End Function
    'to do
    Public Function GoNext() As Boolean
        Dim word As String = frmWords.TxtWord.Text
        Dim word2 As String = frmWords.mWord
        frmWords.TxtWord.Text = ""
        If word.Length >= 1 And word <> frmWords.mWord And mTestNum < 10 Then
            frmWords.TxtWord.Text = ""
            Call frmWords.Pronounce(word2)
            mTestNum = mTestNum + 1
            Return False
        End If
        Select Case mTestNum
            Case 10
                Call frmWords.ShowTip()
                Return False
            Case 20
                frmWords.TxtWord.Text = word2
        End Select

        If word2 = word Then
            Dim curTime As DateTime = DateTime.Now
            Dim time As Integer = Convert.ToInt32(curTime.ToString("yyyyMMdd"))
            frmWords.mDict.UpdateTime(word2, time)
            Dim mark As Integer = frmWords.mDict.mMark
            If mTestNum < 5 Then
                frmWords.mDict.UpdateMark(word2, mark + (5 - mTestNum))
            Else
                frmWords.mDict.UpdateMark(word2, mark - mTestNum)
            End If

        End If

        frmWords.rtxDefinition.Hide()
        word2 = GetNextWord()
        If word2.Length >= 1 Then
            'labWord.Text = mWord
            frmWords.mWord = word2
            If frmWords.mDict.ExistWord(word2) Then
                'rtxDefinition.Text = mCET4Dict.mContent
                'labSymbol.Text = mCET4Dict.mSymbol
            End If
            Call frmWords.Pronounce(word2)
            mTestNum = 1
        Else
            frmWords.Close()
        End If
        Return True
    End Function
End Class