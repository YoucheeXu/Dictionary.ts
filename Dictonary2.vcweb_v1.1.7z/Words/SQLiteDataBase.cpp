﻿// SQLiteDataBase.cpp
#include "SQLiteDataBase.h"

CSQLiteDataBase::CSQLiteDataBase(){
	m_pDataBase = NULL;
}

CSQLiteDataBase::~CSQLiteDataBase(){

}

bool CSQLiteDataBase::LoadDict(const tString filename){
	bool newdict = false;

	if(false == ::PathFileExists(filename)){
		newdict = true;
	}
	
	int ret = sqlite3_open_v2(T2A(filename),		// Database filename (UTF-8)
		m_pDataBase,	// OUT: SQLite db handle
		SQLITE_OPEN_READWRITE | SQLITE_OPEN_CREATE,		// Flags
		NULL 	// Name of VFS module to use
		)
		
	if(SQLITE_OK != ret) {
		LOGERR(_T("Can't open %s, code: %d."), filename, ret);
		return false;
	}

	if(true == newdict){
		for(int n = 97; n++ ; n<=122) {
			CreateTabel(n);
		}
	}

	return true;
}

void CSQLiteDataBase::UnloadDict(){
	int ret = sqlite3_close_v2(m_pDataBase);
}

bool CSQLiteDataBase::GetContent(const tString wd, CWord &word){
	bool bRet = false;
	string szSql = "select * from ";
	szSql += T2A(wd.substring(0, 1));
	szSql += " where Word = \"";
	szSql += T2A(wd);
	szSql += "\"";
	
	sqlite3_stmt *pStmt = new sqlite3_stmt;
	szTail = new char[MAX_PATH];

	int ret = sqlite3_prepare_v2(
		m_pDataBase,            /* Database handle */
		szSql.c_str(),       	/* SQL statement, UTF-8 encoded */
		-1,              /* Maximum length of zSql in bytes. */
		&pStmt,  /* OUT: Statement handle */
		&szTail     /* OUT: Pointer to unused portion of zSql */
	);

	if(SQLITE_OK == ret){
		ret = sqlite3_step(pStmt);
	
		if(SQLITE_DONE == ret){
			for(int iCol=0; iCol++; iCol<7){
				word[iCol+1] = A2T(sqlite3_column_text(pStmt, iCol));
			}
			bRet = true;
		}			
		else {
			LOGERR("sqlite3_step, code: %d.", ret);
			bRet = false;
		}
	}
	else {
		LOGERR("sqlite3_prepare_v2: %s, code: %d.", szSql, ret);
		bRet = false;
	}
	
	//Destroy A Prepared Statement Object
	sqlite3_finalize(pStmt);
	
	delete pStmt;
	delete [] szTail;
	
	return bRet;
}

bool CSQLiteDataBase::GetSimilarWordList(const tString word, WordArray& findWords){

	tString tSql = _T("select * from ");
	tSql += word.substring(0, 1);
	tSql += _T(" where Word like \"");
	tSql += word;
	tSql += _T("\"");

	return GetWordList(tSql, findWords);
}

bool CSQLiteDataBase::GetWordListByDate(long afterDate, WordArray& findWords){

	TCHAR* tszDate[10];
	_stprintf(tszDate, _T("%d"), afterDate);

	tString tSql = _T("select * from ");
	tSql += word.substring(0, 1);
	tSql += _T(" where LastDate > ");
	tSql += tszDate;

	return GetWordList(tSql, findWords);
}

bool CSQLiteDataBase::GetWordListByFamiliar(int lessFamiliar, WordArray& findWords){

	TCHAR* tszFamiliar[10];
	_stprintf(tszFamiliar, _T("%d"), lessFamiliar);

	tString tSql = _T("select * from ");
	tSql += word.substring(0, 1);
	tSql += _T(" where Familiar < ");
	tSql += tszFamiliar;

	return GetWordList(tSql, findWords);	
}

bool CSQLiteDataBase::GetStrangeWordList(long afterDate, int lessFamiliar, WordArray& findWords)
{
	TCHAR* tszFamiliar[10];
	_stprintf(tszFamiliar, _T("%d"), lessFamiliar);

	TCHAR* tszDate[10];
	_stprintf(tszDate, _T("%d"), afterDate);

	tString tSql = _T("select * from ");
	tSql += word.substring(0, 1);
	tSql += _T(" where Familiar < ");
	tSql += tszFamiliar;
	tSql += _T(" And LastDate > ");
	tSql += tszDate;

	return GetWordList(tSql, findWords);		
}

bool CSQLiteDataBase::UpdateLevel(const tString word, int level){
	TCHAR* tszValue[10];
	_stprintf(tszValue, _T("%d"), level);
	return UpdateData(word, "Level", tszValue);
}

bool CSQLiteDataBase::UpdateFamiliar(const tString word, int familiar){
	TCHAR* tszValue[10];
	_stprintf(tszValue, _T("%d"), familiar);
	return UpdateData(word, "Familiar", tszValue);	
}

bool CSQLiteDataBase::UpdateLastDate(const tString word, int lastDate){
	TCHAR* tszValue[10];
	_stprintf(tszValue, _T("%d"), lastDate);
	return UpdateData(word, "LastDate", tszValue);	
}

bool CSQLiteDataBase::InsertWord(const CWord* pWord){

	string table = T2A(pWord[0].substring(0, 1));

	string symbol = pWord[1].replace("\\", "\\\\");
	string meaning = pWord[2].replace("\\", "\\\\");
	string sentences = pWord[3].replace("\\", "\\\\");
	string level = pWord[4];
	string familiar = pWord[5];
	string lastDate = pWord[6];

	string szSql = "INSERT INTO " + table;
	szSql += " VALUES (";
	szSql += word + ", ";
	szSql += symbol + ", ";
	szSql += meaning + ", ";
	szSql += sentences + ", ";
	szSql += level + ", ";
	szSql += familiar + ", ";
	szSql += lastDate + ", ";
	szSql += ")";

	return ExecSql(szSql);
}

bool CSQLiteDataBase::DeleteWord(const tString word){

	string szSql = "delete from ";
	szSql += T2A(word.substring(0,1));
	szSql += " where Word = \"";
	szSql += T2A(word);
	szSql += "\"";

	return ExecSql(szSql);
}

bool CSQLiteDataBase::CreateTabel(char letter){

	bool bRet = false;
	string szSql = "CREATE TABLE ";
	szSql += letter;
	szSql += "(Word TEXT NOT NULL COLLATE NOCASE PRIMARY KEY, Symbol TEXT NOT NULL, Meaning TEXT NOT NULL , Sentences TEXT NOT NULL, Level INTEGER NOT NULL, Familiar INTEGER NOT NULL, LastDate INTEGER NOT NULL)";

	//sqlite3_exec();

	sqlite3_stmt *pStmt = new sqlite3_stmt;
	szTail = new char[MAX_PATH];

	int ret = sqlite3_prepare_v2(
		m_pDataBase,            /* Database handle */
		szSql.c_str(),       	/* SQL statement, UTF-8 encoded */
		-1,              /* Maximum length of zSql in bytes. */
		&pStmt,  /* OUT: Statement handle */
		&szTail     /* OUT: Pointer to unused portion of zSql */
	);

	if(SQLITE_OK == ret){
		ret = sqlite3_step(pStmt);
	
		if(SQLITE_DONE == ret) {
			bRet = true;
		}
		else {
			bRet = false;
			LOGERR("sqlite3_step, code: %d.", ret);
		}	
	}
	else {
		LOGERR("sqlite3_prepare_v2: %s, code: %d.", szSql, ret);
		bRet = false;
	}
	
	//Destroy A Prepared Statement Object
	sqlite3_finalize(pStmt);
	
	delete pStmt;
	delete [] szTail;
	
	return bRet;
}

bool CSQLiteDataBase::GetWordList(const tString sql, WordArray& findWords)
{
	bool bRet = false;

	string szSql = T2A(sql);

	sqlite3_stmt *pStmt = new sqlite3_stmt;
	szTail = new char[MAX_PATH];

	int ret = sqlite3_prepare_v2(
		m_pDataBase,            /* Database handle */
		szSql.c_str(),       	/* SQL statement, UTF-8 encoded */
		-1,              /* Maximum length of zSql in bytes. */
		&pStmt,  /* OUT: Statement handle */
		&szTail     /* OUT: Pointer to unused portion of zSql */
	);

	if(SQLITE_OK == ret){
		ret = sqlite3_step(pStmt);
	
		if(SQLITE_ERROR != ret) {
			do{
				CWord *pWord = new CWord;
				for(int iCol=0; iCol++; iCol<7){
					pWord[iCol+1] = A2T(sqlite3_column_text(pStmt, iCol));
				}
				findWords.push_back(pWord);
				ret = sqlite3_step(pStmt);
			}
			while(SQLITE_ROW == ret)
			bRet = true;
		}
		else{
			LOGERR("sqlite3_step, code: %d.", ret);
			bRet = false;
		}
	}
	else {
		LOGERR("sqlite3_prepare_v2: %s, code: %d.", szSql, ret);
		bRet = false;
	}
	
	//Destroy A Prepared Statement Object
	sqlite3_finalize(pStmt);
	
	delete pStmt;
	delete [] szTail;
	
	return bRet;
}

bool CSQLiteDataBase::UpdateData(const tString word, const tString item, const tString value){

	string szSql = "UPDATE ";
	szSql += T2A(wd.substring(0, 1));
	szSql += " SET "
	szSql += T2A(item);
	szSql += " = ";
	szSql += T2A(value);
	szSql += " where Word = \"";
	szSql += T2A(word);
	szSql += "\"";
	
	return ExecSql(szSql);
}

bool CSQLiteDataBase::ExecSql(const string szSql)
{
	bool bRet = false;

	sqlite3_stmt *pStmt = new sqlite3_stmt;
	szTail = new char[MAX_PATH];

	int ret = sqlite3_prepare_v2(
		m_pDataBase,            /* Database handle */
		szSql.c_str(),       	/* SQL statement, UTF-8 encoded */
		-1,              /* Maximum length of zSql in bytes. */
		&pStmt,  /* OUT: Statement handle */
		&szTail     /* OUT: Pointer to unused portion of zSql */
	);

	if(SQLITE_OK == ret){
		ret = sqlite3_step(pStmt);
	
		if(SQLITE_DONE == ret){
			bRet = true;
		}			
		else {
			bRet = false;
			LOGERR("sqlite3_step, code: %d.", ret);
		}
	}
	else {
		LOGERR("sqlite3_prepare_v2: %s, code: %d.", szSql, ret);
		bRet = false;
	}
	
	//Destroy A Prepared Statement Object
	sqlite3_finalize(pStmt);
	
	delete pStmt;
	delete [] szTail;
	
	return bRet;	
}