#include "stdafx.h"
#include "GDictBase.h"
#include "DictDlg.h"
#include <io.h>
//#include <AtlBase.h>
#pragma comment(lib, "Shlwapi.lib")

CGDictBase::CGDictBase(CDictDlg* pDlg)
{
	m_pDlg = pDlg;
	m_hFile = -1;
}

CGDictBase::~CGDictBase()
{
}

bool CGDictBase::Load(const TCHAR* dictPath, const TCHAR* audioPath)
{
	_stprintf(m_tszGDictPath1, _T("%s%s"), dictPath, _T("\\Google\\"));
	//_stprintf(m_tszGDictPath2, _T("%s%s"), dictPath, _T("\\Google2\\"));

	_stprintf(m_tszAudioPath, _T("%s%s"), audioPath, _T("\\Google\\"));

	//_tcscpy(m_tszAudioPath, audioPath);

	return true;
}

void CGDictBase::Unload()
{
}

bool CGDictBase::QueryJson(const TCHAR* dictPath, const TCHAR* wd, TCHAR* jsonURL)
{
	TCHAR jsonPath[MAX_PATH];
	TCHAR jsonFile[MAX_PATH];

	tString tWord = wd;

	_stprintf(jsonPath, _T("%s%s%s"), dictPath, tWord.substr(0, 1).c_str(), _T("\\"));
	_stprintf(jsonFile, _T("%s%s%s"), jsonPath, tWord.c_str(), _T(".json"));

	try
	{
		if (-1 == _taccess(jsonFile, 00))
		{
			if (-1 == _taccess(jsonPath, 00))
				_tmkdir(jsonPath);

			m_pDlg->DownloadFile(jsonURL, jsonFile);
		}
	}
	catch (std::exception &e)
	{
		// Process the exception and quit 
		e.what();
		return false;
	}

	if (0 == _taccess(jsonFile, 00)) return true;
	else return false;
}

bool CGDictBase::QueryWrod(const TCHAR* wd)
{
	TCHAR jsonURL[MAX_PATH];
	bool bFound;

	_stprintf(jsonURL, _T("%s%s"),
		_T("http://dictionary.so8848.com/ajax_search?q="), wd);
	bFound = QueryJson(m_tszGDictPath1, wd, jsonURL);

	/*_stprintf(jsonURL, _T("%s%s%s"),
		_T("http://www.google.com/dictionary/json?callback=getJson&q="),
		wd, _T("&sl=en&tl=zh-cn&restrict=pr,de&client=te"));
	bFound = bFound || QueryJson(m_tszGDictPath2, wd, jsonURL);*/

	return bFound;
}

bool CGDictBase::GetWordList(const tString word, tString& tFindWord)
{
	//int l = _tcslen(wd);
	int l = word.length();

	TCHAR wordsPath[MAX_PATH];

	_stprintf(wordsPath, _T("%s%s%s"), m_tszGDictPath1, word.substr(0, 1).c_str(), _T("\\"));

	if (-1 == _taccess(wordsPath, 00))
	{
		_tmkdir(wordsPath);
		return false;
	}

	_stprintf(wordsPath, _T("%s%s%s"), wordsPath, word.c_str(), _T("*.json"));

	//find the first file
	//_tfinddata_t filedata;
	_tfinddata64_t filedata;
	int result = 5;

	if (-1 == m_hFile) m_hFile = _tfindfirst64(wordsPath, &filedata);
	else result = _tfindnext64(m_hFile, &filedata);
	if ((m_hFile != -1 && 5 == result) || 0 == result)
	{
		while (_tcslen(filedata.name) == 1 && filedata.name[0] == _T('.') ||
			_tcslen(filedata.name) == 2 && filedata.name[0] == _T('.') &&
			filedata.name[1] == _T('.'))
		{
			result = _tfindnext64(m_hFile, &filedata);
			if (-1 == result)
			{
				m_hFile = -1;
				_findclose(m_hFile);
				return false;
			}
		}

		if (filedata.attrib & _A_SUBDIR) assert(NULL);
		else
		{
			tFindWord = filedata.name;
			tFindWord = tFindWord.substr(0, tFindWord.find(_T(".")));
			//_tcscpy(filedata.name, tfindWord.c_str());
			//return filedata.name;
			return true;
		}
	}
	else
	{
		//close search handle
		_findclose(m_hFile);
		m_hFile = -1;
		return false;
	}
	return false;
}

bool CGDictBase::DeleteFile(const TCHAR* file) {
	SHFILEOPSTRUCT FileOp = {0};
	FileOp.fFlags = FOF_ALLOWUNDO | //允许放回回收站
		FOF_NOCONFIRMATION; //不出现确认对话框
	FileOp.pFrom = file;
	FileOp.pTo = NULL; //一定要是NULL
	FileOp.wFunc = FO_DELETE; //删除操作
	return SHFileOperation(&FileOp) == 0;
}

bool CGDictBase::DelWord(const TCHAR* wd)
{
	bool ret = false;
	TCHAR tszPath[MAX_PATH] = _T("");
	TCHAR path[2] = _T("");
	_tcsncpy(path, wd, 1);
	//path[1] = _T("\0")

	_stprintf(tszPath, _T("%s%s%s%s%s"), m_tszGDictPath1, path, _T("\\"), wd, _T(".json"));

	// ::DeleteFile(tszPath);
	// BOOL ret = ::PathFileExists(tszPath);
	
	ret = DeleteFile(tszPath);

	/*_stprintf(tszPath, _T("%s%s%s%s%s"), m_tszGDictPath2, path, _T("\\"), wd, _T(".json"));
	ret = DeleteFile(tszPath);*/

	return ret;
}

bool CGDictBase::DelAudio(const TCHAR* wd)
{
	bool ret = false;
	TCHAR tszPath[MAX_PATH] = _T("");

	_stprintf(tszPath, _T("%s%s%s"), m_tszAudioPath, wd, _T(".mp3"));

	ret = DeleteFile(tszPath);

	return ret;
}

//TCHAR* CGDictBase::GetAudioPath(const TCHAR* wd, bool isUs)
bool CGDictBase::GetAudioPath(const TCHAR* wd, bool isUs, tString& path)
{
	TCHAR mp3file[MAX_PATH];
	_stprintf(mp3file, _T("%s%s%s"), m_tszAudioPath, wd, _T(".mp3"));

	path = mp3file;

	//check if mp3file exits or not
	if (0 == _taccess(mp3file, 00)) return true;

	TCHAR mp3url[MAX_PATH];

	_stprintf(mp3url, _T("%s%s%s"), _T("http://www.gstatic.com/dictionary/static/sounds/de/0/"), wd, _T(".mp3"));
	if (true == m_pDlg->DownloadFile(mp3url, mp3file)) return true;

	return false;
}