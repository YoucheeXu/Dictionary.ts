#ifndef IDC_STATIC
#define IDC_STATIC (-1)
#endif

//#define ICO_MAIN								0x1000    //图标
#define IDD_DICT                                101
#define IDI_MAIN								102
#define IDD_ABOUT                               103
#define IDM_MAINMENU                            105
#define IDT_CAPTION                             40000
#define IDB_MENU                                40001
#define IDB_MIN                                 40002
#define IDB_MAX                                 40003
#define IDB_CLOSE                               40004
#define IDB_PREV                                40005
#define IDB_NEXT                                40006
#define IDB_DEL                                 40007
#define IDB_DROP                                40008
#define IDC_PANEL_INPUT                         40009
#define IDB_LOOKUP                              40010
#define IDC_EDIT_WORD                           40011
#define IDC_LSTB_WORDS                          40012
#define IDC_WB_DATA								40013

#define IDM_TOP                                 40100
#define IDM_NEWWORD								40110
#define IDM_EDITWORD                            40120
#define IDM_DELWORD                             40130
