//DictWebBrowser.cpp
#include "stdafx.h"
#include "DictApp.h"
#include "DictWebBrowser.h"

//CDictWebBrowser::CDictWebBrowser(CDictDlg* pDlg) : m_cRefs(1), m_pDlg(pDlg)
CDictWebBrowser::CDictWebBrowser() : m_cRefs(1), m_pDoc(NULL)
{
	// Set me as our event sink
	//m_EventSink.SetSink(this);
	//With m_webBrowser
	//	.AllowWebBrowserDrop = false
	//	.IsWebBrowserContextMenuEnabled = false
	//	.WebBrowserShortcutsEnabled = true
	//	.ObjectForScripting = Me
	//	.ScriptErrorsSuppressed = true
	//End With

	// The entry for the dialog's control in resource.rc must match this name.
	CString className = _T("WebControl");

	// Register the window class
	WNDCLASS wc;
	ZeroMemory(&wc, sizeof(WNDCLASS));

	if (!::GetClassInfo(GetApp().GetInstanceHandle(), className, &wc))
	{
		wc.lpszClassName = className;
		wc.lpfnWndProc = ::DefWindowProc;
		wc.hInstance = GetApp().GetInstanceHandle();
		::RegisterClass(&wc);
	}

	assert(::GetClassInfo(GetApp().GetInstanceHandle(), className, &wc));

	m_pDialog = GetDialogApp().GetDialog();

	assert(m_pDialog);

	// GetIWebBrowser2()->put_Silent(VARIANT_TRUE);
}

CDictWebBrowser::~CDictWebBrowser()
{
}

STDMETHODIMP_(ULONG) CDictWebBrowser::AddRef()
{
	return ++m_cRefs;
}

STDMETHODIMP CDictWebBrowser::QueryInterface(REFIID riid, void** ppvObject)
{
	if (!ppvObject) return E_POINTER;

	if (IsEqualIID(riid, IID_IUnknown)) *ppvObject = this; 
	else if(IsEqualIID(riid, IID_IDispatch)) *ppvObject = (IDispatch *)this;
	else if (IsEqualIID(riid, IID_IDocHostUIHandler)) *ppvObject = (IDocHostUIHandler*)this;
	else if (IsEqualIID(riid, IID_IOleCommandTarget)) *ppvObject = (IOleCommandTarget*)this;
	else
	{
		*ppvObject = NULL;
		return E_NOINTERFACE;
	}

	AddRef();
	return S_OK;
}

STDMETHODIMP CDictWebBrowser::GetIDsOfNames(REFIID riid, OLECHAR** rgszNames, unsigned int cNames, LCID lcid, DISPID* rgdispid)
{
	UNREFERENCED_PARAMETER((IID)riid); // IID cast required for the MinGW compiler
	UNREFERENCED_PARAMETER(rgszNames);
	UNREFERENCED_PARAMETER(cNames);
	UNREFERENCED_PARAMETER(lcid);

	// for (i = 0; i < cNames; i ++)
	// { 
	// if(0 == _tcscmp(rgszNames[i], _T("QueryWord")))
	// {
	// *rgDispId = DISPID_DICT_QUERYWORD; 
	// return S_OK; 
	// }
	// }

	*rgdispid = DISPID_UNKNOWN;
	return DISP_E_UNKNOWNNAME;
}

STDMETHODIMP CDictWebBrowser::GetTypeInfo(unsigned int itinfo, LCID lcid, ITypeInfo** pptinfo)
{
	UNREFERENCED_PARAMETER(itinfo);
	UNREFERENCED_PARAMETER(lcid);
	UNREFERENCED_PARAMETER(pptinfo);
	return E_NOTIMPL;
}

STDMETHODIMP CDictWebBrowser::GetHostInfo(DOCHOSTUIINFO *pInfo)
{
	pInfo->cbSize = sizeof(DOCHOSTUIINFO);
	//pInfo->dwFlags = DOCHOSTUIFLAG_NO3DBORDER | DOCHOSTUIFLAG_SCROLL_NO;
	pInfo->dwFlags |= DOCHOSTUIFLAG_NO3DOUTERBORDER;
	return S_OK;
}

STDMETHODIMP CDictWebBrowser::GetTypeInfoCount(unsigned int* pctinfo)
{
	UNREFERENCED_PARAMETER(pctinfo);
	return E_NOTIMPL;
}

STDMETHODIMP_(ULONG) CDictWebBrowser::Release()
{
	return --m_cRefs;
}

void CDictWebBrowser::ConnectEvents()
{
	//IUnknown* pUnk = GetBrowser().GetAXWindow().GetUnknown();
	IUnknown* pUnk = GetAXWindow().GetUnknown();
	if (!pUnk) return;

	IConnectionPoint* pcp;
	pcp = GetConnectionPoint(DIID_DWebBrowserEvents2);
	if (!pcp) return;

	//DWORD dwCookie;
	pcp->Advise((IDispatch*)this, &m_eventCookie);
	pcp->Release();
	pUnk->Release();

	//ICustomDoc *pCustomDoc;

	//HRESULT hr;

	//this->

	//CComPtr<IDispatch> spDoc;
	//Shared_Ptr<IDispatch> spDoc;
	IDispatch* spDoc;

	//m_spWebBrowser2->get_Document(&spDoc);
	GetIWebBrowser2()->get_Document(&spDoc);

	//CComPtr<ICustomDoc> spCustomDoc;
	//Shared_Ptr<ICustomDoc> spCustomDoc;
	ICustomDoc* spCustomDoc;
	spDoc->QueryInterface(IID_ICustomDoc, (void **)&spCustomDoc);

	//CComPtr<IDocHostUIHandler> spDocHostUIHandler;
	//Shared_Ptr<IDocHostUIHandler> spDocHostUIHandler;
	IDocHostUIHandler* spDocHostUIHandler;

	QueryInterface(IID_IDocHostUIHandler, (void **)&spDocHostUIHandler);
	spCustomDoc->SetUIHandler(spDocHostUIHandler);
}

IConnectionPoint* CDictWebBrowser::GetConnectionPoint(REFIID riid)
{
	//IUnknown *pUnk = GetBrowser().GetAXWindow().GetUnknown();
	IUnknown *pUnk = GetAXWindow().GetUnknown();
	if (!pUnk)
		return NULL;

	IConnectionPointContainer* pcpc;
	IConnectionPoint* pcp = NULL;

	HRESULT hr = pUnk->QueryInterface(IID_IConnectionPointContainer, (void**)&pcpc);
	if (SUCCEEDED(hr))
	{
		pcpc->FindConnectionPoint(riid, &pcp);
		pcpc->Release();
	}

	pUnk->Release();

	return pcp;
}

/* DISPID CDictWebBrowser::FindId(IDispatch *pObj, LPOLESTR pName)
// {
// DISPID id = 0;
// if(FAILED(pObj->GetIDsOfNames(IID_NULL, &pName, 1,LOCALE_SYSTEM_DEFAULT, &id))) id = -1;
// return id;
} */

/* HRESULT CDictWebBrowser::InvokeMethod(IDispatch *pObj, LPOLESTR pName, VARIANT *pVarResult, VARIANT *p, int cArgs)
// {
// DISPID dispid = FindId(pObj, pName);
// if(-1 == dispid) return E_FAIL;
// DISPPARAMS ps;
// ps.cArgs = cArgs;
// ps.rgvarg = p;
// ps.cNamedArgs = 0;
// ps.rgdispidNamedArgs = NULL;
// return pObj->Invoke(dispid, IID_NULL, LOCALE_SYSTEM_DEFAULT, DISPATCH_METHOD, &ps, pVarResult, NULL, NULL);
} */

/* HRESULT CDictWebBrowser::GetProperty(IDispatch *pObj, LPOLESTR pName, VARIANT *pValue)
// {
// DISPID dispid = FindId(pObj, pName);
// if(-1 == dispid) return E_FAIL;
// DISPPARAMS ps;
// ps.cArgs = 0;
// ps.rgvarg = NULL;
// ps.cNamedArgs = 0;
// ps.rgdispidNamedArgs = NULL;
// return pObj->Invoke(dispid, IID_NULL, LOCALE_SYSTEM_DEFAULT, DISPATCH_PROPERTYGET, &ps, pValue, NULL, NULL);
} */

/* HRESULT CDictWebBrowser::SetProperty(IDispatch *pObj, LPOLESTR pName, VARIANT *pValue)
// {
// DISPID dispid = FindId(pObj, pName);
// if(dispid == -1) return E_FAIL;
// DISPPARAMS ps;
// ps.cArgs = 1;
// ps.rgvarg = pValue;
// ps.cNamedArgs = 0;
// ps.rgdispidNamedArgs = NULL;
// return pObj->Invoke(dispid, IID_NULL, LOCALE_SYSTEM_DEFAULT, DISPATCH_PROPERTYPUT, &ps, NULL, NULL, NULL);
} */

/* VARIANT CDictWebBrowser::InvokeScript(LPOLESTR strFunc, const CStringArray& paramArray);
// {
// //Getting IDispatch for Java Script objects
// IDispatch* pScript;
// HRESULT hr = m_pDoc->get_Script(&spDisp);
// ATLASSERT(SUCCEEDED(hr));
// if(!FAILED(hr))
// {
// ShowError("Cannot GetScript");
// return false;
// }
// //Find dispid for given function in the object
// //CComBSTR bstrMember(strFunc);
// DISPID dispid = NULL;
// //hr = pScript->GetIDsOfNames(IID_NULL, &strFunc, 1,
// LOCALE_SYSTEM_DEFAULT, &dispid);
// hr = pScript->GetIDsOfNames(IID_NULL, &bstrMember, 1,
// LOCALE_SYSTEM_DEFAULT, &dispid);
// if(FAILED(hr))
// {
// ShowError(GetSystemErrorMessage(hr));
// return false;
// }

// const int arraySize = paramArray.GetSize();
// //Putting parameters
// DISPPARAMS dispparams;
// memset(&dispparams, 0, sizeof dispparams);
// dispparams.cArgs      = arraySize;
// dispparams.rgvarg     = new VARIANT[dispparams.cArgs];
// dispparams.cNamedArgs = 0;

// for( int i = 0; i < arraySize; i++)
// {
// CComBSTR bstr = paramArray.GetAt(arraySize - 1 - i); // back reading
// bstr.CopyTo(&dispparams.rgvarg[i].bstrVal);
// dispparams.rgvarg[i].vt = VT_BSTR;
// }
// EXCEPINFO excepInfo;
// memset(&excepInfo, 0, sizeof excepInfo);
// VARIANT varResult;
// UINT nArgErr = (UINT)-1;  // initialize to invalid arg
// //Call JavaScript function
// hr = pScript->Invoke(dispid, IID_NULL, 0,
// DISPATCH_METHOD, &dispparams,
// &varResult, &excepInfo, &nArgErr);
// delete [] dispparams.rgvarg;
// if(FAILED(hr))
// {
// ShowError(GetSystemErrorMessage(hr));
// return false;
// }
// return varResult;
} */

bool CDictWebBrowser::InvokeScript(LPOLESTR strFunc)
{
	//Getting IDispatch for Java Script objects
	IDispatch* pScript;
	BGNLOG;
	HRESULT hr = m_pDoc->get_Script(&pScript);
	//ATLASSERT(SUCCEEDED(hr));
	if (FAILED(hr))
	{
		LOGINFO(_T("Error: Can't GetScript."));
		return false;
	}
	//Find dispid for given function in the object
	DISPID dispid = NULL;
	hr = pScript->GetIDsOfNames(IID_NULL, &strFunc, 1,
		LOCALE_SYSTEM_DEFAULT, &dispid);
	if (FAILED(hr))
	{
		// ShowError(GetSystemErrorMessage(hr));
		LOGINFO(_T("Error: Can't get id for function: %s."), strFunc);
		return false;
	}

	//Putting parameters  
	DISPPARAMS dispparams;
	memset(&dispparams, 0, sizeof dispparams);
	dispparams.cArgs = 0;
	dispparams.rgvarg = 0;
	dispparams.cNamedArgs = 0;

	EXCEPINFO excepInfo;
	memset(&excepInfo, 0, sizeof excepInfo);
	VARIANT varResult;
	UINT nArgErr = (UINT)-1;  // initialize to invalid arg
	//Call JavaScript function         
	hr = pScript->Invoke(dispid, IID_NULL, 0,
		DISPATCH_METHOD, &dispparams,
		&varResult, &excepInfo, &nArgErr);
	if (FAILED(hr))
	{
		// ShowError(GetSystemErrorMessage(hr));
		LOGINFO(_T("Error: Can't invoke function: %s."), strFunc);
		return false;
	}
	return true;

}

/*IHTMLElement* CDictWebBrowser::GetElementById(const TCHAR* tszID)
//{
//	return NULL;
}*/

bool CDictWebBrowser::SetInnerHtmlByID(const TCHAR* tszID, const TCHAR* tszHtml)
{
	IHTMLElementCollection* pElemColl;

	//IHTMLElement *pBodyElem;

	HRESULT hr = m_pDoc->get_all(&pElemColl);
	//HRESULT hr = m_pDoc->get_body(&pBodyElem);

	if (SUCCEEDED(hr))
	{
		// Obtained element collection.

		IDispatch* pElemDisp = NULL;
		IHTMLElement* pElem = NULL;
		//_variant_t varID(tszID, VT_BSTR);
		VARIANT varID;
		varID.vt = VT_BSTR;
		varID.bstrVal = TtoBSTR(tszID);
		//_variant_t varIdx(0, VT_I4);
		VARIANT varIdx;
		varIdx.vt = VT_I4;
		varIdx.lVal = 0;

		//hr = pBodyElem->get;
		hr = pElemColl->item(varID, varIdx, &pElemDisp);

		if (SUCCEEDED(hr))
		{
			hr = pElemDisp->QueryInterface(IID_IHTMLElement, (void**)&pElem);

			if (SUCCEEDED(hr))
			{
				// Obtained element with ID of "myID".
				//ConnectEvents(pElem);
				hr = pElem->put_innerHTML(TtoBSTR(tszHtml));
				pElem->Release();
			}
			pElemDisp->Release();
		}
		//ProcessElementCollection(pElemColl);
		//pBodyElem->Release();
		pElemColl->Release();
		return true;
	}
	return false;
}

STDMETHODIMP CDictWebBrowser::Invoke(DISPID dispid, REFIID riid, LCID lcid, WORD wFlags, DISPPARAMS* pDispParams, VARIANT* pvarResult, EXCEPINFO* pexecinfo, unsigned int* puArgErr)
{
	UNREFERENCED_PARAMETER((IID)riid);			// IID cast required for the MinGW compiler
	UNREFERENCED_PARAMETER(lcid);
	UNREFERENCED_PARAMETER(wFlags);
	UNREFERENCED_PARAMETER(pvarResult);
	UNREFERENCED_PARAMETER(pexecinfo);
	UNREFERENCED_PARAMETER(puArgErr);

	// if (!m_pSink) return S_OK;

	//LPDISPATCH pDispElem = pvarResult->pdispVal;
	// IHTMLEventObj* pEvtObj;

	// HRESULT hr = pDispElem->QueryInterface(IID_IHTMLEventObj, (void**)&pEvtObj);

	switch (dispid)
	{
		// Just some of the possible events ...
		// case DISPID_HTMLELEMENTEVENTS2_ONDBLCLICK:
		// //OnDoubleClick(pEvtObj);
		// break;

		// case DISPID_DICT_QUERYWORD:

		// break;

	case DISPID_BEFORENAVIGATE2:
		OnBeforeNavigate2(pDispParams);
		break;

	case DISPID_COMMANDSTATECHANGE:
		//OnCommandStateChange(pDispParams);
		break;

	case DISPID_DOCUMENTCOMPLETE:
		//OnDocumentComplete(pDispParams);
		//CComBSTR bstrURL;
		//GetIWebBrowser2()->get_LocationURL(bstrURL);
		OnDocumentComplete(pDispParams->rgvarg[1].pdispVal, pDispParams->rgvarg[0].pvarVal);
		break;

	case DISPID_DOWNLOADBEGIN:
		//OnDownloadBegin(pDispParams);
		break;

	case DISPID_DOWNLOADCOMPLETE:
		//OnDownloadComplete(pDispParams);
		break;

	case DISPID_NAVIGATECOMPLETE2:
		OnNavigateComplete2(pDispParams);
		break;

	case DISPID_NEWWINDOW2:
		//OnNewWindow2(pDispParams);
		break;

	case DISPID_PROGRESSCHANGE:
		//OnProgressChange(pDispParams);
		break;

	case DISPID_PROPERTYCHANGE:
		//OnPropertyChange(pDispParams);
		break;

	case DISPID_STATUSTEXTCHANGE:
		//OnStatusTextChange(pDispParams);
		break;

	case DISPID_TITLECHANGE:
		//OnTitleChange(pDispParams);
		break;
	}

	//pDispElem->Release();

	return S_OK;
}

void CDictWebBrowser::QueryWord(const TCHAR* tszWord, const TCHAR* tszUrl)
{
	//m_pDialog->QueryWord(tWord.c_str());
	m_tWord = tszWord;
	StringTrim(m_tWord);
	Navigate(tszUrl);
}

/* void CDictWebBrowser::OnDoubleClick(IHTMLEventObj* pEvtObj)
// {
// LOGINFOBGNT;
// // mshtml.IHTMLDocument2 oDOM= m_webBrowser.Document.DomDocument;
// // //'m_edtWord.Text = oDOM.selection.createRange.htmlText.ToString.ToLower.Trim
// // m_edtWord.SetWindowText(oDOM.selection.createRange.Text.ToString.ToLower.Trim);
// // this->EditWord_TextChanged();
// CString elemInfo("OnClick Event | Element=");
// BSTR bstrTag = 0;
// BSTR bstrId = 0;
// BSTR bstrAt = 0;

// VARIANT bstrValue;
// //get the element object who fire current event.
// IHTMLElement* pElem;
// pEvtObj->get_srcElement(&pElem);
// //get Button value.
// CString strAt("VALUE");
// bstrAt = strAt.AllocSysString();
// pElem->getAttribute(bstrAt, 1, &bstrValue);
// BSTR reVal = bstrValue.bstrVal;
// CString strReVal(reVal);
// //get Button id
// pElem->get_id(&bstrId);
// CString strId(bstrId);
// //get tag name
// pElem->get_tagName(&bstrTag);
// CString strTag(bstrTag);
// //object release.
// SysFreeString(bstrId);
// SysFreeString(bstrAt);
// SysFreeString(bstrTag);
// SysFreeString(reVal);
// elemInfo = elemInfo + strTag + ";id= " + strId + ";Value= " + strReVal;
// //get main dialog window object.
// // CMshtmlhookDlg* mainDlg = (CMshtmlhookDlg*)m_pWnd;
// // mainDlg->DisplayEvent(elemInfo);
// LOGINFO(elemInfo.c_str());
// m_pDialog->QueryWord();
}*/

/* void CDictWebBrowser::OnDocumentBegin(DISPPARAMS* pDispParams)
// {
// UNREFERENCED_PARAMETER(pDispParams);
// TRACE(_T("OnDocumentBegin\n"));
} */

/*// void CDictWebBrowser::OnDocumentComplete(DISPPARAMS* pDispParams)
// {
// UNREFERENCED_PARAMETER(pDispParams);
// CDictDlg* pDialog = GetDlgApp()->GetDialog();
// //if(true = m_bMore)
// if(true = pDialog->IsMore())
// {
// HtmlElement word_Item = m_webBrowser.Document.GetElementById(_T("queryword"));
// if(NULL == word_Item) return;

// word_Item.InnerHtml = m_tszWord;

// //m_webBrowser.Document.InvokeScript(_T("google_search"));

// // VARIANT params[10];
// // VARIANT ret;
// // //��ȡҳ��window
// // IDispatch *pHtmlWindow = GetHtmlWindow();//ҳ��ȫ�ֺ���Testʵ������window��Test������
// // InvokeMethod(pHtmlWindow, _T("google_search"), &ret, params, 0);

// //CComQIPtr<IHTMLDocument2> spDoc = GetIWebBrowser2()->get_Document();
// //CComDispatchDriver spScript;
// //spDoc->get_Script(&spScript);
// //CComVariant varRet;
// //spScript.Invoke0(_T("Add"), &varRet);

// IHTMLElement *elBody = NULL;
// IHTMLDocument2 *pDoc;
// GetIWebBrowser2()->get_Document(pDoc);

// pDialog->OnHoverSpeech(m_tszWord, true);
// m_bMore = false;
// //Debug.Print(m_webBrowser.DocumentText);
// }

// // return

// if(READYSTATE_COMPLETE == GetReadyState())
// {
// pDoc->attachEvent();
// //addEventListener(type, listener, useCapture); //for IE11
// }
//m_webBrowser.Document.Body.AttachEventHandler("ondblclick", AddressOf m_webBrowser_OnDoubleClick)
// // }
// // if mFocus
// //{
// // m_edtWord.Focus()
// // mFocus = false
// // }
} */

void CDictWebBrowser::OnDocumentComplete(LPDISPATCH pDisp, VARIANT* URL)
{
	//CDictDlg* pDialog = GetDlgApp()->GetDialog();
	if (false == m_pDialog->IsMore())
	{
		m_pDialog->FocusEditWord();
		return;
	}

	HRESULT hr;
	IUnknown* pUnkBrowser = NULL;
	IUnknown* pUnkDisp = NULL;
	IDispatch* pDocDisp = NULL;
	//IHTMLDocument2* pDoc = NULL;

	//IUnknown* pUnkBrowser = GetAXWindow().GetUnknown();

	// Is this the DocumentComplete event for the top frame window?
	// Check COM identity: compare IUnknown interface pointers.
	hr = GetIWebBrowser2()->QueryInterface(IID_IUnknown, (void**)&pUnkBrowser);
	//if(pUnkBrowser)
	if (SUCCEEDED(hr))
	{
		//// Store the pointer to the WebBrowser control
		////hr = pUnkBrowser->QueryInterface(IID_IWebBrowser2, (void**)&m_pIWebBrowser2);
		//hr = pUnkBrowser->QueryInterface(IID_IWebBrowser2, (void**)&pUnkBrowser);
		//
		//if (SUCCEEDED(hr))
		//{
		hr = pDisp->QueryInterface(IID_IUnknown, (void**)&pUnkDisp);
		if (SUCCEEDED(hr))
		{
			if (pUnkBrowser == pUnkDisp)
			{
				// This is the DocumentComplete event for the top frame.
				// This page is loaded, so we can access the DHTML Object Model.
				hr = GetIWebBrowser2()->get_Document(&pDocDisp);

				if (SUCCEEDED(hr))
				{
					// Obtained the document object.
					// pDocDisp->QueryInterface(IID_IHTMLDocument2, (void**)&pDoc);
					pDocDisp->QueryInterface(IID_IHTMLDocument2, (void**)&m_pDoc);
					if (SUCCEEDED(hr))
					{
						// Obtained the IHTMLDocument2 interface for the document object

						/*IHTMLElement* pElem = GetElementById(_T("queryword"));
						SetInnerHtml(pElem, m_tszWord);*/
						SetInnerHtmlByID(_T("queryword"), m_tWord.c_str());
						InvokeScript(_T("google_search"));
						m_pDialog->OnHoverSpeech(m_tWord.c_str(), true);
						m_pDialog->FocusEditWord();
						//AttachEvent(_T("ondblclick"), this);
						//m_pDoc->put_ondblclick((VARIANT)&this);
					}
					pDocDisp->Release();
				}
			}
			pUnkDisp->Release();
		}
	}
	pUnkBrowser->Release();
	m_pDialog->SetMore(false);
	m_pDialog->FocusEditWord();
}

/* void CDictWebBrowser::OnDownloadBegin(DISPPARAMS* pDispParams)
// {
// UNREFERENCED_PARAMETER(pDispParams);
} */

/* void CDictWebBrowser::OnDownloadComplete(DISPPARAMS* pDispParams)
// {
// UNREFERENCED_PARAMETER(pDispParams);
} */

void CDictWebBrowser::OnBeforeNavigate2(DISPPARAMS* pDispParams)
{
	UNREFERENCED_PARAMETER(pDispParams);

	if (pDispParams->rgvarg[0].vt == (VT_BYREF | VT_VARIANT))
	{
		VARIANT vtURL;
		vtURL = *pDispParams->rgvarg[0].pvarVal;
		vtURL.vt = VT_BSTR;

		// str += vtURL.bstrVal;
		// TRACE(str);
		VariantClear(&vtURL);
	}

	BSTR bstrUrlName;

	HRESULT hr = GetIWebBrowser2()->get_LocationURL(&bstrUrlName);
	if (FAILED(hr))
		return;

	tString tUrl = WtoT(bstrUrlName);
	tString tFunc;
	tString tWord;

	if (_T("app:") == tUrl.substr(0, 4))
	{
		// cancel the common url navigate and call your c++ code here  
		// *pbCancel = TRUE;
		// call other c++ function here or parse the argument in the strUrl
		int pos = tUrl.find(_T(":"), 4);
		if (pos != tString::npos)
		{
			tFunc = tUrl.substr(4, pos - 4);
			if (_T("queryword") == tFunc)
			{
				tWord = tUrl.substr(pos + 1, tUrl.size() - (pos + 1));
				m_pDialog->QueryMore(tWord.c_str());
			}
			else if (_T("pronounceword") == tFunc)
			{
				tWord = tUrl.substr(pos + 1, tUrl.size() - (pos + 1));
				m_pDialog->OnHoverSpeech(tWord.c_str(), true);
			}
		}
		return;
	}
	// go common url navigate here 
}

/* void CDictWebBrowser::OnCommandStateChange(DISPPARAMS* pDispParams)
// {
// // CToolBar* pTB = GetToolBar();

// // if (pTB->IsWindow())
// // {
// // if ((pDispParams) && (pDispParams->cArgs == 2))
// // {
// // if (pDispParams->rgvarg[1].vt == (VT_I4) && pDispParams->rgvarg[0].vt == (VT_BOOL))
// // {
// // VARIANT_BOOL bEnable = pDispParams->rgvarg[0].boolVal;
// // int nCommand = pDispParams->rgvarg[1].intVal;
// // {
// // switch (nCommand)
// // {
// // case 1: // Navigate forward:
// // bEnable ? pTB->EnableButton(IDM_FORWARD) : pTB->DisableButton(IDM_FORWARD);

// // break;
// // case 2: // Navigate back:
// // bEnable ? pTB->EnableButton(IDM_BACK) : pTB->DisableButton(IDM_BACK);
// // break;
// // }
// // }
// // }
// // }
// // }
} */

void CDictWebBrowser::OnNavigateComplete2(DISPPARAMS* pDispParams)
{
	tString str = _T("NavigateComplete2: ");

	if (pDispParams->rgvarg[0].vt == (VT_BYREF | VT_VARIANT))
	{
		VARIANT vtURL;
		vtURL = *pDispParams->rgvarg[0].pvarVal;
		vtURL.vt = VT_BSTR;

		str += vtURL.bstrVal;
		TRACE(str.c_str());
		VariantClear(&vtURL);
	}

	BSTR bstrUrlName;

	HRESULT hr = GetIWebBrowser2()->get_LocationURL(&bstrUrlName);
	if (FAILED(hr)) return;

	//SetUIHandler(this);
}

/* void CDictWebBrowser::OnNewWindow2(DISPPARAMS* pDispParams)
// {
// UNREFERENCED_PARAMETER(pDispParams);
// TRACE("newWindow2\n");
} */

/* void CDictWebBrowser::OnProgressChange(DISPPARAMS* pDispParams)
// {
// // tString str;

// // if (pDispParams->cArgs != 0)
// // {
// // if (pDispParams->cArgs > 1 && pDispParams->rgvarg[1].vt == VT_I4)
// // {
// // str.Format(_T("Progress = %d"), pDispParams->rgvarg[1].lVal);
// // }

// // if (pDispParams->rgvarg[0].vt == VT_I4)
// // {
// // tString str2;
// // str2.Format(_T(", ProgressMax = %d\n"), pDispParams->rgvarg[0].lVal);
// // str = str + str2;
// // }

// // TRACE(str);
// // }
} */

/* void CDictWebBrowser::OnPropertyChange(DISPPARAMS* pDispParams)
// {
// // tString str;
// // if (pDispParams->cArgs > 0 && pDispParams->rgvarg[0].vt == VT_BSTR)
// // str.Format(_T("Property Change: %s\n"), (LPCTSTR)W2T(pDispParams->rgvarg[0].bstrVal));

// // TRACE(str);
} */

/* void CDictWebBrowser::OnStatusTextChange(DISPPARAMS* pDispParams)
// {
// // LPOLESTR lpStatusText = pDispParams->rgvarg->bstrVal;

// // if (GetStatusBar()->IsWindow() && lpStatusText)
// // {
// // if (lstrcmp(W2T(lpStatusText), _T("")))
// // {
// // GetStatusBar()->SetPartText(0, W2T(lpStatusText));
// // }
// // else
// // GetStatusBar()->SetPartText(0, _T("Done"));
// // }
} */

/* void CDictWebBrowser::OnTitleChange(DISPPARAMS* pDispParams)
// {
// // TRACE("TitleChange: \n");
// // tString str;

// // if (pDispParams->cArgs > 0 && pDispParams->rgvarg[0].vt == VT_BSTR)
// // {
// // str = tString(pDispParams->rgvarg[0].bstrVal) + _T(" - ") + LoadString(IDW_MAIN);
// // TRACE(W2T(pDispParams->rgvarg[0].bstrVal));
// // }
// // else
// // str = LoadString(IDW_MAIN);

// // SetWindowText(str);
} */

HRESULT STDMETHODCALLTYPE CDictWebBrowser::Exec(
	/* [unique][in] */ __RPC__in_opt const GUID *pguidCmdGroup,
	/* [in] */ DWORD nCmdID,
	/* [in] */ DWORD nCmdexecopt,
	/* [unique][in] */ __RPC__in_opt VARIANT *pvaIn,
	/* [unique][out][in] */ __RPC__inout_opt VARIANT *pvaOut)
{
	HRESULT hr = OLECMDERR_E_NOTSUPPORTED;
	//return S_OK;  
	if (pguidCmdGroup && IsEqualGUID(*pguidCmdGroup, CGID_DocHostCommandHandler))
	{
		switch (nCmdID)
		{
		case OLECMDID_SHOWSCRIPTERROR:
		{
			IHTMLDocument2*             pDoc = NULL;
			IHTMLWindow2*               pWindow = NULL;
			IHTMLEventObj*              pEventObj = NULL;
			BSTR                        rgwszNames[5] =
				{
					SysAllocString(L"errorLine"), SysAllocString(L"errorCharacter"), 
					SysAllocString(L"errorCode"), SysAllocString(L"errorMessage"), 
					SysAllocString(L"errorUrl")
				};
			DISPID                      rgDispIDs[5];
			VARIANT                     rgvaEventInfo[5];
			DISPPARAMS                  params;
			BOOL                        fContinueRunningScripts = true;

			params.cArgs = 0;
			params.cNamedArgs = 0;

			hr = pvaIn->punkVal->QueryInterface(IID_IHTMLDocument2, (void **)&pDoc);

			hr = pDoc->get_parentWindow(&pWindow);
			pDoc->Release();

			hr = pWindow->get_event(&pEventObj);

			for (int i = 0; i < 5; i++)
			{

				hr = pEventObj->GetIDsOfNames(IID_NULL, &rgwszNames[i], 1,
					LOCALE_SYSTEM_DEFAULT, &rgDispIDs[i]);

				hr = pEventObj->Invoke(rgDispIDs[i], IID_NULL,
					LOCALE_SYSTEM_DEFAULT,
					DISPATCH_PROPERTYGET, &params, &rgvaEventInfo[i],
					NULL, NULL);
				//�����ڴ˼�¼������Ϣ

				//����ʹ��SysFreeString���ͷ�SysAllocString������ڴ�,SysAllocString�ڷ�����ڴ��м�¼���ַ��ĳ���
				SysFreeString(rgwszNames[i]);
			}

			// At this point, you would normally alert the user with   
			// the information about the error, which is now contained  
			// in rgvaEventInfo[]. Or, you could just exit silently.  

			(*pvaOut).vt = VT_BOOL;
			if (fContinueRunningScripts)
			{
				// ��ҳ���м���ִ�нű� 
				(*pvaOut).boolVal = VARIANT_TRUE;
			}
			else
			{
				// ֹͣ��ҳ����ִ�нű�  
				(*pvaOut).boolVal = VARIANT_FALSE;
			}
			break;
		}
		default:
			hr = OLECMDERR_E_NOTSUPPORTED;
			break;
		}
	}
	else
	{
		hr = OLECMDERR_E_UNKNOWNGROUP;
	}
	return (hr);
}