//DictWebBrowser.h
#ifndef _DICTWEBBROWSER_H_
#define _DICTWEBBROWSER_H_

//#include <Mshtml.h>
//#include <webbrowser.h>

// The following can also be found in exdispid.h (except MinGW)
//#define DISPID_STATUSTEXTCHANGE   102
//#define DISPID_DOWNLOADCOMPLETE   104
//#define DISPID_COMMANDSTATECHANGE 105
//#define DISPID_DOWNLOADBEGIN      106
//#define DISPID_PROGRESSCHANGE     108
//#define DISPID_PROPERTYCHANGE     112
//#define DISPID_TITLECHANGE        113
//#define DISPID_BEFORENAVIGATE2    250
//#define DISPID_NEWWINDOW2         251
//#define DISPID_NAVIGATECOMPLETE2  252
//#define DISPID_DOCUMENTCOMPLETE   259

// #define DISPID_DICT_QUERYWORD		  1000
// #define DISPID_DICT_PRONOUNCEWORD	  1001

class CDictDlg;	// Forward declaration

class CDictWebBrowser : public CWebBrowser, public IDispatch, public IDocHostUIHandler, public IOleCommandTarget
{
public:
	//CDictWebBrowser(CDictDlg* pDlg);
	CDictWebBrowser();
	~CDictWebBrowser();

private:
	//CWebBrowser& GetBrowser() const { return (CWebBrowser&)this; }
	IConnectionPoint* GetConnectionPoint(REFIID riid);
	
private:
	//DISPID FindId(IDispatch *pObj, LPOLESTR pName);
	//HRESULT InvokeMethod(IDispatch *pObj, LPOLESTR pName, VARIANT *pVarResult, VARIANT *p, int cArgs);
	//HRESULT GetProperty(IDispatch *pObj, LPOLESTR pName, VARIANT *pValue);
	//HRESULT SetProperty(IDispatch *pObj, LPOLESTR pName, VARIANT *pValue);
	
	//void OnDoubleClick(IHTMLEventObj* pEvtObj);

	void OnBeforeNavigate2(DISPPARAMS* pDispParams);
	// void OnCommandStateChange(DISPPARAMS* pDispParams);
	// void OnDocumentBegin(DISPPARAMS* pDispParams);
	// void OnDocumentComplete(DISPPARAMS* pDispParams);
	void OnDocumentComplete(LPDISPATCH pDisp, VARIANT* URL = NULL);
	// void OnDownloadBegin(DISPPARAMS* pDispParams);
	// void OnDownloadComplete(DISPPARAMS* pDispParams);
	void OnNavigateComplete2(DISPPARAMS* pDispParams);
	// void OnNewWindow2(DISPPARAMS* pDispParams);
	// void OnProgressChange(DISPPARAMS* pDispParams);
	// void OnPropertyChange(DISPPARAMS* pDispParams);
	// void OnStatusTextChange(DISPPARAMS* pDispParams);
	// void OnTitleChange(DISPPARAMS* pDispParams);
	
public:
	//interface for dispatch
	STDMETHODIMP Invoke(DISPID dispid, REFIID riid, LCID lcid, WORD wFlags, DISPPARAMS* pdispparams, VARIANT* pvarResult, EXCEPINFO* pexecinfo, unsigned int* puArgErr);
	
	// IUnknown Methods
	STDMETHODIMP QueryInterface(REFIID riid, void** ppvObject);
	STDMETHODIMP_(ULONG) AddRef();
	STDMETHODIMP_(ULONG) Release();

	// IDispatch Methods
	STDMETHODIMP GetIDsOfNames(REFIID riid, OLECHAR** rgszNames, unsigned int cNames, LCID lcid, DISPID* rgdispid);
	STDMETHODIMP GetTypeInfo(unsigned int itinfo, LCID lcid, ITypeInfo** pptinfo);
	STDMETHODIMP GetTypeInfoCount(unsigned int* pctinfo);

	STDMETHODIMP ShowContextMenu(
		/* [in] */ DWORD dwID,
		/* [in] */ POINT *ppt,
		/* [in] */ IUnknown *pcmdtReserved,
		/* [in] */ IDispatch *pdispReserved) {
		return E_NOTIMPL;
	};

	STDMETHODIMP GetHostInfo(
		/* [out][in] */ DOCHOSTUIINFO *pInfo);

	STDMETHODIMP ShowUI(
		/* [in] */ DWORD dwID,
		/* [in] */ IOleInPlaceActiveObject *pActiveObject,
		/* [in] */ IOleCommandTarget *pCommandTarget,
		/* [in] */ IOleInPlaceFrame *pFrame,
		/* [in] */ IOleInPlaceUIWindow *pDoc){
		return E_NOTIMPL;
	};

	STDMETHODIMP HideUI(void){
		return E_NOTIMPL;
	};

	STDMETHODIMP UpdateUI(void) {
		return E_NOTIMPL;
	};

	STDMETHODIMP EnableModeless(
		/* [in] */ BOOL fEnable) {
		return E_NOTIMPL;
	};

	STDMETHODIMP OnDocWindowActivate(
		/* [in] */ BOOL fActivate) {
		return E_NOTIMPL;
	};

	STDMETHODIMP OnFrameWindowActivate(
		/* [in] */ BOOL fActivate) {
		return E_NOTIMPL;
	};

	STDMETHODIMP ResizeBorder(
		/* [in] */ LPCRECT prcBorder,
		/* [in] */ IOleInPlaceUIWindow *pUIWindow,
		/* [in] */ BOOL fRameWindow) {
		return E_NOTIMPL;
	};

	STDMETHODIMP TranslateAccelerator(
		/* [in] */ LPMSG lpMsg,
		/* [in] */ const GUID *pguidCmdGroup,
		/* [in] */ DWORD nCmdID) {
		return E_NOTIMPL;
	};

	STDMETHODIMP GetOptionKeyPath(
		/* [annotation][out] */
		__out  LPOLESTR *pchKey,
		/* [in] */ DWORD dw) {
		return E_NOTIMPL;
	};

	STDMETHODIMP GetDropTarget(
		/* [in] */ IDropTarget *pDropTarget,
		/* [out] */ IDropTarget **ppDropTarget) {
		return E_NOTIMPL;
	};

	STDMETHODIMP GetExternal(
		/* [out] */ IDispatch **ppDispatch) {
		return E_NOTIMPL;
	};

	STDMETHODIMP TranslateUrl(
		/* [in] */ DWORD dwTranslate,
		/* [annotation][in] */
		__in __nullterminated  OLECHAR *pchURLIn,
		/* [annotation][out] */
		__out  OLECHAR **ppchURLOut) {
		return E_NOTIMPL;
	};

	STDMETHODIMP FilterDataObject(
		/* [in] */ IDataObject *pDO,
		/* [out] */ IDataObject **ppDORet) {
		return E_NOTIMPL;
	};

	//STDMETHODIMP GetHostInfo(
	//	/* [out][in] */ DOCHOSTUIINFO *pInfo);

	// IOleCommandTarget Methods
	/* [input_sync] */ HRESULT STDMETHODCALLTYPE QueryStatus(
		/* [unique][in] */ __RPC__in_opt const GUID *pguidCmdGroup,
		/* [in] */ ULONG cCmds,
		/* [out][in][size_is] */ __RPC__inout_ecount_full(cCmds) OLECMD prgCmds[],
		/* [unique][out][in] */ __RPC__inout_opt OLECMDTEXT *pCmdText){
		return OLECMDERR_E_NOTSUPPORTED;
	};

	HRESULT STDMETHODCALLTYPE Exec(
		/* [unique][in] */ __RPC__in_opt const GUID *pguidCmdGroup,
		/* [in] */ DWORD nCmdID,
		/* [in] */ DWORD nCmdexecopt,
		/* [unique][in] */ __RPC__in_opt VARIANT *pvaIn,
		/* [unique][out][in] */ __RPC__inout_opt VARIANT *pvaOut);

private:
	CDictDlg* m_pDialog;
	ULONG		m_cRefs;		// ref count
	//CDictDlg*	m_pSink;		// Send the notifications here
	DWORD		m_eventCookie;		// Token that uniquely identifies this connection
	IHTMLDocument2* m_pDoc;
	tString m_tWord;
	
protected:
	// IHTMLElement* GetElementById(const TCHAR* tszID);
	bool InvokeScript(LPOLESTR strFunc);
	//VARIANT InvokeScript(LPOLESTR strFunc, const CStringArray& paramArray);
	//AttachEvent(_T("ondblclick"), this);
	bool SetInnerHtmlByID(const TCHAR* tszID, const TCHAR* tszHtml);
	
public:
	void ConnectEvents();
	void QueryWord(const TCHAR* tszWord, const TCHAR* tszUrl);
};

#endif //_DICTWEBBROWSER_H_