//GDictBase.h
#ifndef __GDICTBASE__H__
#define __GDICTBASE__H__

#include <string>
#include <tchar.h>
#include "DictBase.h"

using namespace std;

class CDictDlg;

class CGDictBase : public CDictBase
{
public:

	CGDictBase(CDictDlg* pDlg);
	~CGDictBase();

public:

	bool Load(const TCHAR* dictPath, const TCHAR* audioPath);
	void Unload();

	bool QueryWrod(const TCHAR* wd);

	//TCHAR* GetWordList(const TCHAR* wd);
	//TCHAR* GetWordList(const tString word);
	bool GetWordList(const tString word, tString& tFindWord);

	bool DelWord(const TCHAR* wd);
	bool DelAudio(const TCHAR* wd);
	
	bool GetAudioPath(const TCHAR* wd, bool isUs, tString& path);

private:
	bool QueryJson(const TCHAR* dictPath, const TCHAR* wd, TCHAR* jsonURL);
	bool DeleteFile(const TCHAR* file);

private:
	TCHAR m_tszGDictPath1[MAX_PATH];
	//TCHAR m_tszGDictPath2[MAX_PATH];
	TCHAR m_tszAudioPath[MAX_PATH];
	CDictDlg* m_pDlg;
	intptr_t m_hFile;
};

#endif //__GDICTBASE__H__