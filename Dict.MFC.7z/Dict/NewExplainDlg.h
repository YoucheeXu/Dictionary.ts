#pragma once
#include "afxcmn.h"


// CNewWordDlg �Ի���
class CNewExplainDlg : public CDialog
{
	DECLARE_DYNAMIC(CNewExplainDlg)

public:
	CNewExplainDlg(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CNewExplainDlg();

// �Ի�������
	enum { IDD = IDD_DIALOG_NEWEXPLAIN };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	int updateData(void);
	afx_msg void OnBnClickedButtonNext();
	afx_msg void OnBnClickedOk();
	virtual BOOL OnInitDialog();
private:
	//CListCtrl m_ListView_Explain;
public:
	//afx_msg void OnNMDblclkListviewExplain(NMHDR *pNMHDR, LRESULT *pResult);
	//afx_msg void OnHdnItemclickListviewExplain(NMHDR *pNMHDR, LRESULT *pResult);
private:
	// ���ӵ��ʽ��ͼ�����
	int instertExplain(int nItem);
public:
	afx_msg void OnBnClickedButtonAddexplain();
};
