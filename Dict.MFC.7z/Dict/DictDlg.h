// DictDlg.h : ͷ�ļ�
//

#pragma once
#include "afxcmn.h"


// CDictDlg �Ի���
class CDictDlg : public CDialog
{
// ����
public:
	CDictDlg(CWnd* pParent = NULL);	// ��׼���캯��

// �Ի�������
	enum { IDD = IDD_DICT_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ֧��


// ʵ��
protected:
	HICON m_hIcon;

	// ���ɵ���Ϣӳ�亯��
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnNewword();
	afx_msg void OnBnClickedButtonNewword();
	static int _callback_exec(void * notused,int argc, char ** argv, char ** aszColName);
	afx_msg void OnBnClickedButtonQueryword();
private:
	CRichEditCtrl m_RichEdit2_Explain;
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
};
