#pragma once

#include "stdafx.h"
#include "DictDat.h"

class CDict
{
public:
	CDict();
	~CDict();

private:
	CDictDat* m_pWordDat;
	CDictDat* m_pDictDat;

public:
	int loadDict();
	int insertSymbol(char* strWord, char* strSymbol1, char* strSymbol2);
	int queryWord(char* strWord, char* strSymbol1, char* strSymbol2);		//�鵥�ʷ���
	//int queryWord2(char* strTable, char* strWord, char* strResult);		//�鵥��ԭ��

	int createExplainTable(char* strWord);
	int insertExplain(char* strWord, char* strExplain, char* strInstance);	
	int displayExplain(char* strWord,int (*callback)(void*,int,char**,char**));
};