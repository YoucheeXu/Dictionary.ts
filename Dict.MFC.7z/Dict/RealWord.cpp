#include "RealWord.h"

CRealWord::CRealWord()
{
	m_pDictDat = new CDictDat();
	m_pDictDat->loadDict("word.dict");
}

CRealWord::~CRealWord()
{
	delete m_pDictDat;
}

int CRealWord::getRealWord(char* strWord, char* strRealWord)
{
	//
	return -1;

}

//CRealWord::