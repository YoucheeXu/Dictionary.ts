#pragma once

#ifndef _REALWORD_H_
#define _REALWORD_H_

#include "stdafx.h"
#include "DictDat.h"

class CRealWord
{
public:
	CRealWord();
	~CRealWord();
private:
	CDictDat* m_pDictDat;

public:
	int getRealWord(char* strWord, char* strRealWord);

private:
	bool isSpecialVerb1(char* strWord);
	bool isSpecialVerb2(char* strWord);
};

#endif //_REALWORD_H_