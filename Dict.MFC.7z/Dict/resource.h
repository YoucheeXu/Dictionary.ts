//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Dict.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_DICT_DIALOG                 102
#define IDR_MAINFRAME                   128
#define IDR_MENU_MAIN                   129
#define IDM_APP_ABOUT                   139
#define IDD_DIALOG_NEWWORD              140
#define IDD_DIALOG_NEWEXPLAIN           141
#define IDC_EDIT_WORD                   142
#define IDC_EDIT_SYSMBOL1               143
#define IDC_EDIT_SYSMBOL2               144
#define IDC_LISTVIEW_EXPLAIN            145
#define IDC_BUTTON_NEXT                 150
#define IDC_BUTTON_ADD                  151
#define IDC_BUTTON_ADDEXPLAIN           151
#define IDC_STATIC_NO                   1001
#define IDC_EDIT_EXPLAIN                1002
#define IDC_EDIT_INSTANCE               1003
#define IDC_BUTTON_NEWWORD              1004
#define IDC_BUTTON_NEWEXPLAIN           1004
#define IDC_COMBO_WORD                  1005
#define IDC_RICHEDIT2_EXPALIN           1006
#define IDC_BUTTON_QUERYWORD            1007
#define IDM_ADD_EXPLAIN                 32772

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        200
#define _APS_NEXT_COMMAND_VALUE         32773
#define _APS_NEXT_CONTROL_VALUE         1010
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
