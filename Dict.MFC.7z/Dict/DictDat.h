#pragma once

#ifndef _DICTDAT_H_
#define _DICTDAT_H_

#include "stdafx.h"

//
class CDictDat
{
public:
	CDictDat();
	~CDictDat();

private:
	sqlite3 * m_sqlite3DB ; //����sqlite�ؼ��ṹָ��

public:
	int loadDict(char* strDictFile);
	int unloadDict();

	int initBasicDict();	
	int queryWord(char* strWord, char* strSymbol1, char* strSymbol2);		//�鵥�ʷ���
	int queryWord2(char* strTable, char* strWord, char* strResult);		//�鵥��ԭ��
	//int queryExplain(char* strWord, char** strExplain, char** strInstance);
	int displayExplain(char* strWord,int (*callback)(void*,int,char**,char**));

	int insertWord(char* strWord, char* strSymbol1, char* strSymbol2);	//���뵥�ʷ���
	int insertWord2(char* strTable, char* strWord1, char* strWord2);	//���뵥��ԭ��
	int createExplainTable(char* strWord);
	int insertExplain(char* strWord, char* strExplain, char* strInstance);
	int markWord(char* strWord, bool bMark);

private:
	int execSQL(char* sql, int (*callback)(void*,int,char**,char**) );
};

#endif  //_DICTDAT_H_