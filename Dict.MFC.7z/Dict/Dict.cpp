#include "Dict.h"

CDict::CDict()
{
}

CDict::~CDict()
{
}

int CDict::loadDict()
{
	m_pWordDat = new CDictDat();
	m_pWordDat->loadDict("word.dict");
	//m_pWordDat->initBasicDict();
	
	m_pDictDat = new CDictDat();
	m_pDictDat->loadDict("1500.dict");

	return 1;
}

int CDict::insertSymbol(char* strWord, char* strSymbol1, char* strSymbol2)
{
	return m_pWordDat->insertWord(strWord, strSymbol1, strSymbol2);
}

int CDict::queryWord(char* strWord, char* strSymbol1, char* strSymbol2)		//�鵥�ʷ���
{
	int n = m_pWordDat->queryWord(strWord, strSymbol1, strSymbol2);
	return n;
}

int CDict::createExplainTable(char* strWord)
{
	return m_pDictDat->createExplainTable(strWord);
}

int CDict::insertExplain(char* strWord, char* strExplain, char* strInstance)
{
	return m_pDictDat->insertExplain(strWord, strExplain, strInstance);
}

int CDict::displayExplain(char* strWord,int (*callback)(void*,int,char**,char**))
{
	return m_pDictDat->displayExplain(strWord, callback);
}