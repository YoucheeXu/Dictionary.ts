#include "DictDat.h"

CDictDat::CDictDat()
{
	m_sqlite3DB = NULL;
}
CDictDat::~CDictDat()
{
	unloadDict();
}
int CDictDat::loadDict(char* strDictFile)
{
	char *pErrMsg = NULL; //������Ϣ
	//�����ݿ�
	//��Ҫ���� db���ָ���ָ�룬��Ϊ sqlite3_open����ҪΪ���ָ������ڴ棬��Ҫ��dbָ��ָ������ڴ���
	int nResult = sqlite3_open(strDictFile, &m_sqlite3DB);
	if (SQLITE_OK != nResult) 
	{
		fprintf(stderr, "SQL error: %s\n", pErrMsg);
		sqlite3_free(pErrMsg);
	}

	return nResult;
}
int CDictDat::unloadDict()
{
	char *pErrMsg = NULL; //������Ϣ
	//�ر����ݿ�
	int nResult = sqlite3_close( m_sqlite3DB);	
	//if (SQLITE_OK != nResult) 
	//{
	//	fprintf(stderr, "SQL error: %s\n", pErrMsg);
	//	sqlite3_free(pErrMsg);
	//}
	return nResult;
}

int CDictDat::initBasicDict()
{
	char* sql = "CREATE TABLE WordList (Word TEXT PRIMARY KEY, Symbol1 TEXT, Symbol2 TEXT, Mark INTEGER, UNIQUE (Word) )";
	int nResult = execSQL(sql, NULL);

	sql = "CREATE TABLE SpecialVerb1 (Word TEXT PRIMARY KEY, Word2 TEXT, UNIQUE (Word))";
	execSQL(sql, NULL);

	return nResult;
}

//�鵥�ʷ���
int CDictDat::queryWord(char* strWord, char* strSymbol1, char* strSymbol2)
{
	char **dbResult; //�� char **���ͣ�����*��
	int nRow = 0;   //��ѯ����������¼������������У���
	int nColumn = 0;  //���ٸ��ֶΣ������У�
	char *pErrMsg = NULL; //������Ϣ

	char sql[100] = "select * from WordList";
	strcat(sql, " where Word = '");
	strcat(sql, strWord);
	strcat(sql, "'");

	int nResult = sqlite3_get_table(m_sqlite3DB, sql, &dbResult, &nRow, &nColumn, &pErrMsg );
	if( SQLITE_OK == nResult )          //��ѯ�ɹ�
	{
		if(nRow !=0)
		{
			//for( int i=0 ; i<(nRow + 1) * nColumn; i++ )
			//	printf("dbResult[%d] = %s\n", i , dbResult[i] );

			//printf("dbResult = %s\n", dbResult[(nRow + 1) * nColumn-1]);
			strcpy(strSymbol1, dbResult[nRow * nColumn+1]);
			strcpy(strSymbol2, dbResult[nRow * nColumn+2]);
		}
		else
			nResult = -1;
	}
	else
	{
		fprintf(stderr, "SQL error: %s\n", pErrMsg);
		fprintf(stderr, "SQL statement: %s\n", sql);
		sqlite3_free(pErrMsg);
	}

	//������������ݿ��ѯ�Ƿ�ɹ������ͷ� char**��ѯ�����ʹ�� sqlite�ṩ�Ĺ������ͷ�
	sqlite3_free_table( dbResult );
	return nResult;
}

//�鵥��ԭ��
int CDictDat::queryWord2(char* strTable, char* strWord, char* strResult)
{
	char **dbResult; //�� char **���ͣ�����*��
	int nRow = 0;   //��ѯ����������¼������������У���
	int nColumn = 0;  //���ٸ��ֶΣ������У�
	char *pErrMsg = NULL; //������Ϣ

	char sql[100] = "select * from ";
	strcat(sql, strTable);
	strcat(sql, " where Word = '");
	strcat(sql, strWord);
	strcat(sql, "'");

	int nResult = sqlite3_get_table(m_sqlite3DB, sql, &dbResult, &nRow, &nColumn, &pErrMsg);
	if( SQLITE_OK == nResult )          //��ѯ�ɹ�
	{
		if(nRow !=0)
		{
			/*for( int i=0 ; i<(nRow + 1) * nColumn; i++ )
			printf("dbResult[%d] = %s\n", i , dbResult[i] );*/

			//printf("dbResult = %s\n", dbResult[(nRow + 1) * nColumn-1]);
			strcpy(strResult, dbResult[(nRow + 1) * nColumn-1]);
		}
		else
			nResult = -1;
	}
	else
	{
		fprintf(stderr, "SQL error: %s\n", pErrMsg);
		fprintf(stderr, "SQL statement: %s\n", sql);
		sqlite3_free(pErrMsg);
	}

	//������������ݿ��ѯ�Ƿ�ɹ������ͷ� char**��ѯ�����ʹ�� sqlite�ṩ�Ĺ������ͷ�
	sqlite3_free_table( dbResult );
	return nResult;
}

//int CDictDat::queryExplain(char* strWord, char** strExplain, char** strInstance)
//{
//	char **dbResult; //�� char **���ͣ�����*��
//	int nRow = 0;   //��ѯ����������¼������������У���
//	int nColumn = 0;  //���ٸ��ֶΣ������У�
//	char * pErrMsg = NULL; //������Ϣ
//
//	char sql[100];
//	strcpy(sql, "select * from ");
//	strcat(sql, strWord);
//
//	int nResult = sqlite3_get_table(m_sqlite3DB, sql, &dbResult, &nRow, &nColumn, &pErrMsg);
//	if( SQLITE_OK == nResult )
//	{
//		//realloc( strExplain, sizeof(char*)*res.nData );
//		for(int i=0; i<= nRow; i++)
//		{
//			char* str = dbResult[(i + 1) * nColumn];
//			char* str2 = (char*)strExplain[i];
//			strcpy(str2, str);
//			//st
//			strcpy(strExplain[i], dbResult[(i + 1) * nColumn]);
//		}
//	}
//	else
//	{
//		fprintf(stderr, "SQL error: %s\n", pErrMsg);
//		fprintf(stderr, "SQL statement: %s\n", sql);
//		sqlite3_free(pErrMsg);
//		nRow = -1;
//	}
//	sqlite3_free_table(dbResult);
//	return nRow;
//}

int CDictDat::displayExplain(char* strWord,int (*callback)(void*,int,char**,char**))
{
	char * pErrMsg = NULL; //������Ϣ

	char sql[100];
	strcpy(sql, "select * from ");
	strcat(sql, strWord);

	int nResult = sqlite3_exec(m_sqlite3DB, sql, callback, NULL, &pErrMsg);
	if (SQLITE_OK != nResult) 
	{
		fprintf(stderr, "SQL error: %s\n", pErrMsg);
		fprintf(stderr, "SQL statement: %s\n", sql);
		sqlite3_free(pErrMsg);
	}
	return nResult;
}

//���뵥�ʷ���
int CDictDat::insertWord(char* strWord, char* strSymbol1, char* strSymbol2)
{
	char * pErrMsg = NULL; //������Ϣ
	char sql[100];
	//sql = "INSERT INTO WordList (Word, Symbol1, Symbol2, Mark) VALUES (" + strWord + "," + strSymbol1 + "," + strSymbol2 + ",false)";
	//strcpy(sql, "INSERT INTO WordList (Word, Symbol1, Symbol2, Mark) VALUES (NULL,");
	strcpy(sql, "INSERT INTO WordList VALUES('");
	strcat(sql, strWord);
	strcat(sql , "','");
	strcat(sql, strSymbol1);
	strcat(sql, "','");
	strcat(sql, strSymbol2);
	strcat(sql, "',0)");	

	int nResult = sqlite3_exec(m_sqlite3DB, sql, NULL, NULL, &pErrMsg);
	if (SQLITE_OK != nResult) 
	{
		fprintf(stderr, "SQL error: %s\n", pErrMsg);
		fprintf(stderr, "SQL statement: %s\n", sql);
		sqlite3_free(pErrMsg);
	}
	return nResult;
}

//���뵥��ԭ��
int CDictDat::insertWord2(char* strTable, char* strWord1, char* strWord2)
{
	char * pErrMsg = NULL; //������Ϣ
	char sql[100];
	//sql = "INSERT INTO strTable VALUES (" + strWord + "," + strSymbol1 + "," + strSymbol2 + ",false)";
	strcpy(sql, "INSERT INTO "); 
	strcat(sql, strTable);
	strcat(sql, " VALUES('");
	strcat(sql, strWord1);
	strcat(sql, "','");
	strcat(sql, strWord2);
	strcat(sql, "')");	

	int nResult = sqlite3_exec(m_sqlite3DB, sql, NULL, NULL, &pErrMsg);
	if (SQLITE_OK != nResult) 
	{
		fprintf(stderr, "SQL error: %s\n", pErrMsg);
		fprintf(stderr, "SQL statement: %s\n", sql);
		sqlite3_free(pErrMsg);
	}
	return nResult;
}

int CDictDat::createExplainTable(char* strWord)
{
	char * pErrMsg = NULL; //������Ϣ
	char sql[100];

	//���ͱ� 
	//id  ע��  ����	
	//sql = "CREATE TABLE strWord (id INTEGER PRIMARY KEY, Explain TEXT NOT NULL COLLATE NOCASE, Instance TEXT NOT NULL COLLATE NOCASE )";

	strcpy(sql, "CREATE TABLE ");
	strcat(sql, strWord);
	strcat(sql, " (Explain TEXT PRIMARY KEY, Instance TEXT)");	
	//strcat(sql, " (Explain TEXT PRIMARY KEY, Instance TEXT)");	

	int nResult = sqlite3_exec(m_sqlite3DB, sql, NULL, NULL, &pErrMsg);
	if (SQLITE_OK != nResult) 
	{
		fprintf(stderr, "SQL error: %s\n", pErrMsg);
		fprintf(stderr, "SQL statement: %s\n", sql);
		sqlite3_free(pErrMsg);		
	}
	return nResult;
}

int CDictDat::insertExplain(char* strWord, char* strExplain, char* strInstance)
{
	char * pErrMsg = NULL; //������Ϣ
	char sql[400];

	//sql = "INSERT INTO Word (Explain, Instance) VALUES (strExplain, strInstance)";
	
	strcpy(sql, "INSERT INTO ");
	strcat(sql, strWord);
	strcat(sql, " VALUES ('");
	strcat(sql, strExplain);
	strcat(sql, "','");
	strcat(sql, strInstance);
	strcat(sql, "')");	

	//fprintf(stderr, "SQL statement: %s\n", sql);

	int nResult = sqlite3_exec(m_sqlite3DB, sql, NULL, NULL, &pErrMsg);
	if (SQLITE_OK != nResult) 
	{
		fprintf(stderr, "SQL error: %s\n", pErrMsg);
		fprintf(stderr, "SQL statement: %s\n", sql);
		sqlite3_free(pErrMsg);
	}
	return nResult; 
}

int CDictDat::markWord(char* strWord, bool bMark)
{
	char* pErrMsg = NULL; //������Ϣ
	char* sql = "UPDATE WordList SET Mark = bMark WHERE Word = strWord";
	int nResult=sqlite3_exec(m_sqlite3DB, sql, NULL, NULL, &pErrMsg);
	if (SQLITE_OK != nResult) 
	{
		fprintf(stderr, "SQL error: %s\n", pErrMsg);
		fprintf(stderr, "SQL statement: %s\n", sql);
		sqlite3_free(pErrMsg);
	}
	return nResult;
}

int CDictDat::execSQL(char* sql, int (*callback)(void*,int,char**,char**) )
{
	char *pErrMsg = NULL; //������Ϣ

	int nResult = sqlite3_exec(m_sqlite3DB, sql, callback, NULL, &pErrMsg);
	if (SQLITE_OK != nResult) 
	{
		fprintf(stderr, "SQL error: %s\n", pErrMsg);
		fprintf(stderr, "SQL statement: %s\n", sql);
		sqlite3_free(pErrMsg);
	}
	return nResult;
}