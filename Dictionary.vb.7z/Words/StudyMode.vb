﻿Public Class CStudyMode
    Property mWordList As String()
    Property mNewWordList As String()
	Private mTarget As String
    Private mOrder As Integer = 1
	Private mLimit As Integer = 1
	Private mNum1 As Integer = 1
    Private mNum2 As Integer = 0
	'to test
    Sub New(Byval target As String)

        Dim wdlist As String = ""
        Dim wdlists As String = ""
        mTarget = target
        'get strange words
        frmWords.mDict.GetWordListLessMark(-1, wdlist)
        wdlists = wdlists + wdlist
        'get Ebbinghaus memory curve words
        GetEbbinghausWords(wdlist)
        wdlists = wdlists + wdlist
		
		Dim words() As String = wdlists.Split("@")
		If words.length >= 1 Then
			ReDim mWordList(words.Length)
			mWordList = words
		End If
			
        'get new words
        mLimit = frmWords.mIniFile.GetInteger("StudyMode", "limit")
        mOrder = frmWords.mIniFile.GetInteger("StudyMode", "order")
        GetNewwords(wdlist)
		
		Dim words2() As String = wdlist.Split("@")
		If words2.length >= 1 Then
            ReDim mNewWordList(words2.Length)
			mNewWordList = words2
		End If
	
    End Sub
	'to test
    Private Function GetNextWord() As String

        If mWordList.Length > 1 And mNum1 < mWordList.Length Then
            mNum1 = mNum1 + 1
            Return mWordList(mNum1 - 2)
        End If

        frmWords.mIniFile.SetInteger("StudyMode", "order", mOrder + mNum2)
        If mNewWordList.Length > 1 And mNum2 < mNewWordList.Length Then
            mNum2 = mNum2 + 1
            Return mNewWordList(mNum2 - 1)
        End If

        Return ""
    End Function
	'to test
    Private Function GetEbbinghausWords(ByRef wdlists As String) As Integer
        Dim wdlist As String = ""
        Dim time4, time5, time6, time7, time8 As Integer
        Dim curTime, time As DateTime
        curTime = DateTime.Now
        
        'get Ebbinghaus time4 words
		time4 = frmWords.mIniFile.GetInteger("StudyMode", "time4")
        time = curTime.AddDays(time4)
        time4 = Convert.ToInt32(time.ToString("yyyyMMdd"))
        frmWords.mDict.GetWordListByTime(time4, wdlist)
        wdlists = wdlists + wdlist
        'get Ebbinghaus time5 words
		time5 = frmWords.mIniFile.GetInteger("StudyMode", "time5")
        time = curTime.AddDays(time5)
        time5 = Convert.ToInt32(time.ToString("yyyyMMdd"))
        frmWords.mDict.GetWordListByTime(time5, wdlist)
        wdlists = wdlists + wdlist
        'get Ebbinghaus time6 words
		time6 = frmWords.mIniFile.GetInteger("StudyMode", "time6")
        time = curTime.AddDays(time6)
        time6 = Convert.ToInt32(time.ToString("yyyyMMdd"))
        frmWords.mDict.GetWordListByTime(time6, wdlist)
        wdlists = wdlists + wdlist
        'get Ebbinghaus time7 words
		time7 = frmWords.mIniFile.GetInteger("StudyMode", "time7")
        time = curTime.AddDays(time7)
        time7 = Convert.ToInt32(time.ToString("yyyyMMdd"))
        frmWords.mDict.GetWordListByTime(time7, wdlist)
        wdlists = wdlists + wdlist
        'get Ebbinghaus time8 words
		time8 = frmWords.mIniFile.GetInteger("StudyMode", "time8")
        time = curTime.AddDays(time8)
        time8 = Convert.ToInt32(time.ToString("yyyyMMdd"))
        frmWords.mDict.GetWordListByTime(time8, wdlist)
        wdlists = wdlists + wdlist
        Return wdlists.Length
    End Function
    'to test
    Private Function GetNewwords(ByRef wdlist As String) As Integer
        'Throw New NotImplementedException
        Dim total = frmWords.mIniFile.GetInteger("StudyMode", "total")
        Dim n As Integer = 0
		If mOrder <= total Then
            Dim lstFile As String = frmWords.mDictPath + mTarget + ".lst"
            Dim line As String
			Dim ReadStream As New System.IO.StreamReader(lstFile, System.Text.Encoding.Default)
			If ReadStream IsNot Nothing Then
				Do Until ReadStream.EndOfStream
					line = ReadStream.ReadLine()
					Dim wordLine() As String = line.Split(Chr(9))    'tab
					'ReDim wdlist(mLimit)
                    For i = mOrder To mLimit + mOrder - 1
                        wdlist = wdlist + wordLine(i - 1) + "@"
                        n = n + 1
                    Next
				Loop
				ReadStream.Close()
			End If
		End If
        Return n
    End Function

    Public Function GoNext() As Boolean
        Dim word As String = GetNextWord()
        frmWords.mWord = word
        If word.Length >= 1 Then

            frmWords.labWord.Text = word
            If frmWords.mDict.ExistWord(word) Then
                frmWords.rtxDefinition.Text = frmWords.mDict.mContent
                frmWords.labSymbol.Text = frmWords.mDict.mSymbol
            End If
            Call frmWords.Pronounce(word)

        Else
            Call frmWords.ShowTestMode()
        End If
        Return True
    End Function
End Class