﻿Imports System.Data.SQLite
'
Public Class CWordsLibrary
    Private mConnection As SQLiteConnection
    Private mDictName As String
    Property mWord As String
    Property mSymbol As String
    Property mContent As String
    Property mMark As Integer
    Property mTime As Integer

    Sub New()
        mConnection = New SQLiteConnection
        mDictName = ""
    End Sub

    Protected Overrides Sub Finalize()
        '此处放入要执的代码
        'm_connn.Close()
        MyBase.Finalize() ' Call Finalize on the base class.
    End Sub

    Public Function LoadDict(ByVal name As String) As Boolean
        Dim newdict As Boolean = False
        mDictName = name
        name = name + ".dict"
        mConnection.ConnectionString = "Data Source =" + name
        Try
            'Dim objFile As System.IO.File
            If Not IO.File.Exists(name) Then
                'm_connn.Open()
                newdict = True
            End If
            mConnection.Open()
            If newdict = True Then
                For n = 97 To 122
                    CreateTabel(Chr(n))
                    Debug.Print(Chr(n))
                Next
                Call BuildLibrary()
            End If
        Catch ex As Exception
            MessageBox.Show(ex.ToString)
        End Try
        Return True
    End Function

    Public Sub UnloadDict()
        mConnection.Close()
    End Sub
	'to test
    Private Function CreateTabel(ByVal letter As Char) As Boolean
        Dim cmd As SQLiteCommand = mConnection.CreateCommand

        cmd.CommandText = "CREATE TABLE " + letter + " (" + _
            "Word TEXT NOT NULL PRIMARY KEY, Symbol TEXT NOT NULL , Content TEXT NOT NULL , Time INTEGER NOT NULL, Mark INTEGER NOT NULL)"
        Try
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            MessageBox.Show(ex.ToString)
            Return False
        End Try
        Return True
    End Function
	'to test
    Private Function InsertContent(ByVal word As String, ByVal symbol As String, ByVal content As String, ByVal time As Integer, ByVal mark As Integer)

        Dim cmd As SQLiteCommand = mConnection.CreateCommand

        Dim table As String = word.Substring(0, 1)

        symbol = symbol.Replace("'", "''")
        content = content.Replace("'", "''")

        Dim sql As String = "INSERT INTO " + table
        sql = sql + " VALUES ('"
        sql = sql + word + "', '"
        sql = sql + symbol + "', '"
        sql = sql + content + "', '"
        sql = sql + time.ToString + "', '"
        sql = sql + mark.ToString
        sql = sql + "')"
        cmd.CommandText = sql
        Try
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            MessageBox.Show(ex.ToString)
            Return False
        End Try
        Return True
    End Function
    'to-test
    Private Sub BuildLibrary()
        Dim txtFile As String = mDictName + ".txt"
        Dim line, word, symbol, content As String
        Dim ReadStream As New System.IO.StreamReader(txtFile, System.Text.Encoding.UTF8)
        If ReadStream IsNot Nothing Then
            Do Until ReadStream.EndOfStream
                line = ReadStream.ReadLine()
                Dim txtLine() As String = line.Split(Chr(9))    'tab
                word = txtLine(0)
                Console.WriteLine(word)
                symbol = txtLine(1)
                content = txtLine(2)
                InsertContent(word, symbol, content, 0, 0)
            Loop
            ReadStream.Close()
        End If
        'Throw New NotImplementedException
    End Sub

    Private Function GetContent(ByVal wd As String) As Boolean
        Dim cmd As SQLiteCommand = mConnection.CreateCommand
        Dim dbReader As SQLiteDataReader

        cmd.CommandText = "select * from " + wd.Substring(0, 1) + " where Word='" + wd + "'"

        Try
            dbReader = cmd.ExecuteReader

            If dbReader.Read Then
                mSymbol = dbReader.Item(1)
                'mDefinition = dbReader.Item(2)
                'mSentence = dbReader.Item(3)
                mContent = dbReader.Item(2)
                mTime = dbReader.Item(3)
                mMark = dbReader.Item(4)
                Return True
            Else
                Return False
            End If

        Catch ex As Exception
            MessageBox.Show(ex.ToString)
            Return False
        End Try

    End Function

    Function ExistWord(ByVal wd As String) As Boolean
        'Throw New NotImplementedException
        Return GetContent(wd)
    End Function

    Public Function UpdateMark(ByVal wd As String, ByVal mark As Integer) As Boolean
        Dim cmd As SQLiteCommand = mConnection.CreateCommand

        cmd.CommandText = "UPDATE " + wd.Substring(0, 1) + " SET Mark = '" + mark.ToString + "' WHERE Word ='" + wd + "'"

        Try
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            MessageBox.Show(ex.ToString)
            Return False
        End Try
        Return True
    End Function
	'to test
    Public Function UpdateTime(ByVal wd As String, ByVal time As Integer) As Boolean
        Dim cmd As SQLiteCommand = mConnection.CreateCommand

        cmd.CommandText = "UPDATE " + wd.Substring(0, 1) + " SET Time = '" + time.ToString + "' WHERE Word ='" + wd + "'"

        Try
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            MessageBox.Show(ex.ToString)
            Return False
        End Try
        Return True
    End Function

	'to test
    Public Function GetWordListByTime(ByVal mark As Integer, ByRef wdlist As String) As Boolean
        Dim cmd As SQLiteCommand
        Dim dbReader As SQLiteDataReader
        Dim n As Integer = 0
        For i = 97 To 122
            cmd = mConnection.CreateCommand
            cmd.CommandText = "select Word from " + Chr(i) + " where Time = '" + mark.ToString + "'"

            Try
                dbReader = cmd.ExecuteReader

                While dbReader.Read
                    wdlist = wdlist + dbReader.Item(0) + "@"
                    n = n + 1
                End While
            Catch ex As Exception
                MessageBox.Show(ex.ToString)
                Return False
            End Try
        Next

        If n > 0 Then
            Return True
        Else
            Return False
        End If
    End Function
	'to test
    Public Function GetWordListLessMark(ByVal mark As Integer, ByRef wdlist As String) As Boolean
        Dim cmd As SQLiteCommand
        Dim dbReader As SQLiteDataReader
        Dim num As Integer = 0
        For i = 97 To 122
            For n = -10 To mark - 1
                cmd = mConnection.CreateCommand
                cmd.CommandText = "select Word from " + Chr(i) + " where Mark = '" + n.ToString + "'"
                Try
                    dbReader = cmd.ExecuteReader

                    While dbReader.Read
                        wdlist = wdlist + dbReader.Item(0) + "@"
                        num = num + 1
                    End While
                Catch ex As Exception
                    MessageBox.Show(ex.ToString)
                    Return False
                End Try
            Next
        Next

        If num > 0 Then
            Return True
        Else
            Return False
        End If
    End Function

End Class