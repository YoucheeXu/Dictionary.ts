﻿Imports System
Imports System.Drawing
Imports System.Runtime.InteropServices 'dllimport

Public Class frmWords

    Property mDictPath() As String = Application.StartupPath + "\Dict\"
    Property mSkinPath() As String = Application.StartupPath + "\Skin\"
    Property mDataPath() As String = Application.StartupPath + "\Data\"
    Property mGDictPath() As String = mDictPath + "\Google\"
    Property mGAudioPath() As String = Application.StartupPath + "\Audio\Google\"

    Property mWord As String = "Start"
    Property mDict As CWordsLibrary
    Property mIniFile As CIniFile

    Private mTTS As New Speech.Synthesis.SpeechSynthesizer

	Property mStudyMode As CStudyMode
    Property mTestMode As CTestMode

    Property mIsTestMode As Boolean = False

    'Private fullnow As Boolean
    Private rect As Rectangle
    Public Const SPI_GETWORKAREA As Integer = &H30
    Public Const SPI_SETWORKAREA As Integer = &H2F
    Public Const SPIF_UPDATEINIFILE As Integer = 1
    Public Const SW_HIDE As Integer = 0
    Public Const SW_SHOW As Integer = 5
    <DllImport("user32")> _
    Private Shared Function FindWindow(ByVal lpClassName As String, ByVal lpWindowName As String) As Integer
    End Function
    <DllImport("user32")> _
    Public Shared Function ShowWindow(ByVal hwnd As Integer, ByVal nCmdShow As Integer) As Integer
    End Function
    <DllImport("user32")> _
    Private Shared Function SystemParametersInfo(ByVal uAction As Integer, ByVal uParam As Integer, ByRef lpvParam As Rectangle, ByVal fuWinIni As Integer) As Integer
    End Function

    Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        mIniFile = New CIniFile
        mIniFile.mIniFilePath = mDataPath + "Words.ini"
        mDict = New CWordsLibrary
        Dim target As String = mIniFile.GetString("Words", "target")
        mDict.LoadDict(mDictPath + target)
		mStudyMode = New CStudyMode(target)
        mTestMode = New CTestMode
        Call ShowStudyMode()
        Call ToggleFullScreen(True)

        'Call ShowTestMode()
        'frmStudyMode.ShowDialog(Me)
    End Sub

    Private Sub frmMain_FormClosing(ByVal sender As System.Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        Call ToggleFullScreen(False)
        mDict.UnloadDict()
    End Sub

    Private Sub frmMain_KeyDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyDown
        'If e.KeyCode = Keys.Escape Then
        '    Me.Close()
        'End If
        Select Case e.KeyCode
            Case Keys.Escape
                Me.Close()
            Case Keys.Enter
                If mIsTestMode = True Then
                    If TxtWord.Text = "" Then
                        TxtWord.Text = "@"
                    End If
                    Call mTestMode.GoNext()
                End If
        End Select

    End Sub

    Private Shared Function SetFullScreen(ByVal fullscreen As Boolean, ByRef rectOld As Rectangle) As Boolean
        Dim Hwnd As Integer = frmWords.FindWindow("Shell_TrayWnd", Nothing)
        If (Hwnd = 0) Then
            Return False
        End If
        If fullscreen Then
            frmWords.ShowWindow(Hwnd, 0)
            Dim rectFull As Rectangle = Screen.PrimaryScreen.Bounds
            frmWords.SystemParametersInfo(&H30, 0, (rectOld), 1)
            frmWords.SystemParametersInfo(&H2F, 0, (rectFull), 1)
        Else
            frmWords.ShowWindow(Hwnd, 5)
            frmWords.SystemParametersInfo(&H2F, 0, (rectOld), 1)
        End If
        Return True
    End Function

    Public Sub ToggleFullScreen(ByVal fullnow As Boolean)

        frmWords.SetFullScreen(fullnow, (Me.rect))
        Me.FormBorderStyle = IIf(fullnow, FormBorderStyle.None, FormBorderStyle.FixedDialog)
        Me.WindowState = IIf(fullnow, FormWindowState.Maximized, FormWindowState.Normal)
    End Sub

    'Private Sub WordBrowser_DocumentCompleted3(ByVal sender As System.Object, ByVal e As System.Windows.Forms.WebBrowserDocumentCompletedEventArgs)
    '    Dim word_Item As HtmlElement = WordBrowser.Document.GetElementById("queryword")
    '    If word_Item = Nothing Then Return
    '    word_Item.InnerHtml = mWord
    '    'Call QueryGDict(mWord)
    '    WordBrowser.Document.InvokeScript("google_search")
    '    'OnHoverSpeech(mWord, True)

    'End Sub

    Public Sub Pronounce(ByVal word As String)
        Dim voicefile2 As String = mGAudioPath + word.Trim + ".mp3"
        If IO.File.Exists(voicefile2) Then
            WordPlayer.URL = voicefile2
            WordPlayer.Ctlcontrols.play()
        Else
            mTTS.Speak(word)
        End If
    End Sub

    'Private Sub ShowWord(ByVal word As String)

    '    'With WordBrowser
    '    '    .Left = 1
    '    '    .Width = 699
    '    '    .Update()
    '    'End With

    '    'WordBrowser.Navigate(mDataPath + "Query\dict.html")

    'End Sub
    'to test
    Public Sub ShowStudyMode()
        Dim anchorX As Integer = 565
        Dim anchorY As Integer = 250
        Dim x As Integer = 0
        Dim y As Integer = 0

        labWord.Location = New Point(anchorX, anchorY)
        labWord.Show()

        x = labWord.Location.X + labWord.Size.Width + 40
        y = labWord.Location.Y + labWord.Size.Height / 2
        btnPronounce.Location = New Point(x, y)
        btnPronounce.Show()

        x = btnPronounce.Location.X + btnPronounce.Size.Width + 5
        y = btnPronounce.Location.Y
        labSymbol.Location = New Point(x, y)
        labSymbol.Show()
        'WordBrowser.Show()

        rtxDefinition.Location = New Point(anchorX, anchorY + 40)
        rtxDefinition.Show()

        BtnForget.Location = New Point(anchorX, anchorY + 140)

        BtnFamiliar.Location = New Point(anchorX + 70, anchorY + 140)
        BtnFamiliar.Show()

        BtnNext.Location = New Point(anchorX + 140, anchorY + 140)
        BtnNext.Show()

        TxtWord.Hide()
        BtnTip.Hide()
        BtnFinish.Hide()

        WordPlayer.Hide()

        Call mStudyMode.GoNext()
        'Call ShowTestMode()

    End Sub

	'to do
    Public Sub ShowTestMode()
        Dim anchorX As Integer = 565
        Dim anchorY As Integer = 250
        labWord.Hide()
        labSymbol.Hide()

        btnPronounce.Location = New Point(anchorX, anchorY)
        btnPronounce.Show()

        TxtWord.Location = New Point(anchorX, anchorY + 40)
        TxtWord.Show()

        BtnTip.Location = New Point(anchorX, anchorY + 80)
        BtnTip.Show()

        BtnFinish.Location = New Point(anchorX + 120, anchorY + 80)
        BtnFinish.Show()

        'WordBrowser.Hide()
        rtxDefinition.Location = New Point(anchorX, anchorY + 140)
        'rtxDefinition.Text = "Call Pronounce(mWord)"
        rtxDefinition.Hide()

        BtnForget.Hide()
        BtnFamiliar.Hide()
        BtnNext.Hide()

        WordPlayer.Hide()

        mIsTestMode = True
        Call mTestMode.GoNext()
        'Me.Close()
    End Sub

    Public Function ShowTip() As Boolean
        rtxDefinition.Show()
        rtxDefinition.Text = mDict.mContent
        Call Pronounce(mWord)
        Return True
    End Function
    Private Sub BtnPronounce_Click(sender As Object, e As EventArgs) Handles btnPronounce.Click
        Call Pronounce(mWord)
    End Sub

    Private Sub BtnForget_Click(sender As Object, e As EventArgs) Handles BtnForget.Click
        'Dim mark As Integer = mCET4Dict.GetMark(mWord)
        Dim curTime As DateTime = DateTime.Now
        Dim time As Integer = Convert.ToInt32(curTime.ToString("yyyyMMdd"))
        mDict.UpdateTime(mWord, time)
        mDict.UpdateMark(mWord, -5)
        Call mStudyMode.GoNext()
    End Sub

    Private Sub BtnNext_Click(sender As Object, e As EventArgs) Handles BtnNext.Click
        Call mStudyMode.GoNext()
    End Sub

    Private Sub BtnFamiliar_Click(sender As Object, e As EventArgs) Handles BtnFamiliar.Click
        'Dim mark As Integer = mCET4Dict.GetMark(mWord)
        Dim curTime As DateTime = DateTime.Now
        Dim time As Integer = Convert.ToInt32(curTime.ToString("yyyyMMdd"))
        mDict.UpdateTime(mWord, time)
        mDict.UpdateMark(mWord, 5)
        Call mStudyMode.GoNext()
    End Sub

    Private Sub BtnTip_Click(sender As Object, e As EventArgs) Handles BtnTip.Click
        Call ShowTip()
    End Sub

    Private Sub BtnFinish_Click(sender As Object, e As EventArgs) Handles BtnFinish.Click

        If TxtWord.Text = "" Then
            TxtWord.Text = "@"
        End If
        Call mTestMode.GoNext()
    End Sub
End Class