﻿'Property mWordDict() As CDataBase
'Property m1500Dict() As CDataBase
'Property mBasicDict() As CDataBase2
'Property mDict2() As CMDBDataBase

'Property mFrmGrab As New GrabForm()

'Private nPreMouseX As Integer = 0
'Private nPreMouseY As Integer = 0

'Private WithEvents GloablMouseHook As New SystemHook(False, True)

'm1500Dict = New CDataBase
'm1500Dict.LoadDict(mDictPath + "1500.dict")
'mBasicDict = New CDataBase2
'mBasicDict.LoadDict(mDictPath + "basic.dict")
	
'mWordDict.UnloadDict()
'm1500Dict.UnloadDict()
'mDict2.UnloadDict()
'mBasicDict.UnloadDict()

'another change
'Private Sub DataWebBrowser_Navigating(ByVal sender As System.Object, ByVal e As System.Windows.Forms.WebBrowserNavigatingEventArgs) Handles DataWebBrowser.Navigating
'    Dim str() As String = e.Url.ToString().Split(":")
'    Dim id As String = " "
'    If (str(0) = "app") Then
'        Select Case str(1)
'            Case "remind"
'                'System.Diagnostics.
'            Case "detail"
'                'Dim HTML As System.Windows.Forms.HtmlDocument = DataWebBrowser.Document
'                'Dim doc As mshtml.IHTMLDocument2 = HTML.DomDocument
'                'Dim htm As String = ""
'                'If GetMore(str(2).Trim, htm) Then
'                '    doc.activeElement.parentElement.parentElement.outerHTML = htm
'                'End If
'                mMore = True
'                mFocus = True
'                DataWebBrowser.Navigate(mDataPath + "ResultHtml\result.html")
'        End Select

'        WordTxtBox.Focus()

'        e.Cancel = True
'    ElseIf str(0) = "file" Then
'        id = DataWebBrowser.Document.ActiveElement.Id
'        Select Case id
'            Case "opendictmgr"
'            Case "opensetting"
'            Case "opennewword"
'                frmNewWords.ShowDialog()
'        End Select
'    End If
'End Sub

'Private Function QueryDict(ByVal wd As String, ByRef smb As String, ByRef ct As String) As Boolean
'    Dim tp As String = ""
'    Dim n As Integer = 0
'    Dim i As Integer = 0
'    If m1500Dict.GetContent(wd, ct, tp) Then
'        Dim ctlist() As String = ct.Split("@")
'        Dim tplist() As String = tp.Split("@")
'        ct = ""
'        For Each Type In tplist
'            If Type.Length > 0 Then
'                Select Case Convert.ToInt32(Type)
'                    Case 1
'                        ct = ct + "<DIV class=pos>" + (i + 1).ToString + "." + ctlist(n) + "</DIV> "
'                        i += 1
'                    Case 0
'                        ct = ct + "<DIV class=pos>&nbsp;&nbsp;" + ctlist(n) + "</DIV> "
'                End Select
'                n += 1
'            End If
'        Next
'    End If
'    Return True
'End Function


'Private Function QueryDict2(ByVal wd As String, ByRef smb As String, ByRef ct As String) As Boolean
'    Dim mp3path As String = ""
'    Dim xmlPath As String = "http://dict.cn/ws.php?utf8=true&q=" & wd.Trim
'    mVoice = False
'    wd = wd.Trim
'    If mBasicDict.ExistWord(wd) Then
'        smb = mBasicDict.GetSymbol()
'        ct = mBasicDict.GetExplain()
'        mp3path = mBasicDict.GetVoice()
'        ct = ct.Replace(vbLf, "<BR>")
'    ElseIf SystemInformation.Network And mMore Then
'        Dim dSet As New DataSet
'        Dim dRow As DataRow

'        Try
'            dSet.ReadXml(xmlPath)
'            dRow = dSet.Tables(0).Rows(0)
'            If dSet Is Nothing Then
'                Return False
'                'Exit Function
'            End If
'            If dSet.Tables(0).TableName = "dict" Then
'                'If dRow.Item("def") = "Not Found" Then
'                '    'MsgBox("未能找到单词:" & Me.txtWord.Text.Trim & vbCrLf & "请确认拼写正确")
'                '    Return False
'                '    'Exit Function
'                'End If
'                ct = IIf(IsDBNull(dRow.Item("def")), "", dRow.Item("def"))
'                smb = "[" + IIf(IsDBNull(dRow.Item("pron")), "", dRow.Item("pron")) + "]"
'                mp3path = IIf(IsDBNull(dRow.Item("audio")), "", dRow.Item("audio"))
'                dSet.Dispose()
'                mBasicDict.InsertContent(wd, smb, ct, mp3path, True)
'                ct = ct.Replace(vbLf, "<BR>")
'            Else
'                Return False
'            End If
'        Catch ex As Exception
'            'MessageBox.Show(ex.ToString)
'            Return False
'        End Try
'    End If
'    Dim voice As String = mAudioPath + wd.Trim + ".mp3"
'    Dim xml As String = mXMLPath + wd.Trim + ".xml"

'    If System.IO.File.Exists(voice) = False And SystemInformation.Network Then
'        Dim myWebClient = New System.Net.WebClient
'        myWebClient.DownloadFile(New Uri(mp3path), voice)
'        myWebClient.DownloadFile(New Uri(xmlPath), xml)
'    End If

'    If System.IO.File.Exists(voice) = True Then
'        mVoice = True
'    End If

'    AxWindowsMediaPlayer1.URL = voice
'    AxWindowsMediaPlayer1.Ctlcontrols.play()

'    Return True
'End Function

	'Private Sub OnGlobalMouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles GloablMouseHook.MouseActivity
'    'MessageBox.Show("MouseMove")
'    'If e.Clicks = 1 Then
'    '    MessageBox.Show("Singel Click")
'    'End If
'    If (Math.Abs(nPreMouseX - e.X) > 5 Or Math.Abs(nPreMouseY - e.Y) > 5) Then
'        GrabForm.Hide()
'    End If

'    nPreMouseX = e.X
'    nPreMouseY = e.Y
'    If e.Clicks = 2 And e.Button = Windows.Forms.MouseButtons.Left Then
'        'MessageBox.Show("DoubleClick:" + e.Clicks.ToString)
'        'My.Computer.Clipboard.Clear()
'        System.Windows.Forms.SendKeys.SendWait("^F")
'        'System.Windows.Forms.SendKeys.SendWait("^c")
'        'MainTimer.Interval = 1000
'        'MainTimer.Enabled = True
'        Debug.Print("LeftDoubleClick:" + My.Computer.Clipboard.GetText)
'        'If My.Computer.Clipboard.ContainsText Then
'        '    MessageBox.Show(My.Computer.Clipboard.GetText)
'        '    'GrabForm.Location = New Point(e.X + 5, e.Y + 5)
'        '    'GrabForm.m_Word = My.Computer.Clipboard.GetText
'        '    'GrabForm.Show()
'        '    My.Computer.Clipboard.Clear()
'        'End If
'    End If
'End Sub

'Public Sub OnClickMore(ByVal what As String)
'    MessageBox.Show(what)
'    Select Case what
'        Case "NetDes" '展开更多解释
'        Case "SyncAnt" '展开更多同反义词
'        Case "Related"    '展开更多相关词组
'    End Select
'End Sub

'OnClickTitle(ByVal id As String)
'OnClickDictHeader(rect.left, rect.top + height, idx)
'OnClickFold("fold")
'OnClickFold("unfold")

'Private Sub MainTimer_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MainTimer.Tick
'    'MessageBox.Show("OK")
'    'GrabForm.Hide()
'    'MainTimer.Enabled = False
'End Sub

	
'convert database0 to database1
'Private Sub ConvertDataBase()
'	Dim wordlist As String = ""
'       Dim n As Integer = 0
'       Dim ct As String = ""
'       Dim tp As String = ""
'       Dim def As String = ""
'       Dim sent As String = ""

'	Dim VOADict As New CDataBase1
'       VOADict.LoadDict(mDictPath + "VOA.dict")

'       If m1500Dict.GetWordList("c", wordlist) Then
'           Dim wdlst() As String = wordlist.Split("@")
'           Dim oldWd As String = ""
'           For Each wd In wdlst
'               If wd <> oldWd Then
'                   ct = ""
'                   tp = ""
'                   If m1500Dict.GetContent(wd, ct, tp) Then
'                       Dim ctlst() As String = ct.Split("@")
'                       Dim tplst() As String = tp.Split("@")
'                       n = 0
'                       For Each type In tplst
'                           If type.Length > 0 Then
'                               Select Case Convert.ToInt32(type)
'                                   Case 1
'                                       def = ctlst(n)
'                                   Case 0
'                                       sent = ctlst(n)
'                                       VOADict.InsertContent(wd, def, sent)
'                               End Select
'                           End If
'                           n += 1
'                       Next
'                   End If
'               End If
'               oldWd = wd
'           Next
'       End If

'       VOADict.UnloadDict()
'End Sub

Private Function GetMore0(ByVal wd As String, ByRef htm As String, ByRef bNew As Boolean) As Boolean
	Dim symbol As String = ""
	Dim content As String = ""
	QueryDict1(wd, symbol, content)
	htm = GetHtm(wd, symbol, content, bNew)
	If content.Length <= 1 Then
		Return False
	Else
		Return True
	End If
End Function


Private Sub DataWebBrowser_DocumentCompleted(ByVal sender As System.Object, ByVal e As System.Windows.Forms.WebBrowserDocumentCompletedEventArgs) Handles DataWebBrowser.DocumentCompleted
	Dim NewWordCnt_Item As HtmlElement

	If mResult = False Then
		NewWordCnt_Item = DataWebBrowser.Document.GetElementById("NewWordCnt")
		If NewWordCnt_Item <> Nothing Then
			NewWordCnt_Item.InnerHtml = "<img style='vertical-align:top;' src='./hp_img/notify.png'/>" _
			 + "今天要复习<a target='_self' href='app:remind'>" + mNumNewwords.ToString + "</a>个单词"
		End If
End Sub

'Private Function GetMore2(ByVal wd As String, ByVal symbol As String, ByVal def As String, ByVal sent As String, ByVal bnew As Boolean) As String
'    If symbol <> Nothing Then
'        Dim symbols() As String = symbol.Split("&")
'        Dim sound_EN As String =
'            "<SPAN class='symbol' id=voice0 style='MARGIN-LEFT: 5px; VERTICAL-ALIGN: middle' qvalue='" + wd + "' onclick=onVoice(this,0); >" + _
'            "<IMG style='CURSOR:hand' src='images/Voice_1.png'" + _
'            "onmouseup=""this.src='images/Voice_1.png'"" onmousedown=""this.src='images/Voice_2.png'""/>" + _
'            "</SPAN>"
'        Dim sound_US As String =
'            "<SPAN class='symbol' id=voice0 style='MARGIN-LEFT: 5px; VERTICAL-ALIGN: middle' qvalue='" + wd + "' onclick=onVoice(this,1); >" + _
'            "<IMG style='CURSOR:hand' src='images/Voice_1.png'" + _
'            "onmouseup=""this.src='images/Voice_1.png'"" onmousedown=""this.src='images/Voice_2.png'""/>" + _
'            "</SPAN>"
'        If symbols.Length > 1 Then
'            symbol = "[英][" + symbols(0) + "]" + sound_EN + "  [美][" + symbols(1) + "]" + sound_US
'        Else
'            symbol = "[" + symbols(0) + "]" + sound_US
'        End If
'    End If

'    Dim strAddDelWord As String = "<IMG id=delWord src='images/delete_word.png' alt ='mark as old'>"

'    If bnew = False Then
'        strAddDelWord = "<IMG id=addWord src='images/add_word.png' alt ='mark as new'>"
'    End If
'    Return "<div class='title' id='current_word'><h1>" + wd + "</h1></div>" + _
'            "<div class='prons'>" + symbol + _
'                 "<SPAN style='MARGIN-LEFT: 5px; VERTICAL-ALIGN: middle;CURSOR:hand' onclick=addDelWord(this);>" + _
'                strAddDelWord + _
'            "</div>" + _
'            "<DIV class='dict_content'>" + _
'                "<DIV class='explain'>" + def + "</DIV>" + _
'                "<DIV class='sample'>" + sent + "</DIV>" + _
'            "</DIV>"
'End Function

'iciba dict 
'Private Function QueryPWDict(ByVal wd As String, ByRef smb As String, ByRef def As String, ByRef sent As String) As Integer
'    Dim mp3path_EN As String = ""
'    Dim mp3path_US As String = ""
'    Dim xmlPath As String = "http://dict-co.iciba.com/api/dictionary.php?w=" & wd.Trim
'    Dim xmlFile As String = mXMLPath + wd.Trim + ".xml"
'    Dim bFound As Boolean = False
'    Dim S_XmlReader As XmlReader
'    Dim i As Integer = 0
'    smb = ""
'    def = ""
'    sent = ""
'    wd = wd.Trim
'    Try
'        If mBasicDict3.ExistWord(wd) Then
'            smb = mBasicDict3.GetSymbol()
'            def = mBasicDict3.GetDefinition()
'            sent = mBasicDict3.GetSentence()

'        ElseIf SystemInformation.Network And mMore Then
'            Dim pos As String = ""
'            Dim myWebClient = New System.Net.WebClient

'            If System.IO.File.Exists(xmlFile) = False Then
'                myWebClient.DownloadFile(New Uri(xmlPath), xmlFile)
'            End If
'            If System.IO.File.Exists(xmlFile) = True Then
'                Dim S_XmlReader2 As XmlReader
'                Dim settings As New XmlReaderSettings()
'                settings.ConformanceLevel = ConformanceLevel.Fragment
'                settings.IgnoreWhitespace = True
'                settings.IgnoreComments = True
'                S_XmlReader = XmlReader.Create(xmlFile, settings)
'                While S_XmlReader.Read()
'                    If S_XmlReader.NodeType = XmlNodeType.Element Then
'                        Select Case S_XmlReader.Name
'                            Case "ps"
'                                smb = smb + S_XmlReader.ReadString() + "&"
'                                bFound = True
'                            Case "pron"
'                                i = i + 1
'                                If i = 1 Then
'                                    mp3path_EN = S_XmlReader.ReadString()
'                                    bFound = True
'                                Else
'                                    mp3path_US = S_XmlReader.ReadString()
'                                End If

'                            Case "pos"
'                                pos = S_XmlReader.ReadString()
'                            Case "acceptation"
'                                def = def + pos + S_XmlReader.ReadString()
'                            Case "sent"
'                                S_XmlReader2 = S_XmlReader
'                                S_XmlReader2.ReadSubtree()
'                                While S_XmlReader2.Read()
'                                    If S_XmlReader.NodeType = XmlNodeType.Element Then
'                                        Select Case S_XmlReader2.Name
'                                            Case "orig"
'                                                sent = sent + S_XmlReader2.ReadString()
'                                            Case "trans"
'                                                sent = sent + S_XmlReader2.ReadString()
'                                        End Select
'                                    End If
'                                End While
'                                S_XmlReader2.Close()
'                        End Select
'                    End If
'                End While
'            End If

'            If bFound Then
'                If smb.Length > 1 Then
'                    smb = smb.Remove(Len(smb) - 1)
'                End If
'                sent = sent.Trim
'                sent = sent.Replace(vbLf + vbLf, vbLf)
'                mBasicDict3.InsertContent(wd, smb, def, sent, True)
'                Dim voiceFile_EN As String = mAudioPath_EN + wd.Trim + ".mp3"
'                Dim voiceFile_US As String = mAudioPath_US + wd.Trim + ".mp3"
'                If System.IO.File.Exists(voiceFile_EN) = False And mp3path_EN.Length > 4 Then
'                    If mp3path_EN.Substring(mp3path_EN.Length - 4, 4) = ".mp3" Then
'                        myWebClient.DownloadFile(New Uri(mp3path_EN), voiceFile_EN)
'                    End If
'                End If
'                If System.IO.File.Exists(voiceFile_US) = False And mp3path_US.Length > 4 Then
'                    If mp3path_US.Substring(mp3path_US.Length - 4, 4) = ".mp3" Then
'                        myWebClient.DownloadFile(New Uri(mp3path_US), voiceFile_US)
'                    End If
'                End If
'            Else
'                def = "Not Found!"
'                sent = ""
'                S_XmlReader.Close()
'                System.IO.File.Delete(xmlFile)
'                Return -1       'not found
'            End If
'        End If

'        def = def.Replace(vbLf, "<BR>")
'        sent = sent.Replace(vbLf, "<BR>")

'        Call OnHoverSpeech(wd, True)
'    Catch ex As Exception
'        If S_XmlReader IsNot Nothing Then
'            S_XmlReader.Close()
'        End If
'        If System.IO.File.Exists(xmlFile) = True Then
'            Dim xml As String = System.IO.File.ReadAllText(xmlFile, System.Text.Encoding.UTF8)
'            xml = Regex.Replace(xml, "<([^a-z>]+)>", "&lt;$1&gt;")
'            xml = xml.Replace("&", "&amp;")
'            System.IO.File.WriteAllText(xmlFile, xml)
'        End If
'        def = "Try Again!"
'        Return -2   'try again
'    End Try

'    Return 1    'good
'End Function

'qq dict 
Private Function QueryQQDict(ByVal wd As String, ByRef json As String) As Integer
	Dim jsonURL As String = "http://dict.qq.com/dict?q=" & wd.Trim
	Dim jsonFile As String = mJSONPath + wd.Trim + ".json"
	Dim bFound As Boolean = False
	wd = wd.Trim
	Try
		If System.IO.File.Exists(jsonFile) = False And SystemInformation.Network And mMore Then
			'Dim myWebClient = New System.Net.WebClient
			'myWebClient.DownloadFile(New Uri(jsonURL), jsonFile)
			My.Computer.Network.DownloadFile(New Uri(jsonURL), jsonFile)
		End If

		'If System.IO.File.Exists(jsonFile) = True Then
		'    'check if is found or not
		'    Dim fileInfo As New FileInfo(jsonFile)
		'    Dim fileSize As Long = fileInfo.Length / 1024

		'    If fileSize > 2 Then
		'        bFound = True
		'    End If

		'End If

		json = My.Computer.FileSystem.ReadAllText(jsonFile)
		json = json.Replace("'", "\'")

		'Call OnHoverSpeech(wd, True)
	Catch ex As Exception
		Return -2       'error
	End Try

	Return 1    'good
End Function

'Private Sub DataWebBrowser_DocumentCompleted(ByVal sender As System.Object, ByVal e As System.Windows.Forms.WebBrowserDocumentCompletedEventArgs) Handles DataWebBrowser.DocumentCompleted
'    If mResult = False Then Return
'    Dim symbol As String = ""
'    Dim def As String = ""
'    Dim sent As String = ""
'    Dim more As String = ""
'    Dim more1 As String = ""
'    Dim more2 As String = ""
'    Dim more3 As String = ""
'    Dim bSucess As Boolean = False

'    If mMore Then
'        Dim ret As Integer = QueryDict2(mWord, symbol, def, sent)
'        Select Case ret
'            Case -1
'            Case -2
'                QueryDict2(mWord, symbol, def, sent)
'        End Select
'        Dim bNew As Boolean = (mBasicDict3.GetNew(mWord) = -1)
'        more2 = GetMore(mWord, symbol, def, sent, bNew, 2)
'        If QueryDict3(mWord, symbol, def, sent) = 1 Then
'            more3 = GetMore(mWord, symbol, def, sent, bNew, 3)
'        End If
'        more = more1 + more2 + more3
'    Else
'        more = "<DIV class=lcDownDetail>" + _
'                        "<SPAN><IMG src='images/downdetail.png'></SPAN>" + _
'                        "<SPAN><A class=asTextColor href='app:detail:" + WordTxtBox.Text + "' target=_self>点击查看更多解释</A></SPAN>" + _
'                    "</DIV "
'    End If

'    symbol = ""
'    def = ""
'    sent = ""

'    Dim main_Item As HtmlElement = DataWebBrowser.Document.GetElementById("main")
'    If main_Item = Nothing Then Return
'    If mMore = False Then
'        Dim ct As String = ""
'        QueryDict1(mWord, symbol, ct)
'        main_Item.InnerHtml = "<div class=main>" + _
'                                "<div class = 'dict_title'>" + _
'                                    "<div class='title' id='current_word'><h1>" + mWord + "</h1></div>" + _
'                                "</div>" + _
'                                "<div class = 'dict_content'>" + _
'                                    "<DIV class = 'explain'>" + _
'                                        ct + _
'                                    "</DIV>" + _
'                                "</div>" + _
'                                more + _
'                            "</div>"
'    Else
'        main_Item.InnerHtml = "<div class=main>" + _
'                            more + _
'                             "</div>"
'        mMore = False
'    End If
'    If DataWebBrowser.ReadyState = WebBrowserReadyState.Complete Then
'        DataWebBrowser.Document.Body.AttachEventHandler("ondblclick", AddressOf DataWebBrowser_OnDoubleClick)
'    End If
'    If mFocus Then
'        WordTxtBox.Focus()
'        mFocus = False
'    End If
'End Sub

'Private Sub DataWebBrowser_DocumentCompleted2(ByVal sender As System.Object, ByVal e As System.Windows.Forms.WebBrowserDocumentCompletedEventArgs) Handles DataWebBrowser.DocumentCompleted
'    Return
'    If mResult = False Then Return
'    Dim bFound As String = True
'    Dim bNew As String = True
'    Dim symbol As String = ""
'    Dim def As String = ""
'    Dim sent As String = ""
'    Dim more As String = ""
'    Dim more1 As String = ""
'    Dim more2 As String = ""
'    Dim more3 As String = ""
'    Dim json As String = ""
'    Dim bSucess As Boolean = False

'    If mMore Then
'        'Dim ret As Integer = QueryDict2(mWord, symbol, def, sent)
'        'Select Case ret
'        '    Case -1
'        '    Case -2
'        '        QueryDict2(mWord, symbol, def, sent)
'        'End Select
'        'Dim bNew As Boolean = (mBasicDict3.GetNew(mWord) = -1)
'        'more2 = GetMore(mWord, symbol, def, sent, bNew, 2)
'        If QueryQQDict(mWord, json) <> 1 Then
'            bFound = False
'            'more3 = GetMore(mWord, symbol, def, sent, bNew, 3)
'        End If
'        bNew = mWordDict.GetNew(mWord)
'        more = more1 + more2 + more3
'    Else
'        more = "<DIV class=lcDownDetail>" + _
'                        "<SPAN><IMG src='images/downdetail.png'></SPAN>" + _
'                        "<SPAN><A class=asTextColor href='app:detail:" + WordTxtBox.Text + "' target=_self>点击查看更多解释</A></SPAN>" + _
'                    "</DIV "
'    End If

'    symbol = ""
'    def = ""
'    sent = ""

'    Dim main_Item As HtmlElement = DataWebBrowser.Document.GetElementById("main")
'    If main_Item = Nothing Then Return
'    If mMore = False Then
'        Dim ct As String = ""
'        QueryVOADict(mWord, symbol, ct)
'        main_Item.InnerHtml = "<div class=main>" + _
'                                "<div class = 'dict_title'>" + _
'                                    "<div class='title' id='current_word'><h1>" + mWord + "</h1></div>" + _
'                                "</div>" + _
'                                "<div class = 'dict_content'>" + _
'                                    "<DIV class = 'explain'>" + _
'                                        ct + _
'                                    "</DIV>" + _
'                                "</div>" + _
'                                more + _
'                            "</div>"
'    Else
'        'main_Item.InnerHtml = "<div class=main>" + _
'        '                    more + _
'        '                     "</div>"
'        Dim ObjArr(3) As Object
'        ObjArr(0) = CObj(New String(mWord))
'        ObjArr(1) = CObj(New String(json))
'        ObjArr(2) = CObj(New String(bNew))
'        DataWebBrowser.Document.InvokeScript("Display", ObjArr)
'        mMore = False
'    End If
'    If DataWebBrowser.ReadyState = WebBrowserReadyState.Complete Then
'        DataWebBrowser.Document.Body.AttachEventHandler("ondblclick", AddressOf DataWebBrowser_OnDoubleClick)
'    End If
'    If mFocus Then
'        WordTxtBox.Focus()
'        mFocus = False
'    End If
'End Sub

Private Function GetMore(ByVal wd As String, ByVal symbol As String, ByVal def As String, ByVal sent As String, ByVal bNew As Boolean, ByVal which As Integer) As String
	If symbol <> Nothing Then
		Dim symbols() As String = symbol.Split("&")
		Dim sound_EN As String =
			"<SPAN class='symbol' id=voice0 style='MARGIN-LEFT: 5px; VERTICAL-ALIGN: middle' qvalue='" + wd + "' onclick=onVoice(this,0); >" + _
			"<IMG style='CURSOR:hand' src='images/Voice_1.png'" + _
			"onmouseup=""this.src='images/Voice_1.png'"" onmousedown=""this.src='images/Voice_2.png'""/>" + _
			"</SPAN>"
		Dim sound_US As String =
			"<SPAN class='symbol' id=voice0 style='MARGIN-LEFT: 5px; VERTICAL-ALIGN: middle' qvalue='" + wd + "' onclick=onVoice(this,1); >" + _
			"<IMG style='CURSOR:hand' src='images/Voice_1.png'" + _
			"onmouseup=""this.src='images/Voice_1.png'"" onmousedown=""this.src='images/Voice_2.png'""/>" + _
			"</SPAN>"
		If symbols.Length > 1 Then
			symbol = "[英][" + symbols(0) + "]" + sound_EN + "  [美][" + symbols(1) + "]" + sound_US
		Else
			symbol = "[" + symbols(0) + "]" + sound_US
		End If
	End If

	Dim strAddDelWord As String = "<IMG id='delWord' src='images/delete_word.png' alt ='mark as old'>"

	If bNew = False Then
		strAddDelWord = "<IMG id = 'addWord' src='images/add_word.png' alt ='mark as new'>"
	End If
	Return "<div class = 'dict_title'>" + _
				"<div class='title' id='current_word'><h1>" + wd + "</h1></div>" + _
				"<div class='prons'>" + symbol + _
				  "<SPAN style='MARGIN-LEFT: 5px; VERTICAL-ALIGN: middle;CURSOR:hand' onclick=addDelWord" + which.ToString + "(this);>" + _
					strAddDelWord + "</SPAN>" + _
				"</div>" + _
			"</div>" + _
			"<div class = 'dict_content'>" + _
				"<div class = 'explain'>" + _
					def + _
				"</div>" + _
				"<div class = 'sample'>" + _
					sent + _
				"</div>" + _
			"</div>"
End Function

'Private Function DownloadIAudio(wd As String) As Boolean
'    Dim mp3path_EN As String = ""
'    Dim mp3path_US As String = ""
'    Dim xmlPath As String = "http://dict-co.iciba.com/api/dictionary.php?w=" & wd.Trim
'    Dim xmlFile As String = mXMLPath + wd.Trim + ".xml"
'    Dim S_XmlReader As XmlReader
'    Dim i As Integer = 0

'    wd = wd.Trim
'    Try
'        If System.IO.File.Exists(xmlFile) = False Then
'            Return False
'            If SystemInformation.Network And mMore Then
'                'Dim pos As String = ""
'                Dim myWebClient = New System.Net.WebClient

'                myWebClient.DownloadFile(New Uri(xmlPath), xmlFile)
'            Else
'                Return False
'            End If
'        End If

'        If System.IO.File.Exists(xmlFile) = True Then
'            Dim settings As New XmlReaderSettings()
'            settings.ConformanceLevel = ConformanceLevel.Fragment
'            settings.IgnoreWhitespace = True
'            settings.IgnoreComments = True
'            S_XmlReader = XmlReader.Create(xmlFile, settings)
'            While S_XmlReader.Read()
'                If S_XmlReader.NodeType = XmlNodeType.Element Then
'                    Select Case S_XmlReader.Name
'                        Case "pron"
'                            i = i + 1
'                            If i = 1 Then
'                                mp3path_EN = S_XmlReader.ReadString()
'                            Else
'                                mp3path_US = S_XmlReader.ReadString()
'                            End If
'                    End Select
'                End If
'            End While
'        End If

'        If SystemInformation.Network Then
'            Dim myWebClient = New System.Net.WebClient
'            Dim voiceFile_EN As String = mIAudioPath_EN + wd.Trim + ".mp3"
'            Dim voiceFile_US As String = mIAudioPath_US + wd.Trim + ".mp3"
'            Dim voiceFile As String = mAudioPath + wd.Trim + ".mp3"

'            If i = 1 Then

'                If System.IO.File.Exists(voiceFile) = False And mp3path_EN.Length > 4 Then
'                    If mp3path_EN.Substring(mp3path_EN.Length - 4, 4) = ".mp3" Then
'                        myWebClient.DownloadFile(New Uri(mp3path_EN), voiceFile)
'                    End If
'                End If

'            Else
'                If System.IO.File.Exists(voiceFile_EN) = False And mp3path_EN.Length > 4 Then
'                    If mp3path_EN.Substring(mp3path_EN.Length - 4, 4) = ".mp3" Then
'                        myWebClient.DownloadFile(New Uri(mp3path_EN), voiceFile_EN)
'                    End If
'                End If
'                If System.IO.File.Exists(voiceFile_US) = False And mp3path_US.Length > 4 Then
'                    If mp3path_US.Substring(mp3path_US.Length - 4, 4) = ".mp3" Then
'                        myWebClient.DownloadFile(New Uri(mp3path_US), voiceFile_US)
'                    End If
'                End If
'            End If

'            If System.IO.File.Exists(voiceFile_US) = False Then
'                Return False
'            End If

'        Else
'            Return False
'        End If

'    Catch ex As Exception
'        S_XmlReader.Close()
'        'MessageBox.Show(ex.ToString)
'        If System.IO.File.Exists(xmlFile) = True Then
'            Dim xml As String = System.IO.File.ReadAllText(xmlFile, System.Text.Encoding.UTF8)
'            'Dim expression As New Regex("<[^a-z]+>")
'            xml = Regex.Replace(xml, "<([^a-z>]+)>", "&lt;$1&gt;")
'            xml = xml.Replace("&", "&amp;")
'            System.IO.File.WriteAllText(xmlFile, xml)
'        End If
'        Return False
'    End Try

'    Return True
'End Function

Public Sub OnDelJSON(ByVal wd As String, ByVal first As Boolean)
	System.IO.File.Delete(mJSONPath + wd.Trim + ".json") 'delete JSON file
	If first = False Then
		MsgBox(WordTxtBox.Text + " was deleted!")
		WordTxtBox.Text = ""
	End If
	mWordDict.DelWord(wd)
End Sub

'For Each s In System.IO.Directory.GetDirectories(mGDictPath)
'    f = System.IO.Path.GetFileName(s)
'    If f.Substring(0, l - 1) = wd Then
'        'Console.WriteLine(System.IO.Path.GetFileName(s))
'        Debug.Print(f)
'    End If
'Next


    Private Function DownloadHtml(ByVal url As String, ByVal code As String) As String
        Dim httpURL As New System.Uri(url)
        Dim myWebRequest As WebRequest = WebRequest.Create(httpURL)
        Dim myProxy As New WebProxy()
        Dim html As String = ""

        Try
            Dim proxyAddress As String = "http://127.0.0.1:8087"
            ' Create a new Uri object.
            Dim newUri As New Uri(proxyAddress)
            ' Associate the new Uri object to the myProxy object.
            myProxy.Address = newUri

            ' Create a NetworkCredential object and is assign to the Credentials property of the Proxy object.
            myProxy.Credentials = New NetworkCredential("", "")
            myWebRequest.Proxy = myProxy

            Dim myWebResponse As WebResponse = myWebRequest.GetResponse()
            Dim streamResponse As Stream = myWebResponse.GetResponseStream()
            Dim streamRead As New StreamReader(streamResponse, System.Text.Encoding.GetEncoding(code))
            html = streamRead.ReadToEnd()

            ' Close the Stream object.
            streamResponse.Close()
            streamRead.Close()
            ' Release the HttpWebResponse Resource.
            myWebResponse.Close()

        Catch ex As UriFormatException
            'Console.WriteLine(ControlChars.Cr + "{0}", ex.Message)
            MsgBox(ex.Message)
        End Try
        Return html
    End Function
	
	
    '******************************
    '函数名：GetHtml
    '作  用：读取其他网站页面内容
    '参  数：Url是要读取的网站地址
    '返回值：读取后的网站内容
    '******************************
    Function GetHtml(ByVal Url As String, ByVal bm As String) As String
        Dim httpReq As System.Net.HttpWebRequest
        Dim httpResp As System.Net.HttpWebResponse
        Dim httpURL As New System.Uri(Url)
        Dim respHTML As String = ""

        httpReq = CType(WebRequest.Create(httpURL), HttpWebRequest)
        httpReq.Method = "GET"
        Try
            httpResp = CType(httpReq.GetResponse(), HttpWebResponse)
            httpReq.KeepAlive = False ' 获取或设置一个值，该值指示是否与 Internet资源建立持久连接。 
            Dim reader As StreamReader = New StreamReader(httpResp.GetResponseStream, System.Text.Encoding.GetEncoding(bm))
            respHTML = reader.ReadToEnd() 'respHTML就是网页源代码
        Catch
            respHTML = "zhongduan"
        End Try
        Return respHTML
    End Function

    '******************************
    '函数名：GetHtml
    '作  用：读取其他网站页面内容
    '参  数：Url是要读取的网站地址
    '返回值：读取后的网站内容
    '******************************
    Function GetHtml2(ByVal Url As String, ByVal bm As String) As String
        Dim httpReq As System.Net.HttpWebRequest
        Dim httpResp As System.Net.HttpWebResponse
        Dim httpURL As New System.Uri(Url)
        Dim respHTML As String = ""

        Try
            Dim myProxy As New WebProxy()
            Dim proxyAddress As String = "http://127.0.0.1:8087"
            ' Create a new Uri object.
            Dim newUri As New Uri(proxyAddress)
            ' Associate the new Uri object to the myProxy object.
            myProxy.Address = newUri

            httpReq = CType(WebRequest.Create(httpURL), HttpWebRequest)
            httpReq.Proxy = myProxy
            Console.WriteLine(ControlChars.Cr + "The Address of the  new Proxy settings are {0}", myProxy.Address)
            httpReq.Method = "GET"

            httpResp = CType(httpReq.GetResponse(), HttpWebResponse)
            httpReq.KeepAlive = False ' 获取或设置一个值，该值指示是否与 Internet资源建立持久连接。 
            Dim reader As StreamReader = New StreamReader(httpResp.GetResponseStream, System.Text.Encoding.GetEncoding(bm))
            respHTML = reader.ReadToEnd() 'respHTML就是网页源代码
        Catch ex As UriFormatException
            Console.WriteLine(ControlChars.Cr + "{0}", ex.Message)
            respHTML = "zhongduan"
        End Try
        Return respHTML
    End Function
	
	
        'Dim gpath As String
        'For n = 97 To 122
        '    gpath = mGDictPath2 + Chr(n)
        '    Directory.CreateDirectory(gpath)
        'Next

        'Dim fileEntries As String() = Directory.GetFiles(mGDictPath2)

        '' Process the list of files found in the directory.
        'Dim filePath As String
        'Dim fileName As String
        'For Each filePath In fileEntries
        '    fileName = Path.GetFileName(filePath)
        '    File.Move(filePath, mGDictPath2 + fileName.Substring(0, 1) + "\" + fileName)
        'Next