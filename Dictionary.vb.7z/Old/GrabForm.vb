﻿Imports System
Imports System.Windows.Forms
Imports System.Security.Permissions
Imports System.Speech

<PermissionSet(SecurityAction.Demand, Name:="FullTrust")> _
<System.Runtime.InteropServices.ComVisibleAttribute(True)> _
Public Class GrabForm

    Property m_Result_url() As String = Application.StartupPath + "\ResultHtml\"
    Property m_Word As String = "ok"

    Private Sub GrabForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        With GrabWebBrowser
            '.Left = 1
            '.Width = 518
            .Navigate(m_Result_url + "mouse.html")
            .AllowWebBrowserDrop = False
            .IsWebBrowserContextMenuEnabled = False
            .WebBrowserShortcutsEnabled = False
            .ObjectForScripting = Me
        End With
    End Sub

    Private Sub GrabWebBrowser_Navigating(ByVal sender As System.Object, ByVal e As System.Windows.Forms.WebBrowserNavigatingEventArgs) Handles GrabWebBrowser.Navigating
        Dim str() As String = e.Url.ToString().Split(":")

        If (str(0) = "app") Then
            Select Case str(1)
                Case "remind"
                    'System.Diagnostics.
                Case "detail"
                    'MessageBox.Show(str(2))
            End Select

            e.Cancel = True
        End If

    End Sub

    Private Sub GrabWebBrowser_DocumentCompleted(ByVal sender As System.Object, ByVal e As System.Windows.Forms.WebBrowserDocumentCompletedEventArgs) Handles GrabWebBrowser.DocumentCompleted

        Dim symbol As String = ""

        'MainForm.mWordDict.GetSymbol(m_Word, symbol)

        'Dim bNew As Integer = MainForm.mWordDict.GetNew(m_Word)

        Dim strAddDelWord As String = ""

        'If bNew = 1 Then
        '    strAddDelWord = "<IMG id=delWord src='images/delete_word.png'>"
        'Else
        '    strAddDelWord = "<IMG id=addWord src='images/add_word.png'>"
        'End If

        'Dim ct As String = ""
        Dim tp As String = ""
        'Dim strContent As String = ""
        'Dim n As Integer = 0
        'Dim i As Integer = 0

        'If MainForm.m_pDict.GetContent(m_Word, ct, tp) Then
        '    Dim ctlist() As String = ct.Split("@")
        '    Dim tplist() As String = tp.Split("@")
        '    For Each Type In tplist
        '        If Type.Length > 0 Then
        '            Select Case Convert.ToInt32(Type)
        '                Case 1
        '                    strContent = strContent + "<DIV class=pos>" + (i + 1).ToString + "." + ctlist(n) + "</DIV> "
        '                    i += 1
        '                Case 0
        '                    strContent = strContent + "<DIV class=pos>&nbsp;&nbsp;" + ctlist(n) + "</DIV> "
        '            End Select
        '            n += 1
        '        End If
        '    Next
        'End If

        'Dim ct2 As String = ""
        'MainForm.m_pDict2.GetContent(m_Word, ct2, tp)

        Dim main_Item As HtmlElement = GrabWebBrowser.Document.GetElementById("main")
        If main_Item <> Nothing Then
            main_Item.InnerHtml = "<DIV class=main>" + _
                                    "<DIV>" + _
                                        "<DIV ><BR></DIV> " + _
                                        "<SPAN id=word class=lcWdLemma>" + m_Word + "</SPAN>" + _
                                        "<SPAN class='lcWdPho asTextColor'>" + symbol + "</SPAN>" + _
                                        "<SPAN class=lcWdSd id=voice0 style='MARGIN-LEFT: 5px; VERTICAL-ALIGN: middle' qvalue='" + m_Word + "' onclick=onVoice(this); >" + _
                                            "<IMG style='CURSOR:hand' src='voice/1.png'" + _
                                                "onmouseup=""this.src='voice/1.png'"" onmousedown=""this.src='voice/2.png'""/>" + _
                                        "</SPAN>" + _
                                        "<SPAN style='MARGIN-LEFT: 5px; VERTICAL-ALIGN: middle' onclick=addDelWord(this);>" + _
                                            strAddDelWord + _
                                        "</SPAN>" + _
                                        "<DIV class='lcWdMor asTextColor'>" + _
                                        "</DIV>" + _
                                        "<DIV class=dash></DIV> " + _
                                    "</DIV>" + _
                                    "<DIV class=lcDownDetail>" + _
                                        "<SPAN><IMG src='images/downdetail.png'></SPAN>" + _
                                        "<SPAN><A class=asTextColor href='app:detail:" + m_Word + "' target=_self>点击查看更多解释</A></SPAN>" + _
                                    "</DIV " + _
                                "</DIV>"
        End If
        If GrabWebBrowser.ReadyState = WebBrowserReadyState.Complete Then
            GrabWebBrowser.Document.Body.AttachEventHandler("ondblclick", AddressOf GrabWebBrowser_OnDoubleClick)
            'DataWebBrowser.Document.Body.AttachEventHandler("onclick", AddressOf DataWebBrowser_OnClick)
        End If
    End Sub

    Private Sub GrabWebBrowser_OnDoubleClick()
        Dim oDOM As mshtml.IHTMLDocument2 = GrabWebBrowser.Document.DomDocument
        m_Word = oDOM.selection.createRange.htmlText.ToString.ToLower.Trim
    End Sub

    Public Sub OnAddDelWord(ByVal bNew As Integer)
        If bNew = 1 Then
            MainForm.mNumNewwords += 1
        Else
            MainForm.mNumNewwords -= 1
        End If
        'MainForm.mWordDict.UpdateNew(m_Word, bNew)
    End Sub

    Public Sub OnHoverSpeech(ByVal word As String)
        If word IsNot Nothing Then
            MainForm.OnHoverSpeech(word)
        End If
    End Sub

End Class