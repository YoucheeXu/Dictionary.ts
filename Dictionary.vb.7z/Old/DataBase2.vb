﻿Imports System.Data.SQLite

Public Class CDataBase2
    Property mConnection As SQLiteConnection
    Property mDictName As String
    Private mWord As String
    Private mSymbol As String
    Private mExplain As String
    Private mVoice As String
    Private mMark As Boolean

    Sub New()
        mConnection = New SQLiteConnection
        mDictName = ""
    End Sub

    Protected Overrides Sub Finalize()
        '此处放入要执的代码
        'm_connn.Close()
        MyBase.Finalize() ' Call Finalize on the base class.
    End Sub

    Public Function LoadDict(ByVal name As String) As Boolean
        Dim newdict As Boolean = False
        mDictName = name
        mConnection.ConnectionString = "Data Source =" + mDictName
        Try
            'Dim objFile As System.IO.File
            If Not IO.File.Exists(mDictName) Then
                'm_connn.Open()
                newdict = True
                'create table
            End If
            mConnection.Open()
            If newdict = True Then
                For n = 97 To 122
                    CreateTabel(Chr(n))
                    Debug.Print(Chr(n))
                Next
            End If
        Catch ex As Exception
            MessageBox.Show(ex.ToString)
        End Try
        Return True
    End Function

    Public Sub UnloadDict()
        mConnection.Close()
    End Sub

    Private Function CreateTabel(ByVal letter As Char) As Boolean
        Dim cmd As SQLiteCommand = mConnection.CreateCommand

        cmd.CommandText = "CREATE TABLE " + letter + " (" + _
            "Word TEXT NOT NULL COLLATE NOCASE PRIMARY KEY, Symbol TEXT NOT NULL , Explain TEXT NOT NULL , Voice TEXT NOT NULL , Mark INTEGER NOT NULL)"
        Try
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            MessageBox.Show(ex.ToString)
            Return False
        End Try
        Return True
    End Function

    Function ExistWord(ByVal wd As String) As Boolean
        'Throw New NotImplementedException
        Return GetContent(wd)
    End Function

    Public Function GetWordList(ByVal wd As String, ByRef wdlist As String) As Boolean
        Dim cmd As SQLiteCommand = mConnection.CreateCommand
        Dim n As Integer = 0
        Dim dbReader As SQLiteDataReader

        cmd.CommandText = "select Word from " + wd.Substring(0, 1) + " where Word like '" + wd + "%'"
        Try
            dbReader = cmd.ExecuteReader

            While dbReader.Read
                wdlist = wdlist + dbReader.Item(0) + "@"
                n = n + 1
            End While
        Catch ex As Exception
            MessageBox.Show(ex.ToString)
            Return False
        End Try
        If n > 0 Then
            Return True
        Else
            Return False
        End If
    End Function

    Private Function GetContent(ByVal wd As String) As Boolean
        Dim cmd As SQLiteCommand = mConnection.CreateCommand
        Dim dbReader As SQLiteDataReader

        cmd.CommandText = "select * from " + wd.Substring(0, 1) + " where Word='" + wd + "'"

        Try
            dbReader = cmd.ExecuteReader

            If dbReader.Read Then
                mSymbol = dbReader.Item(1)
                mExplain = dbReader.Item(2)
                mVoice = dbReader.Item(3)
                mMark = dbReader.Item(4)
                Return True
            Else
                Return False
            End If

        Catch ex As Exception
            MessageBox.Show(ex.ToString)
            Return False
        End Try

    End Function

    Public Function UpdateNew(ByVal wd As String, ByVal bNew As Integer) As Boolean
        Dim cmd As SQLiteCommand = mConnection.CreateCommand

        If (bNew = 1) Then
            cmd.CommandText = "UPDATE " + wd.Substring(0, 1) + " SET Mark = '-1' WHERE Word ='" + wd + "'"
        Else
            cmd.CommandText = "UPDATE " + wd.Substring(0, 1) + " SET Mark = '0' WHERE Word ='" + wd + "'"
        End If

        Try
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            MessageBox.Show(ex.ToString)
            Return False
        End Try
        Return True
    End Function

    Public Function GetNew(ByVal wd As String) As Integer
        Dim cmd As SQLiteCommand = mConnection.CreateCommand
        Dim dbReader As SQLiteDataReader
        Dim bNew As Integer

        cmd.CommandText = "select Mark from " + wd.Substring(0, 1) + " where Word = '" + wd + "'"
        Try
            dbReader = cmd.ExecuteReader

            If dbReader.Read Then
                bNew = dbReader.Item(0)
            End If

        Catch ex As Exception
            MessageBox.Show(ex.ToString)
            Return -1
        End Try
        Return bNew
    End Function

    Public Function GetNewWords(ByVal table As String, ByRef wd As String, ByRef symbol As String, ByRef exp As String) As Boolean
        Dim cmd As SQLiteCommand = mConnection.CreateCommand
        Dim dbReader As SQLiteDataReader
        Dim n As Integer = 0

        cmd.CommandText = "select Word, Symbol, Explain from " + table + " where Mark = -1"

        Try
            dbReader = cmd.ExecuteReader

            While dbReader.Read
                wd = wd + dbReader.Item(0) + "@"
                symbol = symbol + dbReader.Item(1).ToString + "@"
                exp = exp + dbReader.Item(2).ToString + "@"
                n += 1
            End While

        Catch ex As Exception
            MessageBox.Show(ex.ToString)
            Return False
        End Try
        Return True
    End Function

    Public Function InsertContent(ByVal word As String, ByVal symbol As String, ByVal explain As String, ByVal voice As String, ByVal mark As Integer)

        Dim cmd As SQLiteCommand = mConnection.CreateCommand

        Dim table As String = word.Substring(0, 1)

        symbol = symbol.Replace("'", "''")

        Dim sql As String = "INSERT INTO " + table
        sql = sql + " VALUES ('"
        sql = sql + word + "', '"
        sql = sql + symbol + "', '"
        sql = sql + explain + "', '"
        sql = sql + voice + "', '"
        sql = sql + mark.ToString
        sql = sql + "')"
        cmd.CommandText = sql
        Try
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            MessageBox.Show(ex.ToString)
            Return False
        End Try
        Return True
    End Function

    Function GetSymbol() As String
        Return mSymbol
    End Function

    Function GetExplain() As String
        Return mExplain
    End Function

    Function GetVoice() As String
        Return mVoice
    End Function

End Class
