﻿Imports System.Data.OleDb

Public Class CMDBDataBase
    Property m_connn As OleDb.OleDbConnection
    Property m_strDictName As String

    Sub New()
        m_connn = New OleDbConnection
        m_strDictName = ""
    End Sub

    Protected Overrides Sub Finalize()
        '此处放入要执的代码
        'm_connn.Close()
        MyBase.Finalize() ' Call Finalize on the base class.
    End Sub

    Public Function LoadDict(ByVal name As String) As Boolean
        m_strDictName = Application.StartupPath + "\Data\" + name
        m_connn.ConnectionString = "Provider = Microsoft.Jet.OLEDB.4.0; Data Source =" + m_strDictName
        Try
            m_connn.Open()
        Catch ex As Exception
            MessageBox.Show(ex.ToString)
        End Try
        Return True
    End Function

    Public Sub UnloadDict()
        m_connn.Close()
    End Sub

    Public Function GetWordList(ByVal wd As String, ByRef wdlist As String) As Boolean
        Dim cmd As OleDbCommand = m_connn.CreateCommand
        Dim n As Integer = 0
        Dim dbReader As OleDbDataReader

        cmd.CommandText = "select Word from WordList where Word like '" + wd + "%'"
        Try
            dbReader = cmd.ExecuteReader

            While dbReader.Read
                wdlist = wdlist + dbReader.Item(0) + "@"
                n = n + 1
            End While
        Catch ex As Exception
            MessageBox.Show(ex.ToString)
            Return False
        End Try
        If n > 0 Then
            Return True
        Else
            Return False
        End If
    End Function

    Public Function GetSymbol(ByVal wd As String, ByRef symbol As String) As Boolean
        Dim cmd As OleDbCommand = m_connn.CreateCommand
        Dim n As Integer = 0
        Dim dbReader As OleDbDataReader

        cmd.CommandText = "select Pron from WordList where Word = '" + wd + "'"
        Try
            dbReader = cmd.ExecuteReader

            If dbReader.Read Then
                symbol = dbReader.Item(0)
                n += 1
            End If

        Catch ex As Exception
            MessageBox.Show(ex.ToString)
            Return False
        End Try
        If n > 0 Then
            Return True
        Else
            Return False
        End If
    End Function

    Public Function GetContent(ByVal wd As String, ByRef content As String, ByRef type As String) As Boolean
        Dim cmd As OleDbCommand = m_connn.CreateCommand
        Dim n As Integer = 0
        Dim dbReader As OleDbDataReader

        cmd.CommandText = "select explain from WordList where Word='" + wd + "'"

        Try
            dbReader = cmd.ExecuteReader

            While dbReader.Read
                content = dbReader.Item(0)
                n += 1
                type = Int(1).ToString
            End While

        Catch ex As Exception
            MessageBox.Show(ex.ToString)
            Return False
        End Try
        If n > 0 Then
            Return True
        Else
            Return False
        End If
    End Function

    Public Function UpdateNew(ByVal wd As String, ByVal bNew As Integer) As Boolean
        Dim cmd As OleDbCommand = m_connn.CreateCommand

        If (bNew = 1) Then
            cmd.CommandText = "UPDATE WordList SET New = '1' WHERE Word ='" + wd + "'"
        Else
            cmd.CommandText = "UPDATE WordList SET New = '0' WHERE Word ='" + wd + "'"
        End If

        Try
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            MessageBox.Show(ex.ToString)
            Return False
        End Try
        Return True
    End Function

    Public Function GetNew(ByVal wd As String) As Integer
        Dim cmd As OleDbCommand = m_connn.CreateCommand
        Dim dbReader As OleDbDataReader
        Dim bNew As Integer

        cmd.CommandText = "select New from WordList where Word = '" + wd + "'"
        Try
            dbReader = cmd.ExecuteReader

            While dbReader.Read
                bNew = dbReader.Item(0)
            End While

        Catch ex As Exception
            MessageBox.Show(ex.ToString)
            Return -1
        End Try
        Return bNew
    End Function

End Class