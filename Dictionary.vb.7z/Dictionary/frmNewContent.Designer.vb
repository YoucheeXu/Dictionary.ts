﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmNewContent
    Inherits System.Windows.Forms.Form

    'Form 重写 Dispose，以清理组件列表。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows 窗体设计器所必需的
    Private components As System.ComponentModel.IContainer

    '注意: 以下过程是 Windows 窗体设计器所必需的
    '可以使用 Windows 窗体设计器修改它。
    '不要使用代码编辑器修改它。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TxtWord = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TxtContent = New System.Windows.Forms.TextBox()
        Me.btnAddExplain = New System.Windows.Forms.Button()
        Me.btnAddInstance = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'TxtWord
        '
        Me.TxtWord.Location = New System.Drawing.Point(24, 43)
        Me.TxtWord.Name = "TxtWord"
        Me.TxtWord.Size = New System.Drawing.Size(148, 21)
        Me.TxtWord.TabIndex = 0
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(22, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(29, 12)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "单词"
        '
        'TxtContent
        '
        Me.TxtContent.Location = New System.Drawing.Point(24, 125)
        Me.TxtContent.Name = "TxtContent"
        Me.TxtContent.Size = New System.Drawing.Size(314, 21)
        Me.TxtContent.TabIndex = 2
        '
        'btnAddExplain
        '
        Me.btnAddExplain.Location = New System.Drawing.Point(24, 175)
        Me.btnAddExplain.Name = "btnAddExplain"
        Me.btnAddExplain.Size = New System.Drawing.Size(75, 23)
        Me.btnAddExplain.TabIndex = 4
        Me.btnAddExplain.Text = "增加解释"
        Me.btnAddExplain.UseVisualStyleBackColor = True
        '
        'btnAddInstance
        '
        Me.btnAddInstance.Location = New System.Drawing.Point(130, 175)
        Me.btnAddInstance.Name = "btnAddInstance"
        Me.btnAddInstance.Size = New System.Drawing.Size(75, 23)
        Me.btnAddInstance.TabIndex = 6
        Me.btnAddInstance.Text = "增加例句"
        Me.btnAddInstance.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(22, 89)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(65, 12)
        Me.Label2.TabIndex = 7
        Me.Label2.Text = "解释或例句"
        '
        'NewContentForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(350, 219)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.btnAddInstance)
        Me.Controls.Add(Me.btnAddExplain)
        Me.Controls.Add(Me.TxtContent)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.TxtWord)
        Me.KeyPreview = True
        Me.Name = "NewContentForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "New Content"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TxtWord As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents TxtContent As System.Windows.Forms.TextBox
    Friend WithEvents btnAddExplain As System.Windows.Forms.Button
    Friend WithEvents btnAddInstance As System.Windows.Forms.Button
    Friend WithEvents Label2 As System.Windows.Forms.Label
End Class
