﻿Imports System.IO
Imports System.Net
'google dict
Public Class CDataBase4
    Private mGDictPath1 As String
    Private mGDictPath2 As String
    Private mProxyAddress As String

    Sub New()
    End Sub

    Protected Overrides Sub Finalize()
        '此处放入要执的代码
        'm_connn.Close()
        MyBase.Finalize() ' Call Finalize on the base class.
    End Sub

    Public Function LoadDict(ByVal path As String, ByVal iniFile As CIniFile) As Boolean
        mGDictPath1 = path + "\Google\"
        mGDictPath2 = path + "\Google2\"

        mProxyAddress = "http://" + iniFile.GetString("Agent", "ip")

        Return True
    End Function

    Public Sub UnloadDict()

    End Sub

    Function ExistWord(ByVal wd As String) As Boolean
        'Throw New NotImplementedException
        Return False
    End Function

    Function QueryWrod(wd As String, ByVal isAgent As Boolean) As Boolean
        Dim jsonPath1 As String = mGDictPath1 + wd.Substring(0, 1) + "\\"
        Dim jsonFile1 As String = jsonPath1 + wd.Trim + ".json"
        Dim jsonURL1 As String = "http://dictionary.so8848.com/ajax_search?q=" & wd.Trim

        Dim jsonPath2 As String = mGDictPath2 + wd.Substring(0, 1) + "\\"
        Dim jsonFile2 As String = jsonPath2 + wd.Trim + ".json"
        Dim jsonURL2 As String = "http://www.google.com/dictionary/json?callback=getJson&q=" + wd.Trim + "&sl=en&tl=zh-cn&restrict=pr,de&client=te"

        Dim jsonStr As String = ""
        Dim bFound As Boolean = False
        wd = wd.Trim
        Try
            If System.IO.File.Exists(jsonFile1) = False And SystemInformation.Network Then
                'My.Computer.Network.DownloadFile(New Uri(jsonURL), jsonFile)
                'jsonStr = GetHtml(jsonURL, "UTF-8")
                'jsonStr = GetHtml2(jsonURL, "UTF-8")
                'jsonStr = DownloadHtml(jsonURL, "UTF-8")
                'My.Computer.FileSystem.WriteAllText(jsonFile, jsonStr, True)
                DownloadFile(jsonURL1, jsonFile1, isAgent)
            End If

            If System.IO.File.Exists(jsonFile2) = False And SystemInformation.Network Then
                'My.Computer.Network.DownloadFile(New Uri(jsonURL2), jsonFile2)
                If System.IO.Directory.Exists(jsonPath2) = False Then
                    My.Computer.FileSystem.CreateDirectory(jsonPath2)
                End If
                DownloadFile(jsonURL2, jsonFile2, isAgent)
            End If

            If System.IO.File.Exists(jsonFile1) Then Return True

        Catch ex As Exception
            Return False       'error
        End Try
        Return False
    End Function

    Public Function GetWordList(ByVal wd As String, ByRef wdlist As String) As Boolean
        Dim l As Integer = wd.Length
        wdlist = ""
        Dim wordsPath = mGDictPath1 + wd.Substring(0, 1)
        If System.IO.Directory.Exists(wordsPath) = False Then
            My.Computer.FileSystem.CreateDirectory(wordsPath)
        End If
        Dim fileEntries As String() = Directory.GetFiles(wordsPath)

        ' Process the list of files found in the directory.
        Dim filePath As String
        Dim fileName As String
        For Each filePath In fileEntries
            'Trace.TraceInformation(filePath)
            fileName = Path.GetFileNameWithoutExtension(filePath)
            'Trace.TraceInformation(fileName)
            If fileName.Length >= l Then
                If fileName.Substring(0, l) = wd Then
                    'console.writeline(system.io.path.getfilename(s))
                    'Trace.TraceInformation("Selected file: " + fileName)
                    wdlist = wdlist + fileName + "@"
                End If
            End If
        Next
        Return True
    End Function

    Function DelWord(ByVal wd As String) As Boolean

        'mPWDict.DelWord(mWord)  'delete word from dictory database
        'System.IO.File.Delete(mXMLPath + wd + ".xml") 'delete xml file
        'System.IO.File.Delete(mIAudioPath_EN + wd + ".mp3") 'delete audio file
        'System.IO.File.Delete(mIAudioPath_US + wd + ".mp3") 'delete audio file
        'System.IO.File.Delete(mIAudioPath + wd + ".mp3") 'delete audio file
        System.IO.File.Delete(mGDictPath1 + wd.Substring(0, 1) + "\\" + wd.Trim + ".json") 'delete JSON file
        System.IO.File.Delete(mGDictPath2 + wd.Substring(0, 1) + "\\" + wd.Trim + ".json") 'delete JSON file
        MsgBox(wd + " was deleted!")
        Return True
    End Function

    Private Function DownloadFile(ByVal url As String, ByVal file As String, ByVal isAgent As Boolean) As Boolean
        Dim httpURL As New System.Uri(url)
        Dim myWebRequest As WebRequest = WebRequest.Create(httpURL)

        Try
            ' Create a new Uri object.
            If isAgent = True Then
                'If Not PrevInstance(mProxyName, False) Then
                '    System.Diagnostics.Process.Start(mProxyProgram)
                'End If
                Dim myProxy As New WebProxy()
                Dim newUri As New Uri(mProxyAddress)
                ' Associate the new Uri object to the myProxy object.
                myProxy.Address = newUri

                ' Create a NetworkCredential object and is assign to the Credentials property of the Proxy object.
                myProxy.Credentials = New NetworkCredential("", "")
                myWebRequest.Proxy = myProxy
            End If

            Dim myWebResponse As WebResponse = myWebRequest.GetResponse()
            Dim streamResponse As Stream = myWebResponse.GetResponseStream()

            'Dim streamRead As New StreamReader(streamResponse)
            'html = streamRead.ReadToEnd()
            'Dim readBuff(256) As [Char]
            Dim readBuff(2048) As [Byte]
            Dim count As Integer = streamResponse.Read(readBuff, 0, 256)
            Dim fs As FileStream = New FileStream(file, FileMode.Create)

            While count > 0
                'Dim outputData As New [String](readBuff, 0, count)
                'Console.Write(outputData)

                fs.Write(readBuff, 0, count)
                count = streamResponse.Read(readBuff, 0, 256)
            End While

            ' Close the Stream object.
            streamResponse.Close()
            fs.Close()
            'streamRead.Close()
            ' Release the HttpWebResponse Resource.
            myWebResponse.Close()

        Catch ex As UriFormatException
            'Console.WriteLine(ControlChars.Cr + "{0}", ex.Message)
            MsgBox(ex.Message)
            Return False
        End Try
        Return True
    End Function

    Function DownloadGAudio(ByVal wd As String, ByVal audioPath As String, ByVal isAgent As Boolean) As Boolean
        Dim mp3url As String = "http://www.gstatic.com/dictionary/static/sounds/de/0/" & wd.Trim & ".mp3"
        Dim mp3file As String = audioPath & wd.Trim & ".mp3"
        Try
            If SystemInformation.Network Then
                'Dim myWebClient = New System.Net.WebClient
                'myWebClient.DownloadFile(New Uri(mp3url), mp3file)
                Return DownloadFile(mp3url, mp3file, isAgent)
                'Return True
            Else
                Return False
            End If
        Catch
            Return False
        End Try
    End Function
End Class
