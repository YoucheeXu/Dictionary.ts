﻿Public Class frmNewWordsSelect

    Private Sub frmNewWordSelect_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        'LstNewWordBooks
        Dim name1 As String = "生词本1"
        Dim name2 As String = "生词本2"
        Select Case frmNewWords.mWhichBook
            Case 1
                name1 = name1 + "(当前生词本)"
            Case 2
                name2 = name2 + "(当前生词本)"
        End Select
        LstNewWordBooks.Items.Clear()
        LstNewWordBooks.Items.Add(name1)
        LstNewWordBooks.Items.Add(name2)
        Btn_ChangeBooks.Enabled = False
    End Sub

    Private Sub Btn_ChangeBooks_Click(sender As System.Object, e As System.EventArgs) Handles Btn_ChangeBooks.Click
        Dim which As Integer = LstNewWordBooks.SelectedItem.ToString().Substring(3, 1)
        Select Case which
            'Case 1
            '    frmNewWords.ChangeBooks(1)
            Case 2
                frmNewWords.ChangeBooks(2)
        End Select
        Me.Close()
    End Sub

    Private Sub LstNewWordBooks_Click(sender As System.Object, e As System.EventArgs) Handles LstNewWordBooks.Click
        If LstNewWordBooks.SelectedItem IsNot Nothing Then
            Dim selectedItem As String = LstNewWordBooks.SelectedItem.ToString()
            If selectedItem.Length <= 4 Then
                Btn_ChangeBooks.Enabled = True
            Else
                Btn_ChangeBooks.Enabled = False
            End If
        End If
    End Sub
End Class