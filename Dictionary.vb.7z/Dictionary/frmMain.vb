﻿Imports System
Imports System.Windows.Forms
Imports System.Security.Permissions
Imports System.Speech
Imports System.IO
Imports System.IO.File
Imports System.Runtime.InteropServices
Imports System.Management
'Imports System.Xml
'Imports System.Text.RegularExpressions


'Imports System.Web.Script.Serialization

'<PermissionSet(SecurityAction.Demand, Name:="FullTrust")> _
'<PermissionSet(SecurityAction.LinkDemand, Name:="FullTrust")> _
'<System.Runtime.InteropServices.ComVisibleAttribute(True)> _
<ComVisibleAttribute(True)> _
<ClassInterfaceAttribute(ClassInterfaceType.AutoDispatch)> _
<DockingAttribute(DockingBehavior.AutoDock)> _
<PermissionSetAttribute(SecurityAction.InheritanceDemand, Name:="FullTrust")> _
<PermissionSetAttribute(SecurityAction.LinkDemand, Name:="FullTrust")> _
Public Class frmMain
    Property mSkinPath() As String = Application.StartupPath + "\Skin\"
    Property mDictPath() As String = Application.StartupPath + "\Dict\"
    Property mXMLPath() As String = Application.StartupPath + "\Dict\XML\"
    Property mJSONPath() As String = Application.StartupPath + "\Dict\JSON\"
    Property mDataPath() As String = Application.StartupPath + "\Data\"

    Property mIAudioPath() As String = Application.StartupPath + "\Audio\"
    Property mIAudioPath_EN() As String = mIAudioPath + "\Iciba\EN\"
    Property mIAudioPath_US() As String = mIAudioPath + "\Iciba\US\"
    Property mGAudioPath() As String = Application.StartupPath + "\Audio\Google\"
    Private mIniFile As CIniFile

    Property mNumNewwords() As Integer
    Property mResult() As Boolean = False
    Property mWdVoice() As New Speech.Synthesis.SpeechSynthesizer

    Property mWordDict() As CDataBase
    Property mVOADict() As CDataBase1
    'Property mPWDict() As CDataBase3
    Property mGDict() As CDataBase4
    Private mProxyProgram As String
    Private mProxyName As String
    Private mIsAgent As Boolean

    Property mFocus As Boolean
    Property mMore As Boolean
    Property mWord As String = ""
    Property mUrl As String = ""
    Property mVoice As Boolean
    Property mTopMost As Boolean = False

    Private Const HTCAPTION As Integer = &H2&
    Private Const WM_NCLBUTTONDOWN As Integer = &HA1&
    <DllImport("user32")> _
    Private Shared Function FindWindowA(ByVal lpClassName As String, ByVal lpWindowName As String) As Long
    End Function

    <DllImport("user32")> _
    Private Shared Function SendMessageA(ByVal hWnd As Integer, ByVal wMsg As Integer, ByVal wParam As Integer, ByVal lParam As Integer) As Integer
    End Function
	
    <DllImport("user32")> _
    Private Shared Function ReleaseCapture() As Integer
    End Function

    ''' <summary>
    ''' 移动窗口
    ''' </summary>
    ''' <param name="handle">移动窗口的句柄</param>
    ''' <remarks></remarks>
    Public Shared Sub WindowMove(ByVal handle As Integer)
        ReleaseCapture()
        SendMessageA(handle, WM_NCLBUTTONDOWN, HTCAPTION, &H0&)
    End Sub
	
    Private Sub MainForm_MouseDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles MyBase.MouseDown
        WindowMove(Me.Handle)
    End Sub
	
    Private Sub MainForm_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If PrevInstance(IO.Path.GetFileNameWithoutExtension(Application.ExecutablePath), True) Then
            Me.Close()
            Return
        End If

        'Dim hw&

        'hw = FindWindowA(vbNullString, "Title")
        'If hw <> 0 Then
        '    MsgBox("已经有一个实例在运行")
        '    End
        'End If
		
		mIniFile = New CIniFile
        mIniFile.mIniFilePath = mDataPath + "Dictionary.ini"

        If mIniFile.GetInteger("Agent", "Agent") = 1 Then
            mIsAgent = True
            'mProxyProgram = mIniFile.GetString("Agent", "program")
            'mProxyName = mIniFile.GetString("Agent", "Name")
        Else
            mIsAgent = False
        End If

        Me.Height = mIniFile.GetInteger("GUI", "Height")
        Me.Width = mIniFile.GetInteger("GUI", "Width")
        Me.BackColor = Color.FromArgb(67, 160, 255)

        'Panel_Input.BackColor = Color.FromArgb(9934743)
        'Panel_Input.BackColor = Color.FromArgb(240, 240, 240)
        Panel_Input.BackgroundImage = System.Drawing.Bitmap.FromFile(mSkinPath + "combox_bk.bmp")
        Panel_Input.BackgroundImageLayout = ImageLayout.Center

        Panel_Bottom.BackColor = Color.FromArgb(64, 132, 238)
        'Panel_Bottom.BackgroundImage = System.Drawing.Bitmap.FromFile(mSkinPath + "top_middle.bmp")

        txtCaption.BackColor = Color.Transparent
        BtnMenu.LoadImage(mSkinPath + "menu_btn.bmp", 31, 21)
        BtnMin.LoadImage(mSkinPath + "minimize_btn.bmp", 33, 21)
        BtnClose.LoadImage(mSkinPath + "close_btn.bmp", 43, 21)
        BtnLookup.LoadImage(mSkinPath + "lookup_btn.bmp", 110, 37)

        BtnPrev.LoadImage(mSkinPath + "prev_btn.bmp", 45, 37)
        BtnNxt.LoadImage(mSkinPath + "next_btn.bmp", 40, 37)
        BtnDrop.LoadImage(mSkinPath + "combobox_drop_btn.bmp", 20, 34)
        BtnDel.LoadImage(mSkinPath + "delete_item.bmp", 30, 34)
        BtnDel.Visible = False

        BtnNewword.LoadImage(mSkinPath + "newword_btn.bmp", 75, 22)

        Panel_Edit.BackColor = Color.FromArgb(255, 255, 255)
        Panel_Edit.BackgroundImage = System.Drawing.Bitmap.FromFile(mSkinPath + "combox_bk.bmp")

        '禁止用户用鼠标改变窗体大小
        Me.FormBorderStyle = Windows.Forms.FormBorderStyle.None

        With WordListBox
            .Width = 135
            .Height = 421
            .Hide()
        End With

        With DataWebBrowser
            .Left = 1
            .Width = 699
            .Height = 421
            .Navigate(mDataPath + "FrontPage\index.html")
            .AllowWebBrowserDrop = False
            .IsWebBrowserContextMenuEnabled = False
            .WebBrowserShortcutsEnabled = True
            .ObjectForScripting = Me
            .ScriptErrorsSuppressed = True
        End With

        DataWebBrowser.Update()
        Me.Update()

        mWordDict = New CDataBase
        mWordDict.LoadDict(mDictPath + "word.dict")

        mVOADict = New CDataBase1
        mVOADict.LoadDict(mDictPath + "VOA.dict")

        'mPWDict = New CDataBase3
        'mPWDict.LoadDict(mDictPath + "pw.dict")

        mGDict = New CDataBase4
        mGDict.LoadDict(mDictPath, mIniFile)

        mFocus = True

        MainTimer.Interval = 2000
    End Sub
	
    Private Sub MainForm_Shown(sender As Object, e As EventArgs) Handles MyBase.Shown
        WordTxtBox.Select()
        WordTxtBox.Focus()
    End Sub
	
    Private Sub MainForm_FormClosing(ByVal sender As System.Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        If mWordDict IsNot Nothing Then
            mWordDict.UnloadDict()
        End If
        If mVOADict IsNot Nothing Then
            mVOADict.UnloadDict()
        End If
        'mPWDict.UnloadDict()
        If mGDict IsNot Nothing Then
            mGDict.UnloadDict()
        End If
    End Sub
	
    Private Sub WordTxtBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles WordTxtBox.TextChanged
        Dim url_path As String = mDataPath + "FrontPage\index.html"
        Dim word As String = WordTxtBox.Text.Trim.ToLower
        'Dim word As String = WordTxtBox.Text.Trim
        Dim l = word.Length
        If l > 0 Then
            Dim asccode As Integer = Asc(word.Substring(l - 1))
            If Not ((asccode >= Asc("a") And asccode <= Asc("z")) Or (asccode <= Asc("Z") And asccode >= Asc("A"))) Then
                word = word.Substring(0, l - 1)
                WordTxtBox.Text = word
                WordTxtBox.SelectionStart = word.Length
            End If
        End If
        mWord = word
        Trace.TraceInformation("TextChanged: " + mWord)
        l = word.Length
        If l > 0 Then
            BtnDel.Visible = True
            WordListBox.Show()
            MainTimer.Stop()
            MainTimer.Enabled = False
            MainTimer.Enabled = True
            MainTimer.Start()
            'url_path = url_path + "ResultPage\index.html"\
            'url_path = mDataPath + "FrontPage\index.html"
            'url_path = "http://dict.cn/mini.php?q=" & mWord.Trim
            With DataWebBrowser
                .Width = 699 - 135
                .Left = 136
            End With
            mResult = True
            Dim wordlist As String = ""
            'If mWordDict.GetWordList(word, wordlist) Then
            If mGDict.GetWordList(word, wordlist) Then
                WordListBox.Items.Clear()
                Dim wdlst() As String = wordlist.Split("@")
                For Each wd In wdlst
                    If wd IsNot Nothing Then
                        WordListBox.Items.Add(wd)
                    End If
                Next
                WordListBox.SetSelected(0, True)
                'mWord = WordListBox.Items(0)
            End If
        Else
            BtnDel.Visible = False
            WordListBox.Hide()
            With DataWebBrowser
                .Left = 1
                .Width = 699
            End With
            'url_path = mDataPath + "FrontPage\index.html"
            mResult = False
            DataWebBrowser.Navigate(url_path)
        End If

        mUrl = url_path
        'DataWebBrowser.Navigate(url_path)

        DataWebBrowser.Update()
        Me.Update()
    End Sub

    Private Sub WordTxtBox_KeyDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles WordTxtBox.KeyDown
        If e.KeyCode = Keys.Enter Then
            MainTimer.Stop()
            MainTimer.Enabled = False
            ListMore()
        End If
        If e.Shift = True Then
            If e.KeyCode = Keys.Delete Then
                'Call OnDelJSON(WordTxtBox.Text, False)
                mGDict.DelWord(WordTxtBox.Text)
                WordTxtBox.Text = ""
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub WordListBox_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles WordListBox.Click
        Dim url_result As String = mSkinPath + "ResultHtml\result2.html"
        WordTxtBox.Text = WordListBox.SelectedItem().ToString()
        mWord = WordTxtBox.Text
        DataWebBrowser.Navigate(url_result)
    End Sub

    Private Sub WordListBox_DoubleClick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles WordListBox.DoubleClick
        WordTxtBox.Text = WordListBox.SelectedItem().ToString()
        ListMore()
    End Sub

    Private Sub DataWebBrowser_DocumentCompleted3(ByVal sender As System.Object, ByVal e As System.Windows.Forms.WebBrowserDocumentCompletedEventArgs) Handles DataWebBrowser.DocumentCompleted
        If mMore Then
            Dim word_Item As HtmlElement = DataWebBrowser.Document.GetElementById("queryword")
            If word_Item = Nothing Then Return
            word_Item.InnerHtml = mWord

            If mMore Then
                ' If Not PrevInstance(mProxyName, False) And mIsAgent Then
                    ' System.Diagnostics.Process.Start(mProxyProgram)
                ' End If
                mGDict.QueryWrod(mWord, mIsAgent)
            End If

            DataWebBrowser.Document.InvokeScript("google_search")
            OnHoverSpeech(mWord, True)
            mMore = False
            'Debug.Print(DataWebBrowser.DocumentText)
        End If

        Return

        If DataWebBrowser.ReadyState = WebBrowserReadyState.Complete Then
            DataWebBrowser.Document.Body.AttachEventHandler("ondblclick", AddressOf DataWebBrowser_OnDoubleClick)
        End If
        If mFocus Then
            WordTxtBox.Focus()
            mFocus = False
        End If
    End Sub

    Public Sub OnInsertWord(ByVal word As String, ByVal pho As String, ByVal bNew As Boolean)
        If mWordDict.ExistWord(word) = False Then
            mWordDict.InsertWord(word, pho, "", 1)
        End If
    End Sub

    Public Sub OnSetWordNew(ByVal bNew As Integer)
        If bNew = 1 Then
            mNumNewwords += 1
        Else
            mNumNewwords -= 1
        End If
        mWordDict.UpdateNew(mWord, bNew)
        WordTxtBox.Select()
    End Sub

    Public Sub OnSaveHtml(ByVal html As String)
        My.Computer.FileSystem.WriteAllText(mDataPath + "\query\" + mWord + ".html", html, True)
    End Sub

    Public Sub OnHoverSpeech(ByVal wd As String, ByVal us As Boolean)
        If wd IsNot Nothing Then
            'Dim voicefile As String = ""
            Dim voicefile2 As String = mGAudioPath + wd.Trim + ".mp3"

            'If us = False Then
            '    voicefile = mIAudioPath_EN + wd.Trim + ".mp3"
            'Else
            '    voicefile = mIAudioPath_US + wd.Trim + ".mp3"
            'End If

            If System.IO.File.Exists(voicefile2) = False Then
                If mGDict.DownloadGAudio(wd, mGAudioPath, mIsAgent) = False Then
                    mWdVoice.Speak(wd)
                    Return
                End If
            End If
            AxWindowsMediaPlayer1.URL = voicefile2
            AxWindowsMediaPlayer1.Ctlcontrols.play()
        End If
    End Sub

    Private Sub DataWebBrowser_OnDoubleClick()
        Dim oDOM As mshtml.IHTMLDocument2 = DataWebBrowser.Document.DomDocument
        'WordTxtBox.Text = oDOM.selection.createRange.htmlText.ToString.ToLower.Trim
        WordTxtBox.Text = oDOM.selection.createRange.Text.ToString.ToLower.Trim
        Me.WordTxtBox_TextChanged(Me, New System.EventArgs)
    End Sub

    'VOA dict
    Private Function QueryVOADict(ByVal wd As String, ByRef smb As String, ByRef ct As String) As Boolean
        Dim n As Integer = 0
        Dim def As String = ""
        Dim sent As String = ""
        smb = ""
        If mVOADict.ExistWord(wd) Then
            def = mVOADict.GetDefinition()
            sent = mVOADict.GetSentence()
            Dim deflst() As String = def.Split("@")
            Dim sentlst() As String = sent.Split("@")
            For i = 1 To deflst.Length - 1
                ct = ct + "<DIV class=pos>" + i.ToString + "." + deflst(i - 1) + "</DIV> " + "<DIV class=pos>&nbsp;&nbsp;" + sentlst(i - 1) + "</DIV> "
            Next
        End If
        Return True
    End Function

    Private Sub ListMore()
        WordTxtBox.Text = WordTxtBox.Text.Trim
        If WordTxtBox.Text.Length <= 1 Then Return
        mMore = True
        mFocus = True
        mResult = True
        mWord = WordTxtBox.Text.Trim
        WordListBox.Hide()
        With DataWebBrowser
            .Left = 1
            .Width = 699
            .Update()
        End With
        WordTxtBox.SelectAll()
        DataWebBrowser.Navigate(mDataPath + "Query\dict.html")
    End Sub

    Private Sub ToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolStripItemClickedEventArgs) Handles MenuStrip.ItemClicked
        Dim item As System.Windows.Forms.ToolStripMenuItem = e.ClickedItem
        Select Case e.ClickedItem().ToString()
            Case "Always Top"
                mTopMost = Not mTopMost
                Me.TopMost = mTopMost
                item.Checked = mTopMost
            Case "&Edit Word"
                '
            Case "&Delete Word"
                mGDict.DelWord(WordTxtBox.Text)
                'Call OnDelJSON(WordTxtBox.Text, False)
            Case Else
        End Select
        WordTxtBox.Select()
    End Sub

    Private Sub BtnMenu_Click(sender As Object, e As EventArgs) Handles BtnMenu.Click
        Me.MenuStrip.Show(Me.Location.X + BtnMenu.Location.X, Me.Location.Y + BtnMenu.Location.Y + 30)
    End Sub
	
    Private Sub BtnMin_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnMin.Click
        Me.WindowState = FormWindowState.Minimized
    End Sub
	
    Private Sub BtnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnClose.Click
        Me.Close()
    End Sub
	
    Private Sub BtnDel_Click(sender As System.Object, e As System.EventArgs) Handles BtnDel.Click
        WordTxtBox.Text = ""
    End Sub
	
    Private Sub BtnNewword_Click(sender As Object, e As EventArgs) Handles BtnNewword.Click
        'frmNewWords.ShowDialog()
    End Sub
	
    Private Sub BtnLookup_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnLookup.Click
        ListMore()
    End Sub

    Private Sub MainTimer_Tick(sender As Object, e As EventArgs) Handles MainTimer.Tick
        MainTimer.Stop()
        MainTimer.Enabled = False
        Trace.TraceInformation("TimerTick: " + mWord)
        Dim url_path As String = "http://dict.cn/mini.php?q=" & mWord.Trim
        DataWebBrowser.Navigate(url_path)
    End Sub

    Private Function PrevInstance(ByVal sProName As String, Optional ByVal start As Boolean = False) As Boolean
        Dim i As Integer
        Try
            i = Diagnostics.Process.GetProcessesByName(sProName).Length
        Catch ex As Exception
            i = 0
        End Try

        If start Then
            Return i > 1
        Else
            Return i > 0
        End If

    End Function

    Private Sub SetProxyServer(ByVal strAddress As String, ByVal intPort As Integer)

        Dim strPath As String ' Management Path

        strPath = "Win32_Proxy.ServerName=""" & Environ("ComputerName") & """"

        Dim objWMI As New ManagementObject(strPath) ' 初始化新执行个体 (Instance)。

        Dim objMBO As ManagementBaseObject ' 宣告管理对象的基本类别

        objMBO = objWMI.GetMethodParameters("SetProxySetting") ' 取得参数

        objMBO!ProxyServer = strAddress ' 设定代理服务器位置

        objMBO!ProxyPortNumber = intPort ' 设定代理服务器Port

        ' 呼叫 SetProxySetting 方法并传入参数

        objWMI.InvokeMethod("SetProxySetting", objMBO, Nothing)

    End Sub
End Class