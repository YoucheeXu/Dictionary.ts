﻿Imports Microsoft.VisualBasic.CompilerServices

Public Class CIniFile

    Public Property mIniFilePath As String

    Private Declare Function GetPrivateProfileString Lib "kernel32" Alias "GetPrivateProfileStringA" (ByVal lpApplicationName As String, ByVal lpKeyName As String, ByVal lpDefault As String, ByVal lpReturnedString As String, ByVal nSize As Int32, ByVal lpFileName As String) As Int32
    Private Declare Function WritePrivateProfileString Lib "kernel32" Alias "WritePrivateProfileStringA" (ByVal lpApplicationName As String, ByVal lpKeyName As String, ByVal lpString As String, ByVal lpFileName As String) As Int32

    Private Function GetINI(ByVal Section As String, ByVal keyName As String, Optional ByVal lpDefault As String = "") As String
        Dim Str As String = ""
        Str = LSet(Str, 256)
        GetPrivateProfileString(Section, keyName, lpDefault, Str, Len(Str), mIniFilePath)
        Return Microsoft.VisualBasic.Left(Str, InStr(Str, Chr(0)) - 1)
    End Function

    Public Function GetInteger(ByVal Section As String, ByVal keyName As String, Optional ByVal lpDefault As String = "") As Integer
        Dim value As String = GetINI(Section, keyName, lpDefault)
        Return Convert.ToInt32(value)
    End Function

    Public Function GetString(ByVal Section As String, ByVal keyName As String, Optional ByVal lpDefault As String = "") As String
        Return GetINI(Section, keyName, lpDefault)
    End Function

    Private Function SetINI(ByVal Section As String, ByVal keyName As String, ByVal lpString As String) As Boolean
        Try
            WritePrivateProfileString(Section, keyName, lpString, mIniFilePath)
        Catch exception1 As Exception
            Return False
        End Try
        Return True
    End Function

	Public Function SetInteger(ByVal Section As String, ByVal keyName As String, ByVal value As Integer) As Boolean
        Return   SetINI(Section, keyName, value.toString)
    End Function
	
End Class