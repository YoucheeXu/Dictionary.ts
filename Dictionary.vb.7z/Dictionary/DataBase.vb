﻿Imports System.Data.SQLite
'word dict
Public Class CDataBase

    Property mConnection As SQLiteConnection
    Property mDictName As String

    Sub New()
        mConnection = New SQLiteConnection
        mDictName = ""
    End Sub

    Protected Overrides Sub Finalize()
        '此处放入要执的代码
        'm_connn.Close()
        MyBase.Finalize() ' Call Finalize on the base class.
    End Sub

    Public Function LoadDict(ByVal name As String) As Boolean
        Dim newdict As Boolean = False
        mDictName = name
        mConnection.ConnectionString = "Data Source =" + mDictName
        Try
            If Not IO.File.Exists(mDictName) Then
                mConnection.Open()
                For n = 97 To 122
                    CreateTabel(Chr(n))
                    Debug.Print(Chr(n))
                Next
            End If
        Catch ex As Exception
            MessageBox.Show(ex.ToString)
        End Try
        mConnection.Open()
        Return True
    End Function

    Public Sub UnloadDict()
        mConnection.Close()
    End Sub

    Private Function CreateTabel(ByVal letter As Char) As Boolean
        Dim cmd As SQLiteCommand = mConnection.CreateCommand

        cmd.CommandText = "CREATE TABLE " + letter + " (" + _
            "Word TEXT PRIMARY KEY, Symbol1 TEXT, Symbol2 TEXT, Mark INTEGER)"
        Try
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            MessageBox.Show(ex.ToString)
            Return False
        End Try
        Return True
    End Function

    Public Function GetWordList(ByVal wd As String, ByRef wdlist As String) As Boolean
        Dim cmd As SQLiteCommand = mConnection.CreateCommand
        Dim n As Integer = 0
        Dim dbReader As SQLiteDataReader

        cmd.CommandText = "select Word from " + wd.Substring(0, 1) + " where Word like '" + wd + "%'"
        Try
            dbReader = cmd.ExecuteReader

            While dbReader.Read
                wdlist = wdlist + dbReader.Item(0) + "@"
                n = n + 1
            End While
        Catch ex As Exception
            MessageBox.Show(ex.ToString)
            Return False
        End Try
        If n > 0 Then
            Return True
        Else
            Return False
        End If
    End Function

    Public Function GetSymbol(ByVal wd As String, ByRef symbol As String) As Boolean
        Dim cmd As SQLiteCommand = mConnection.CreateCommand
        Dim n As Integer = 0
        Dim dbReader As SQLiteDataReader

        cmd.CommandText = "select symbol1 from " + wd.Substring(0, 1) + " where Word = '" + wd + "'"
        Try
            dbReader = cmd.ExecuteReader

            If dbReader.Read Then
                symbol = dbReader.Item(0)
                n += 1
            End If

        Catch ex As Exception
            MessageBox.Show(ex.ToString)
            Return False
        End Try
        If n > 0 Then
            Return True
        Else
            Return False
        End If
    End Function

    Public Function InsertWord(ByVal wd As String, ByVal symbol1 As String, ByVal symbol2 As String, ByVal mark As Integer) As Boolean
        Dim cmd As SQLiteCommand = mConnection.CreateCommand

        symbol1 = symbol1.Replace("'", "''")
        symbol2 = symbol2.Replace("'", "''")

        cmd.CommandText = "INSERT INTO " + wd.Substring(0, 1) + " VALUES ('" + wd + "', '" + symbol1 + "', '" + symbol2 + "', '" + mark.ToString + "')"
        Try
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            MessageBox.Show(ex.ToString)
            Return False
        End Try
        Return True
    End Function

    Public Function UpdateNew(ByVal wd As String, ByVal bNew As Boolean) As Boolean
        Dim cmd As SQLiteCommand = mConnection.CreateCommand

        If (bNew = True) Then
            cmd.CommandText = "UPDATE " + wd.Substring(0, 1) + " SET Mark = '1' WHERE Word ='" + wd + "'"
        Else
            cmd.CommandText = "UPDATE " + wd.Substring(0, 1) + " SET Mark = '0' WHERE Word ='" + wd + "'"
        End If

        Try
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            MessageBox.Show(ex.ToString)
            Return False
        End Try
        Return True
    End Function

    Public Function GetNew(ByVal wd As String) As Boolean
        Dim cmd As SQLiteCommand = mConnection.CreateCommand
        Dim dbReader As SQLiteDataReader
        Dim bNew As Integer

        cmd.CommandText = "select Mark from " + wd.Substring(0, 1) + " where Word = '" + wd + "'"
        Try
            dbReader = cmd.ExecuteReader

            If dbReader.Read Then
                bNew = dbReader.Item(0)
            Else
                Return False
            End If

        Catch ex As Exception
            MessageBox.Show(ex.ToString)
            Return False
        End Try
        Return bNew
    End Function

    Function ExistWord(ByVal wd As String) As Boolean
        'Throw New NotImplementedException
        Dim pho As String = ""
        Return GetSymbol(wd, pho)
    End Function

    Public Function DelWord(ByVal word As String)
        Dim table As String = word.Substring(0, 1)
        Dim cmd As SQLiteCommand = mConnection.CreateCommand

        cmd.CommandText = "delete from " + table + " where Word='" + word + "'"
        Try
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            MessageBox.Show(ex.ToString)
            Return False
        End Try
        Return True

    End Function

End Class