﻿'big problem, need be fixed
Public Class frmNewContent

    Private mDict As CDataBase1

    Private Sub NewContentForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        mDict = frmMain.mVOADict
    End Sub

    Private Function AddContent(ByVal bExplain As Boolean) As Boolean
        Dim wd As String = TxtWord.Text
        Dim content As String = TxtContent.Text

        If (wd.Length > 0 And content.Length > 0) Then
            If bExplain Then
                'mDict.InsertContent(wd, content.Replace("'", "''"), 1)
            Else
                'mDict.InsertContent(wd, content.Replace("'", "''"), 0)
            End If
            TxtContent.Clear()
        Else
            MessageBox.Show("Please fill all the TextBox!!")
            Return False
        End If
        Return True
    End Function

    Private Sub btnAddExplain_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAddExplain.Click
        Me.AddContent(True)
    End Sub

    Private Sub btnAddInstance_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAddInstance.Click
        Me.AddContent(False)
    End Sub

    Private Sub NewContentForm_KeyDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyDown
        Select Case e.KeyCode
            Case Keys.F7 : Me.AddContent(True)
            Case Keys.F8 : Me.AddContent(False)
        End Select
    End Sub

End Class