﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmNewWord
    Inherits System.Windows.Forms.Form

    'Form 重写 Dispose，以清理组件列表。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows 窗体设计器所必需的
    Private components As System.ComponentModel.IContainer

    '注意: 以下过程是 Windows 窗体设计器所必需的
    '可以使用 Windows 窗体设计器修改它。
    '不要使用代码编辑器修改它。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TxtWord = New System.Windows.Forms.TextBox()
        Me.TxtSymbol1 = New System.Windows.Forms.TextBox()
        Me.TxtSymbol2 = New System.Windows.Forms.TextBox()
        Me.BtnNextWord = New System.Windows.Forms.Button()
        Me.BtnOKWord = New System.Windows.Forms.Button()
        Me.BtnCancelWord = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'TxtWord
        '
        Me.TxtWord.Location = New System.Drawing.Point(25, 46)
        Me.TxtWord.Name = "TxtWord"
        Me.TxtWord.Size = New System.Drawing.Size(100, 21)
        Me.TxtWord.TabIndex = 0
        '
        'TxtSymbol1
        '
        Me.TxtSymbol1.Location = New System.Drawing.Point(25, 99)
        Me.TxtSymbol1.Name = "TxtSymbol1"
        Me.TxtSymbol1.Size = New System.Drawing.Size(100, 21)
        Me.TxtSymbol1.TabIndex = 1
        '
        'TxtSymbol2
        '
        Me.TxtSymbol2.Location = New System.Drawing.Point(25, 167)
        Me.TxtSymbol2.Name = "TxtSymbol2"
        Me.TxtSymbol2.Size = New System.Drawing.Size(100, 21)
        Me.TxtSymbol2.TabIndex = 2
        '
        'BtnNextWord
        '
        Me.BtnNextWord.Location = New System.Drawing.Point(194, 99)
        Me.BtnNextWord.Name = "BtnNextWord"
        Me.BtnNextWord.Size = New System.Drawing.Size(75, 23)
        Me.BtnNextWord.TabIndex = 3
        Me.BtnNextWord.Text = "&Next"
        Me.BtnNextWord.UseVisualStyleBackColor = True
        '
        'BtnOKWord
        '
        Me.BtnOKWord.Location = New System.Drawing.Point(94, 231)
        Me.BtnOKWord.Name = "BtnOKWord"
        Me.BtnOKWord.Size = New System.Drawing.Size(75, 23)
        Me.BtnOKWord.TabIndex = 4
        Me.BtnOKWord.Text = "&OK"
        Me.BtnOKWord.UseVisualStyleBackColor = True
        '
        'BtnCancelWord
        '
        Me.BtnCancelWord.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.BtnCancelWord.Location = New System.Drawing.Point(194, 231)
        Me.BtnCancelWord.Name = "BtnCancelWord"
        Me.BtnCancelWord.Size = New System.Drawing.Size(75, 23)
        Me.BtnCancelWord.TabIndex = 5
        Me.BtnCancelWord.Text = "&Cancel"
        Me.BtnCancelWord.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(23, 84)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(29, 12)
        Me.Label1.TabIndex = 6
        Me.Label1.Text = "英标"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(23, 152)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(29, 12)
        Me.Label2.TabIndex = 7
        Me.Label2.Text = "美标"
        '
        'NewWordForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.BtnCancelWord
        Me.ClientSize = New System.Drawing.Size(292, 266)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.BtnCancelWord)
        Me.Controls.Add(Me.BtnOKWord)
        Me.Controls.Add(Me.BtnNextWord)
        Me.Controls.Add(Me.TxtSymbol2)
        Me.Controls.Add(Me.TxtSymbol1)
        Me.Controls.Add(Me.TxtWord)
        Me.Name = "NewWordForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "New Word"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TxtWord As System.Windows.Forms.TextBox
    Friend WithEvents TxtSymbol1 As System.Windows.Forms.TextBox
    Friend WithEvents TxtSymbol2 As System.Windows.Forms.TextBox
    Friend WithEvents BtnNextWord As System.Windows.Forms.Button
    Friend WithEvents BtnOKWord As System.Windows.Forms.Button
    Friend WithEvents BtnCancelWord As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
End Class
