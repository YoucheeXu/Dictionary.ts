﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form 重写 Dispose，以清理组件列表。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows 窗体设计器所必需的
    Private components As System.ComponentModel.IContainer

    '注意: 以下过程是 Windows 窗体设计器所必需的
    '可以使用 Windows 窗体设计器修改它。
    '不要使用代码编辑器修改它。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMain))
        Me.WordListBox = New System.Windows.Forms.ListBox()
        Me.MenuStrip = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.AlwaysTopToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DToolStripMenuItem = New System.Windows.Forms.ToolStripSeparator()
        Me.NewToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.NewWordToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.NewExplainToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EditWordToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DeleteWordToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MainTimer = New System.Windows.Forms.Timer(Me.components)
        Me.BtnCapture = New System.Windows.Forms.Button()
        Me.AxWindowsMediaPlayer1 = New AxWMPLib.AxWindowsMediaPlayer()
        Me.txtCaption = New System.Windows.Forms.Label()
        Me.Panel_Input = New System.Windows.Forms.Panel()
        Me.Panel_Edit = New System.Windows.Forms.Panel()
        Me.WordTxtBox = New System.Windows.Forms.TextBox()
        Me.BtnDel = New Dictionary.ImageButton()
        Me.BtnDrop = New Dictionary.ImageButton()
        Me.BtnNxt = New Dictionary.ImageButton()
        Me.BtnPrev = New Dictionary.ImageButton()
        Me.Panel_Bottom = New System.Windows.Forms.Panel()
        Me.BtnNewword = New Dictionary.ImageButton()
        Me.DataWebBrowser = New System.Windows.Forms.WebBrowser()
        Me.BtnClose = New Dictionary.ImageButton()
        Me.BtnMenu = New Dictionary.ImageButton()
        Me.BtnMin = New Dictionary.ImageButton()
        Me.BtnLookup = New Dictionary.ImageButton()
        Me.MenuStrip.SuspendLayout()
        CType(Me.AxWindowsMediaPlayer1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel_Input.SuspendLayout()
        Me.Panel_Edit.SuspendLayout()
        CType(Me.BtnDel, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BtnDrop, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BtnNxt, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BtnPrev, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel_Bottom.SuspendLayout()
        CType(Me.BtnNewword, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BtnClose, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BtnMenu, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BtnMin, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BtnLookup, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'WordListBox
        '
        Me.WordListBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.WordListBox.Font = New System.Drawing.Font("宋体", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.WordListBox.FormattingEnabled = True
        Me.WordListBox.ItemHeight = 16
        Me.WordListBox.Location = New System.Drawing.Point(1, 95)
        Me.WordListBox.Name = "WordListBox"
        Me.WordListBox.Size = New System.Drawing.Size(120, 418)
        Me.WordListBox.TabIndex = 5
        '
        'MenuStrip
        '
        Me.MenuStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AlwaysTopToolStripMenuItem, Me.DToolStripMenuItem, Me.NewToolStripMenuItem, Me.EditWordToolStripMenuItem, Me.DeleteWordToolStripMenuItem})
        Me.MenuStrip.Name = "MenuStrip"
        Me.MenuStrip.Size = New System.Drawing.Size(182, 98)
        '
        'AlwaysTopToolStripMenuItem
        '
        Me.AlwaysTopToolStripMenuItem.Name = "AlwaysTopToolStripMenuItem"
        Me.AlwaysTopToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.AlwaysTopToolStripMenuItem.Text = "Always Top"
        '
        'DToolStripMenuItem
        '
        Me.DToolStripMenuItem.Name = "DToolStripMenuItem"
        Me.DToolStripMenuItem.Size = New System.Drawing.Size(178, 6)
        '
        'NewToolStripMenuItem
        '
        Me.NewToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NewWordToolStripMenuItem, Me.NewExplainToolStripMenuItem})
        Me.NewToolStripMenuItem.Name = "NewToolStripMenuItem"
        Me.NewToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.NewToolStripMenuItem.Text = "New"
        '
        'NewWordToolStripMenuItem
        '
        Me.NewWordToolStripMenuItem.Name = "NewWordToolStripMenuItem"
        Me.NewWordToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.W), System.Windows.Forms.Keys)
        Me.NewWordToolStripMenuItem.Size = New System.Drawing.Size(179, 22)
        Me.NewWordToolStripMenuItem.Text = "New &Word"
        '
        'NewExplainToolStripMenuItem
        '
        Me.NewExplainToolStripMenuItem.Name = "NewExplainToolStripMenuItem"
        Me.NewExplainToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.X), System.Windows.Forms.Keys)
        Me.NewExplainToolStripMenuItem.Size = New System.Drawing.Size(179, 22)
        Me.NewExplainToolStripMenuItem.Text = "New E&xplain"
        '
        'EditWordToolStripMenuItem
        '
        Me.EditWordToolStripMenuItem.Name = "EditWordToolStripMenuItem"
        Me.EditWordToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.E), System.Windows.Forms.Keys)
        Me.EditWordToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.EditWordToolStripMenuItem.Text = "&Edit Word"
        '
        'DeleteWordToolStripMenuItem
        '
        Me.DeleteWordToolStripMenuItem.Name = "DeleteWordToolStripMenuItem"
        Me.DeleteWordToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.D), System.Windows.Forms.Keys)
        Me.DeleteWordToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.DeleteWordToolStripMenuItem.Text = "&Delete Word"
        '
        'MainTimer
        '
        '
        'BtnCapture
        '
        Me.BtnCapture.Location = New System.Drawing.Point(325, 9)
        Me.BtnCapture.Name = "BtnCapture"
        Me.BtnCapture.Size = New System.Drawing.Size(75, 23)
        Me.BtnCapture.TabIndex = 5
        Me.BtnCapture.Text = "屏幕取词"
        Me.BtnCapture.UseVisualStyleBackColor = True
        Me.BtnCapture.Visible = False
        '
        'AxWindowsMediaPlayer1
        '
        Me.AxWindowsMediaPlayer1.Enabled = True
        Me.AxWindowsMediaPlayer1.Location = New System.Drawing.Point(487, 8)
        Me.AxWindowsMediaPlayer1.Name = "AxWindowsMediaPlayer1"
        Me.AxWindowsMediaPlayer1.OcxState = CType(resources.GetObject("AxWindowsMediaPlayer1.OcxState"), System.Windows.Forms.AxHost.State)
        Me.AxWindowsMediaPlayer1.Size = New System.Drawing.Size(75, 23)
        Me.AxWindowsMediaPlayer1.TabIndex = 6
        Me.AxWindowsMediaPlayer1.Visible = False
        '
        'txtCaption
        '
        Me.txtCaption.AutoSize = True
        Me.txtCaption.BackColor = System.Drawing.SystemColors.Control
        Me.txtCaption.Location = New System.Drawing.Point(-2, -1)
        Me.txtCaption.Name = "txtCaption"
        Me.txtCaption.Size = New System.Drawing.Size(65, 12)
        Me.txtCaption.TabIndex = 3
        Me.txtCaption.Text = "Dictionary"
        Me.txtCaption.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel_Input
        '
        Me.Panel_Input.BackColor = System.Drawing.SystemColors.Control
        Me.Panel_Input.Controls.Add(Me.Panel_Edit)
        Me.Panel_Input.Controls.Add(Me.BtnDrop)
        Me.Panel_Input.Controls.Add(Me.BtnNxt)
        Me.Panel_Input.Controls.Add(Me.BtnPrev)
        Me.Panel_Input.Location = New System.Drawing.Point(1, 37)
        Me.Panel_Input.Name = "Panel_Input"
        Me.Panel_Input.Size = New System.Drawing.Size(699, 58)
        Me.Panel_Input.TabIndex = 4
        '
        'Panel_Edit
        '
        Me.Panel_Edit.Controls.Add(Me.WordTxtBox)
        Me.Panel_Edit.Controls.Add(Me.BtnDel)
        Me.Panel_Edit.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.Panel_Edit.Location = New System.Drawing.Point(95, 11)
        Me.Panel_Edit.Name = "Panel_Edit"
        Me.Panel_Edit.Size = New System.Drawing.Size(466, 37)
        Me.Panel_Edit.TabIndex = 12
        '
        'WordTxtBox
        '
        Me.WordTxtBox.AllowDrop = True
        Me.WordTxtBox.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.WordTxtBox.Font = New System.Drawing.Font("宋体", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.WordTxtBox.Location = New System.Drawing.Point(6, 9)
        Me.WordTxtBox.Name = "WordTxtBox"
        Me.WordTxtBox.Size = New System.Drawing.Size(424, 19)
        Me.WordTxtBox.TabIndex = 1
        Me.WordTxtBox.WordWrap = False
        '
        'BtnDel
        '
        Me.BtnDel.Location = New System.Drawing.Point(436, 1)
        Me.BtnDel.Name = "BtnDel"
        Me.BtnDel.Size = New System.Drawing.Size(30, 34)
        Me.BtnDel.TabIndex = 1
        Me.BtnDel.TabStop = False
        '
        'BtnDrop
        '
        Me.BtnDrop.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.BtnDrop.Location = New System.Drawing.Point(561, 13)
        Me.BtnDrop.Name = "BtnDrop"
        Me.BtnDrop.Size = New System.Drawing.Size(20, 34)
        Me.BtnDrop.TabIndex = 8
        Me.BtnDrop.TabStop = False
        '
        'BtnNxt
        '
        Me.BtnNxt.Location = New System.Drawing.Point(55, 11)
        Me.BtnNxt.Name = "BtnNxt"
        Me.BtnNxt.Size = New System.Drawing.Size(40, 37)
        Me.BtnNxt.TabIndex = 7
        Me.BtnNxt.TabStop = False
        '
        'BtnPrev
        '
        Me.BtnPrev.Location = New System.Drawing.Point(10, 11)
        Me.BtnPrev.Name = "BtnPrev"
        Me.BtnPrev.Size = New System.Drawing.Size(45, 37)
        Me.BtnPrev.TabIndex = 0
        Me.BtnPrev.TabStop = False
        '
        'Panel_Bottom
        '
        Me.Panel_Bottom.BackColor = System.Drawing.SystemColors.Control
        Me.Panel_Bottom.Controls.Add(Me.BtnCapture)
        Me.Panel_Bottom.Controls.Add(Me.BtnNewword)
        Me.Panel_Bottom.Location = New System.Drawing.Point(0, 516)
        Me.Panel_Bottom.Name = "Panel_Bottom"
        Me.Panel_Bottom.Size = New System.Drawing.Size(704, 35)
        Me.Panel_Bottom.TabIndex = 13
        '
        'BtnNewword
        '
        Me.BtnNewword.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.BtnNewword.Location = New System.Drawing.Point(571, 9)
        Me.BtnNewword.Margin = New System.Windows.Forms.Padding(0)
        Me.BtnNewword.Name = "BtnNewword"
        Me.BtnNewword.Size = New System.Drawing.Size(75, 22)
        Me.BtnNewword.TabIndex = 12
        Me.BtnNewword.TabStop = False
        Me.BtnNewword.Text = "查词"
        '
        'DataWebBrowser
        '
        Me.DataWebBrowser.IsWebBrowserContextMenuEnabled = False
        Me.DataWebBrowser.Location = New System.Drawing.Point(126, 95)
        Me.DataWebBrowser.Margin = New System.Windows.Forms.Padding(2)
        Me.DataWebBrowser.MinimumSize = New System.Drawing.Size(20, 20)
        Me.DataWebBrowser.Name = "DataWebBrowser"
        Me.DataWebBrowser.Size = New System.Drawing.Size(561, 421)
        Me.DataWebBrowser.TabIndex = 2
        '
        'BtnClose
        '
        Me.BtnClose.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.BtnClose.Location = New System.Drawing.Point(657, 1)
        Me.BtnClose.Name = "BtnClose"
        Me.BtnClose.Size = New System.Drawing.Size(43, 21)
        Me.BtnClose.TabIndex = 9
        Me.BtnClose.TabStop = False
        Me.BtnClose.Text = "×"
        '
        'BtnMenu
        '
        Me.BtnMenu.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.BtnMenu.Location = New System.Drawing.Point(593, 1)
        Me.BtnMenu.Name = "BtnMenu"
        Me.BtnMenu.Size = New System.Drawing.Size(33, 21)
        Me.BtnMenu.TabIndex = 8
        Me.BtnMenu.TabStop = False
        '
        'BtnMin
        '
        Me.BtnMin.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.BtnMin.Location = New System.Drawing.Point(624, 1)
        Me.BtnMin.Name = "BtnMin"
        Me.BtnMin.Size = New System.Drawing.Size(33, 21)
        Me.BtnMin.TabIndex = 7
        Me.BtnMin.TabStop = False
        Me.BtnMin.Text = "-"
        '
        'BtnLookup
        '
        Me.BtnLookup.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.BtnLookup.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.BtnLookup.Location = New System.Drawing.Point(581, 48)
        Me.BtnLookup.Margin = New System.Windows.Forms.Padding(0)
        Me.BtnLookup.Name = "BtnLookup"
        Me.BtnLookup.Size = New System.Drawing.Size(110, 37)
        Me.BtnLookup.TabIndex = 1
        Me.BtnLookup.TabStop = False
        Me.BtnLookup.Text = "查词"
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ClientSize = New System.Drawing.Size(701, 551)
        Me.Controls.Add(Me.DataWebBrowser)
        Me.Controls.Add(Me.Panel_Bottom)
        Me.Controls.Add(Me.txtCaption)
        Me.Controls.Add(Me.AxWindowsMediaPlayer1)
        Me.Controls.Add(Me.BtnClose)
        Me.Controls.Add(Me.BtnMenu)
        Me.Controls.Add(Me.BtnMin)
        Me.Controls.Add(Me.WordListBox)
        Me.Controls.Add(Me.BtnLookup)
        Me.Controls.Add(Me.Panel_Input)
        Me.Font = New System.Drawing.Font("宋体", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.MaximizeBox = False
        Me.MinimumSize = New System.Drawing.Size(580, 436)
        Me.Name = "frmMain"
        Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Dictionary"
        Me.MenuStrip.ResumeLayout(False)
        CType(Me.AxWindowsMediaPlayer1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel_Input.ResumeLayout(False)
        Me.Panel_Edit.ResumeLayout(False)
        Me.Panel_Edit.PerformLayout()
        CType(Me.BtnDel, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BtnDrop, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BtnNxt, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BtnPrev, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel_Bottom.ResumeLayout(False)
        CType(Me.BtnNewword, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BtnClose, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BtnMenu, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BtnMin, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BtnLookup, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents WordListBox As System.Windows.Forms.ListBox
    Friend WithEvents BtnLookup As Dictionary.ImageButton
    Friend WithEvents MenuStrip As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents MainTimer As System.Windows.Forms.Timer
    Friend WithEvents BtnCapture As System.Windows.Forms.Button
    Friend WithEvents AxWindowsMediaPlayer1 As AxWMPLib.AxWindowsMediaPlayer
    Friend WithEvents BtnMin As Dictionary.ImageButton
    Friend WithEvents BtnMenu As Dictionary.ImageButton
    Friend WithEvents BtnClose As Dictionary.ImageButton
    Friend WithEvents txtCaption As System.Windows.Forms.Label
    Friend WithEvents Panel_Input As System.Windows.Forms.Panel
    Friend WithEvents BtnNxt As Dictionary.ImageButton
    Friend WithEvents BtnPrev As Dictionary.ImageButton
    Friend WithEvents BtnDrop As Dictionary.ImageButton
    Friend WithEvents Panel_Edit As System.Windows.Forms.Panel
    Friend WithEvents BtnDel As Dictionary.ImageButton
    Friend WithEvents BtnNewword As Dictionary.ImageButton
    Friend WithEvents Panel_Bottom As System.Windows.Forms.Panel
    Friend WithEvents WordTxtBox As System.Windows.Forms.TextBox
    Friend WithEvents AlwaysTopToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents NewToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DToolStripMenuItem As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents NewWordToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents NewExplainToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EditWordToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DeleteWordToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DataWebBrowser As System.Windows.Forms.WebBrowser
End Class
