﻿Public Class frmRes
    Property m_Result_url() As String = Application.StartupPath + "\ResultHtml\"

    Private Sub ResFrm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        BtnMenu.BackgroundImage = Image.FromFile(m_Result_url + "SGW_BTN_MAIN.png")
        BtnMin.BackgroundImage = Image.FromFile(m_Result_url + "SGW_BTN_MIN.png")
        BtnClose.BackgroundImage = Image.FromFile(m_Result_url + "SGW_BTN_CLOSE.png")
    End Sub


    Private Sub BtnMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnMenu.Click
        'MenuStrip.Show(Me.Left + BtnMenu.Left + 5, Me.Top + BtnMenu.Bottom + 27)
    End Sub

    Private Sub BtnMin_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnMin.Click
        Me.WindowState = FormWindowState.Minimized
        'Me.Hide()
    End Sub

    Private Sub BtnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnClose.Click
        Me.Close()
    End Sub
End Class