﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmNewWords
    Inherits System.Windows.Forms.Form

    'Form 重写 Dispose，以清理组件列表。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows 窗体设计器所必需的
    Private components As System.ComponentModel.IContainer

    '注意: 以下过程是 Windows 窗体设计器所必需的
    '可以使用 Windows 窗体设计器修改它。
    '不要使用代码编辑器修改它。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.BtnSave = New System.Windows.Forms.Button()
        Me.lstNewWords = New System.Windows.Forms.ListView()
        Me.ColumnHeader1 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader2 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader3 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader4 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.SaveFileDialog1 = New System.Windows.Forms.SaveFileDialog()
        Me.txtNum = New System.Windows.Forms.Label()
        Me.BtnManage = New Dictionary.ImageButton()
        Me.Panel_Label = New System.Windows.Forms.Panel()
        CType(Me.BtnManage, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'BtnSave
        '
        Me.BtnSave.Location = New System.Drawing.Point(319, 39)
        Me.BtnSave.Name = "BtnSave"
        Me.BtnSave.Size = New System.Drawing.Size(75, 23)
        Me.BtnSave.TabIndex = 0
        Me.BtnSave.Text = "Export"
        Me.BtnSave.UseVisualStyleBackColor = True
        '
        'lstNewWords
        '
        Me.lstNewWords.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader1, Me.ColumnHeader2, Me.ColumnHeader3, Me.ColumnHeader4})
        Me.lstNewWords.Font = New System.Drawing.Font("Lucida Sans Unicode", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstNewWords.GridLines = True
        Me.lstNewWords.Location = New System.Drawing.Point(0, 68)
        Me.lstNewWords.Name = "lstNewWords"
        Me.lstNewWords.Size = New System.Drawing.Size(765, 379)
        Me.lstNewWords.TabIndex = 1
        Me.lstNewWords.UseCompatibleStateImageBehavior = False
        Me.lstNewWords.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader1
        '
        Me.ColumnHeader1.Text = "No."
        '
        'ColumnHeader2
        '
        Me.ColumnHeader2.Text = "Word"
        '
        'ColumnHeader3
        '
        Me.ColumnHeader3.Text = "Symbol"
        '
        'ColumnHeader4
        '
        Me.ColumnHeader4.Text = "Explain"
        Me.ColumnHeader4.Width = 293
        '
        'txtNum
        '
        Me.txtNum.AutoSize = True
        Me.txtNum.Location = New System.Drawing.Point(46, 459)
        Me.txtNum.Name = "txtNum"
        Me.txtNum.Size = New System.Drawing.Size(41, 12)
        Me.txtNum.TabIndex = 2
        Me.txtNum.Text = "共计："
        '
        'BtnManage
        '
        Me.BtnManage.Location = New System.Drawing.Point(191, 3)
        Me.BtnManage.Name = "BtnManage"
        Me.BtnManage.Size = New System.Drawing.Size(89, 25)
        Me.BtnManage.TabIndex = 3
        Me.BtnManage.TabStop = False
        '
        'Panel_Label
        '
        Me.Panel_Label.Location = New System.Drawing.Point(0, 0)
        Me.Panel_Label.Name = "Panel_Label"
        Me.Panel_Label.Size = New System.Drawing.Size(765, 33)
        Me.Panel_Label.TabIndex = 4
        '
        'frmNewWords
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(765, 480)
        Me.Controls.Add(Me.BtnManage)
        Me.Controls.Add(Me.txtNum)
        Me.Controls.Add(Me.lstNewWords)
        Me.Controls.Add(Me.BtnSave)
        Me.Controls.Add(Me.Panel_Label)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.Name = "frmNewWords"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "NewWords"
        CType(Me.BtnManage, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents BtnSave As System.Windows.Forms.Button
    Friend WithEvents lstNewWords As System.Windows.Forms.ListView
    Friend WithEvents ColumnHeader1 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader2 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader3 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader4 As System.Windows.Forms.ColumnHeader
    Friend WithEvents SaveFileDialog1 As System.Windows.Forms.SaveFileDialog
    Friend WithEvents txtNum As System.Windows.Forms.Label
    Friend WithEvents BtnManage As Dictionary.ImageButton
    Friend WithEvents Panel_Label As System.Windows.Forms.Panel
End Class
