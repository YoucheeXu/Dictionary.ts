﻿Imports System.ComponentModel

Public Class ImageButton
    Inherits System.Windows.Forms.PictureBox

    Private bmp As Bitmap
    Private bmp_Normal As Bitmap
    Private bmp_Focused As Bitmap
    Private bmp_Clicked As Bitmap

    Public Sub LoadImage(ByVal imgfile As String, ByVal w As Integer, ByVal h As Integer)
        bmp = System.Drawing.Bitmap.FromFile(imgfile)
        'bmp.MakeTransparent(Color.FromArgb(240, 240, 240))
        'bmp.MakeTransparent()
        Me.Width = w
        Me.Height = h

        bmp_Normal = CutImage(New Point(0, 0), New Point(Width, Height - 1), bmp)
        bmp_Focused = CutImage(New Point(Width, 0), New Point(Width * 2, Height - 1), bmp)
        bmp_Clicked = CutImage(New Point(Width * 2, 0), New Point(Width * 3 - 1, Height - 1), bmp)

        Me.BackgroundImage = bmp_Normal
    End Sub

    Private Function CutImage(ByVal start As Point, ByVal ends As Point, ByVal b As Bitmap) As Bitmap
        Dim f As New Bitmap(ends.X - start.X + 1, ends.Y - start.Y + 1)
        For i As Integer = start.X To ends.X
            For j As Integer = start.Y To ends.Y
                Dim c As Color = b.GetPixel(i, j)
                f.SetPixel(i - start.X, j - start.Y, c)
            Next
        Next
        Return f

    End Function

    Protected Overrides Sub OnMouseEnter(ByVal e As System.EventArgs)
        MyBase.OnMouseEnter(e)
        Me.BackgroundImage = bmp_Focused
    End Sub

    Protected Overrides Sub OnMouseLeave(ByVal e As System.EventArgs)
        MyBase.OnMouseLeave(e)
        Me.BackgroundImage = bmp_Normal
    End Sub

    Protected Overrides Sub OnMouseDown(ByVal e As System.Windows.Forms.MouseEventArgs)
        MyBase.OnMouseDown(e)
        Me.BackgroundImage = bmp_Clicked
    End Sub

    Protected Overrides Sub OnMouseUp(ByVal e As System.Windows.Forms.MouseEventArgs)
        MyBase.OnMouseUp(e)
        Me.BackgroundImage = bmp_Focused
    End Sub

End Class
