﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmNewWordsSelect
    Inherits System.Windows.Forms.Form

    'Form 重写 Dispose，以清理组件列表。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows 窗体设计器所必需的
    Private components As System.ComponentModel.IContainer

    '注意: 以下过程是 Windows 窗体设计器所必需的
    '可以使用 Windows 窗体设计器修改它。
    '不要使用代码编辑器修改它。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.LstNewWordBooks = New System.Windows.Forms.ListBox()
        Me.Btn_ChangeBooks = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'LstNewWordBooks
        '
        Me.LstNewWordBooks.FormattingEnabled = True
        Me.LstNewWordBooks.ItemHeight = 12
        Me.LstNewWordBooks.Location = New System.Drawing.Point(12, 24)
        Me.LstNewWordBooks.Name = "LstNewWordBooks"
        Me.LstNewWordBooks.Size = New System.Drawing.Size(163, 196)
        Me.LstNewWordBooks.TabIndex = 0
        '
        'Btn_ChangeBooks
        '
        Me.Btn_ChangeBooks.Location = New System.Drawing.Point(205, 36)
        Me.Btn_ChangeBooks.Name = "Btn_ChangeBooks"
        Me.Btn_ChangeBooks.Size = New System.Drawing.Size(75, 23)
        Me.Btn_ChangeBooks.TabIndex = 1
        Me.Btn_ChangeBooks.Text = "Change"
        Me.Btn_ChangeBooks.UseVisualStyleBackColor = True
        '
        'frmNewWordSelect
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(292, 266)
        Me.Controls.Add(Me.Btn_ChangeBooks)
        Me.Controls.Add(Me.LstNewWordBooks)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.Name = "frmNewWordSelect"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "生词本管理"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents LstNewWordBooks As System.Windows.Forms.ListBox
    Friend WithEvents Btn_ChangeBooks As System.Windows.Forms.Button
End Class
