﻿Imports System.Data.SQLite
'VOA dict
Public Class CDataBase1
    Property mConnection As SQLiteConnection
    Property mDictName As String
    Private mWord As String
    Private mDefinition As String
    Private mSentence As String
    Private mMark As Boolean

    Sub New()
        mConnection = New SQLiteConnection
        mDictName = ""
    End Sub

    Protected Overrides Sub Finalize()
        '此处放入要执的代码
        'm_connn.Close()
        MyBase.Finalize() ' Call Finalize on the base class.
    End Sub

    Public Function LoadDict(ByVal name As String) As Boolean
        Dim newdict As Boolean = False
        mDictName = name
        mConnection.ConnectionString = "Data Source =" + mDictName
        Try
            'Dim objFile As System.IO.File
            If Not IO.File.Exists(mDictName) Then
                'm_connn.Open()
                newdict = True
                'create table
            End If
            mConnection.Open()
            If newdict = True Then
                For n = 97 To 122
                    CreateTabel(Chr(n))
                    Debug.Print(Chr(n))
                Next
            End If
        Catch ex As Exception
            MessageBox.Show(ex.ToString)
        End Try
        Return True
    End Function

    Public Sub UnloadDict()
        mConnection.Close()
    End Sub

    Private Function CreateTabel(ByVal letter As Char) As Boolean
        Dim cmd As SQLiteCommand = mConnection.CreateCommand

        cmd.CommandText = "CREATE TABLE " + letter + " (" + _
            "Word TEXT NOT NULL, Definition TEXT NOT NULL , Sentence TEXT NOT NULL)"
        Try
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            MessageBox.Show(ex.ToString)
            Return False
        End Try
        Return True
    End Function

    Function ExistWord(ByVal wd As String) As Boolean
        'Throw New NotImplementedException
        Return GetContent(wd)
    End Function

    Public Function GetWordList(ByVal wd As String, ByRef wdlist As String) As Boolean
        Dim cmd As SQLiteCommand = mConnection.CreateCommand
        Dim n As Integer = 0
        Dim dbReader As SQLiteDataReader

        cmd.CommandText = "select Word from " + wd.Substring(0, 1) + " where Word like '" + wd + "%'"
        Try
            dbReader = cmd.ExecuteReader

            While dbReader.Read
                wdlist = wdlist + dbReader.Item(0) + "@"
                n = n + 1
            End While
        Catch ex As Exception
            MessageBox.Show(ex.ToString)
            Return False
        End Try
        If n > 0 Then
            Return True
        Else
            Return False
        End If
    End Function

    Private Function GetContent(ByVal wd As String) As Boolean
        mDefinition = ""
        mSentence = ""
        Dim cmd As SQLiteCommand = mConnection.CreateCommand
        Dim dbReader As SQLiteDataReader
        Dim n As Integer = 0

        cmd.CommandText = "select * from " + wd.Substring(0, 1) + " where Word='" + wd + "'"

        Try
            dbReader = cmd.ExecuteReader

            While dbReader.Read
                mDefinition = mDefinition + dbReader.Item(1) + "@"
                mSentence = mSentence + dbReader.Item(2) + "@"
                n += 1
            End While

            If n > 0 Then
                Return True
            Else
                Return False
            End If

        Catch ex As Exception
            MessageBox.Show(ex.ToString)
            Return False
        End Try

    End Function

    Public Function InsertContent(ByVal word As String, ByVal definition As String, ByVal sentence As String)

        Dim cmd As SQLiteCommand = mConnection.CreateCommand

        Dim table As String = word.Substring(0, 1)

        sentence = sentence.Replace("'", "''")
        definition = definition.Replace("'", "''")

        Dim sql As String = "INSERT INTO " + table
        sql = sql + " VALUES ('"
        sql = sql + word + "', '"
        sql = sql + definition + "', '"
        sql = sql + sentence + "')"
        cmd.CommandText = sql
        Try
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            MessageBox.Show(ex.ToString)
            Return False
        End Try
        Return True
    End Function

    Function GetDefinition() As String
        Return mDefinition
    End Function

    Function GetSentence() As String
        Return mSentence
    End Function
	
End Class
