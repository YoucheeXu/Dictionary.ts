﻿'big problem, need be fixed
Public Class frmNewWords

    Private Property mSkinPath() As String = Application.StartupPath + "\Skin\"
    Public Property mWhichBook() As Integer = 2

    Private Sub frmNewWords_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        BtnManage.LoadImage(mSkinPath + "manage.bmp", 89, 25)
        Panel_Label.BackgroundImage = System.Drawing.Bitmap.FromFile(mSkinPath + "top.bmp")
        Call ChangeBooks(2)
    End Sub
    Public Sub ChangeBooks(ByVal which As Integer)
        mWhichBook = which
        Dim wds As String = ""
        Dim symbols As String = ""
        Dim exps As String = ""
        Dim num As Integer = 0
        lstNewWords.Items.Clear()
        For n = 97 To 122
            Select Case which
                'Case 1
                '    MainForm.mBasicDict.GetNewWords(Chr(n), wds, symbols, exps)
                Case 2
                    'MainForm.mPWDict.GetNewWords(Chr(n), wds, symbols, exps)
            End Select

            num = num + ShowNewWords(wds, symbols, exps)
            wds = ""
            symbols = ""
            exps = ""
        Next
        txtNum.Text = "共：" + num.ToString + "个生词"
    End Sub

    Private Sub BtnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnSave.Click
        'Dim sw As New IO.StreamWriter("c:\a.txt ")
        SaveFileDialog1.Filter = "txt files (*.txt)|*.txt"
        If SaveFileDialog1.ShowDialog() = DialogResult.OK Then
            Dim sw As New IO.StreamWriter(SaveFileDialog1.FileName)
            'Dim i As Integer, u As Integer = 0, v As Integer = 0 '定义循环变量,行变量,列变量
            'For u = 0 To lstNewWords.Items.Count - 1 '行循环
            '    For v = 0 To lstNewWords.Columns.Count - 1 '列循环
            '        If v < lstNewWords.Items(u).SubItems.Count Then '如果该行该列项存在
            '            Str(u, v) = lstNewWords.Items(u).SubItems(v).Text.Trim
            '        Else '如果该行该列项不存在

            '        End If
            '    Next
            'Next

            For Each item In lstNewWords.Items
                sw.WriteLine(item.subitems(1).text + " " + item.subitems(2).text)
                sw.WriteLine(item.subitems(3).text)
                sw.WriteLine()
            Next
            sw.Close()
        End If
    End Sub

    Private Function ShowNewWords(ByVal wds As String, ByVal symbols As String, ByVal exps As String) As Integer
        Dim lstWd() As String = wds.Split("@")
        Dim lstSyb() As String = symbols.Split("@")
        Dim lstExp() As String = exps.Split("@")
        Dim n As Integer = lstNewWords.Items.Count
        'Throw New NotImplementedException
        For i = 0 To lstWd.Length - 2
            Dim lv As New ListViewItem()
            lv.SubItems(0).Text = (n + i + 1).ToString
            lv.SubItems.Add(lstWd(i))
            lv.SubItems.Add(lstSyb(i))
            lv.SubItems.Add(lstExp(i))
            lstNewWords.Items.Add(lv)
        Next
        Return lstWd.Length - 1
    End Function

    Private Sub BtnManage_Click(sender As System.Object, e As System.EventArgs) Handles BtnManage.Click
        frmNewWordsSelect.ShowDialog(Me)
    End Sub
End Class