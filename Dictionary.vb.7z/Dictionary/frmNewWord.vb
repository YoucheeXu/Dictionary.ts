﻿Public Class frmNewWord

    Private mDict As CDataBase

    Private Function AddWord() As Boolean
        Dim wd As String = TxtWord.Text
        Dim symbol1 As String = TxtSymbol1.Text
        Dim symbol2 As String = TxtSymbol2.Text
        If (wd.Length > 0 And symbol1.Length > 0) Then  'And symbol2.Length > 0
            mDict.InsertWord(wd, symbol1, symbol2, 1)
        Else
            MessageBox.Show("Please fill all the TextBox!!")
            Return False
        End If
        Return True
    End Function

    Private Sub ClearControlsTxt()
        TxtWord.Clear()
        TxtSymbol1.Clear()
        TxtSymbol2.Clear()
    End Sub

    Private Sub MainForm_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'mDict = MainForm.mWordDict
        'm_pDict.LoadDict("word.dict")
    End Sub

    Private Sub BtnNextWord_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnNextWord.Click
        If (Me.AddWord()) Then
            Me.ClearControlsTxt()
        End If
    End Sub

    Private Sub BtnOKWord_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnOKWord.Click
        If (Me.AddWord()) Then
            Me.ClearControlsTxt()
        End If
        Me.Close()
    End Sub

    Private Sub BtnCancelWord_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnCancelWord.Click
        Me.Close()
    End Sub
End Class